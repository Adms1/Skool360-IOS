//
//  WishVC.swift
//  ANBC - Teacher
//
//  Created by ADMS on 01/11/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import SwiftGifOrigin

class WishVC: UIViewController {
    
    @IBOutlet var imgBirthday:UIImageView!
    @IBOutlet var lblName:CSWAnimatedTextView!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        imgBirthday.loadGif(name: "birthday")
        lblName.titleString = "Sweta Sheth"
    }
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
