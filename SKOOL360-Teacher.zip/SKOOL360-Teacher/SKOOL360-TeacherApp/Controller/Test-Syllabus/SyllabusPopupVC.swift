//
//  SyllabusPopupVC.swift
//  Skool360Teacher
//
//  Created by Sweta on 25/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

var syllabusModalData:SyllabusModel!
var syllabusData = [SyllabusModel]()

protocol SyllabusPopupVCDelegate {
    func refreshTableValues(_ values:[String], _ date:String)
}

var strStdID:String!
class SyllabusPopupVC: UIViewController {
    
    @IBOutlet var tblSyllabusPopupVC:UITableView!
    @IBOutlet var btnAddEdit:UIButton!
    var delegate:SyllabusPopupVCDelegate!
    var arrSyllabus:[String] = []
    var height:CGFloat = 0
    
    // MARK: - Life Cycle
    
    override func viewWillAppear(_ animated: Bool) {
        for value in syllabusData {
            arrSyllabus.append(value.TestSyllabus!)
        }
        
        tblSyllabusPopupVC.estimatedSectionHeaderHeight = 120
        tblSyllabusPopupVC.reloadData()
        
        if(self.view.tag == 100) {
            btnAddEdit.setTitle("ADD", for: .normal)
        }else {
            btnAddEdit.setTitle("UPDATE", for: .normal)
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(nextPrevious(notification:)), name: Notification.Name("NextPrevious"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(dismissPicker(notification:)), name: Notification.Name("dismiss"), object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        syllabusData = []
        arrSyllabus = []
        syllabusModalData = nil
        tblSyllabusPopupVC.scrollToRow(at: IndexPath.init(row: 0, section: 0), at: .top, animated: true)
        self.btnClose()
    }
    
    // MARK: - Button Click Action
    
    @IBAction func btnAddEditClicked()
    {
        let params = ["StaffID":staffID!,
                      "TSMasterID":(syllabusModalData.TSMasterID?.stringValue)!,
                      "TestName":(syllabusModalData.TestName)!,
                      "StandardID":strStdID!,
                      "TestDate":(btnChooseDate.titleLabel?.text)!,
                      "SubjectID":(syllabusModalData.SubjectID?.stringValue)!,
                      "SectionID":self.view.tag == 100 ? (syllabusModalData.SectionIDS)! : (syllabusModalData.SectionID?.stringValue)!,
                      "Arydetail":arrSyllabus.count > 0 ? arrSyllabus.joined(separator: "|&") : ""]
        
        print(params)
        
        Functions.callApi(vc: self, api: API.teacherInsertTestDetailApi, params: params) { (json,error) in
            
            if(json != nil) {
                if(self.view.tag == 200) {
                    self.delegate.refreshTableValues(self.arrSyllabus, (btnChooseDate.titleLabel?.text)!)
                    Functions.showAlert(true, Message.testUpdateSuccess)
                }else{
                    Functions.showAlert(true, Message.testAddSuccess)
                }
                self.btnClose()
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.btnAddEditClicked()
                })
            }
        }
    }
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    @objc func nextPrevious(notification:NSNotification)
    {
        let userInfo = notification.userInfo!
        let tagValues = (userInfo["Tag"] as! String).components(separatedBy: "|").flatMap { Int($0.trimmingCharacters(in: .whitespaces)) }
        
        if let nextField = tblSyllabusPopupVC.viewWithTag((tagValues.first!/100) + (tagValues.last == -1 ? -1 : 1))?.subviews[0].subviews[0] as? UITextView {
            nextField.becomeFirstResponder()
        } else {
            NotificationCenter.default.post(name: Notification.Name("dismiss"), object: nil, userInfo: ["Tag":tagValues.first!])
        }
    }
    
    @objc func dismissPicker(notification:NSNotification) {
        
        let userInfo = notification.userInfo!
        let txtView:UITextView = (tblSyllabusPopupVC.viewWithTag((userInfo["Tag"] as! NSInteger)/100)?.subviews[0].subviews[0] as? UITextView)!
        txtView.resignFirstResponder()
        
        tblSyllabusPopupVC.contentInset = .zero
        tblSyllabusPopupVC.contentOffset = .zero
        
        view.endEditing(true)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SyllabusPopupVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:SyllabusPopupCell = tableView.dequeueReusableCell(withIdentifier: "SyllabusPopupHeaderCell") as! SyllabusPopupCell
        
        if syllabusModalData != nil {
            headerView.displayHeaderData(syllabusData: syllabusModalData)
        }
        
        btnChooseDate = headerView.btnDate
        if(self.view.tag == 200) {
            addBorder(headerView.btnDate)
            headerView.btnDate.addTarget(self, action: #selector(chooseTestDate(_:)), for: .touchUpInside)
        }
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SyllabusPopupCell = tableView.dequeueReusableCell(withIdentifier: "SyllabusPopupCell", for: indexPath) as! SyllabusPopupCell
        
        cell.tag = indexPath.row + 1
        (cell.contentView.subviews[0] as! UITextView).tag = cell.tag * 100
        addBorder((cell.contentView.subviews[0] as! UITextView))
        
        if(indexPath.row < arrSyllabus.count) {
            (cell.contentView.subviews[0] as! UITextView).text = arrSyllabus[indexPath.row]
        }else {
            (cell.contentView.subviews[0] as! UITextView).text = nil
        }
        return cell
    }
    
    @objc func chooseTestDate(_ sender:UIButton)
    {
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        let currentDate:Date = (sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        selector.optionCurrentDate = currentDate
        selector.optionCurrentDateRange.setStartDate(currentDate)
        selector.optionCurrentDateRange.setEndDate(currentDate)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
}

extension SyllabusPopupVC: UITextViewDelegate {
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        height = 0
        let offSetY:CGFloat = textView.tag != 100 ? (textView.superview?.superview?.frame.origin.y)! - tblSyllabusPopupVC.estimatedSectionHeaderHeight : 0
        self.tblSyllabusPopupVC.setContentOffset(CGPoint(x:0, y:offSetY), animated: true)
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        
        if((textView.tag/100) < arrSyllabus.count + 1) {
            arrSyllabus[(textView.tag/100) - 1] = textView.text!
        }else{
            if !arrSyllabus.contains(textView.text!) {
                arrSyllabus.append(textView.text!)
            }
        }
    }
    
    func textViewDidChange(_ textView: UITextView) {
        let fixedWidth: CGFloat = textView.frame.size.width
        let newSize: CGSize = textView.sizeThatFits(CGSize(width: fixedWidth, height:CGFloat.greatestFiniteMagnitude))
        
        if(newSize.height != height){
            if(height > 0) {
                UIView.animate(withDuration: 0.3, delay: 0.0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.7, options: [.curveLinear], animations: { () -> Void in
                    
                    self.tblSyllabusPopupVC.beginUpdates()
                    self.tblSyllabusPopupVC.endUpdates()
                    
                }, completion: nil)
            }
            height = newSize.height
        }
    }
}

extension SyllabusPopupVC:WWCalendarTimeSelectorProtocol
{
    // MARK: - Calender Delegate
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        
        btnChooseDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}
