//
//  SyllabusVV.swift
//  Skool360Teacher
//
//  Created by ADMS on 25/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class EditSyllabusVC: UITableViewController,SyllabusPopupVCDelegate,SyllabusCellDelegate {
    
    var arrSyllabusData = [SyllabusModel]()
    var dicTestSyllabusData:NSMutableDictionary = [:]
    var tag:NSInteger = 0
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callSyllabusApi()
    }
    
    func tableFunctions()
    {
        self.tableView.isScrollEnabled = true
        
        self.tableView.tableFooterView = UIView()
        
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }
    
    
    // MARK: - API Calling
    
    func callSyllabusApi()
    {
        self.tableFunctions()
        
        let params = ["StaffID":staffID!]
        
        self.arrSyllabusData = []
        
        Functions.callApi(vc: self, api: API.teacherGetTestSyllabusApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrSyllabus = json!["FinalArray"].array
                
                var i = 0
                self.arrSyllabusData = []
                for values in arrSyllabus! {
                    
                    let syllabusModal:SyllabusModel = SyllabusModel.init(testName: values["TestName"].stringValue, TSmasterID: values["TSMasterID"].numberValue, stdClass: values["StandardClass"].stringValue, sectionID: values["SectionID"].numberValue, subject: values["Subject"].stringValue, subjectID: values["SubjectID"].numberValue, testDate: values["TestDate"].stringValue, testID: values["TestID"].numberValue, sectionIDS: "")
                    
                    self.arrSyllabusData.append(syllabusModal)
                    
                    var arrTestSyllabusData = [SyllabusModel]()
                    let jsonArray = values["TestSyllabus"].array
                    for syllabus in jsonArray!
                    {
                        arrTestSyllabusData.append(SyllabusModel.init(testSyllabus: syllabus["Syllabus"].stringValue))
                        
                        self.dicTestSyllabusData.setValue(arrTestSyllabusData, forKey: "\((i))")
                    }
                    i += 1
                }
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callSyllabusApi()
                })
            }
            self.tableView.reloadData()
        }
    }
    
    func refreshTableValues(_ values:[String])
    {
        var arrSyllabusData = [SyllabusModel]()
        for value in values {
            arrSyllabusData.append(SyllabusModel.init(testSyllabus: value))
        }
        self.dicTestSyllabusData.setValue(arrSyllabusData, forKey: "\((tag))")
        self.tableView.reloadRows(at: [IndexPath.init(row: tag, section: 0)], with: .automatic)
    }
    
    // MARK: - - SyllabusCell Delegate
    
    func editSyllabus(_ sender:UIButton)
    {
        tag = sender.tag
        syllabusModalData = self.arrSyllabusData[tag]
        if(self.dicTestSyllabusData["\((tag))"] != nil) {
            syllabusData = self.dicTestSyllabusData["\((tag))"] as! [SyllabusModel]
        }
        self.tableView.isScrollEnabled = false
        add(asChildViewController: syllabusVC, self)
    }
    
    private lazy var syllabusVC: SyllabusPopupVC = {
        
        var viewController:SyllabusPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "SyllabusPopupVC") as! SyllabusPopupVC
        viewController.view.tag = 200
        viewController.delegate = self
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    
    // MARK: - Button Click Action
    
    @IBAction func back()
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSyllabusData.count > 0 ? arrSyllabusData.count + 1 : 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if(indexPath.row == 0) {
            strIdentifier = "SyllabusHeaderCell"
        }
        else {
            strIdentifier = "SyllabusCell"
        }
        
        let cell:SyllabusCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! SyllabusCell
        
        if(indexPath.row > 0) {
            cell.delegate = self
            cell.btnEdit.tag = indexPath.row - 1
            cell.displayData(syllabusData: arrSyllabusData[indexPath.row-1], row: indexPath.row)
        }
        return cell
    }
}
