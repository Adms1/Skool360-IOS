//
//  LessonPlanScheduleVC.swift
//  Skool360Teacher
//
//  Created by ADMS on 11/10/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class LessonPlanScheduleVC: CustomViewController , LessonPlanScheduleCellDelegate {
    
    @IBOutlet var tblLessonPlanSchedule:UITableView!
    
    var arrLessonPlanSchedule = [LessonPlanScheduleModel]()
    var arrHomeWorkStatus = [LessonPlanScheduleModel]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblLessonPlanSchedule.estimatedRowHeight = self.title! == "Home Work" ? DeviceType.isIpad ? 190.0 : 170.0 : DeviceType.isIpad ? 140.0 : 120.0
        tblLessonPlanSchedule.rowHeight = UITableViewAutomaticDimension
        tblLessonPlanSchedule.tableFooterView = UIView()
        
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if((self.title)! != "Home Work"){
            view.subviews[0].addConstraint(NSLayoutConstraint.init(item: view.subviews[0], attribute: .height, relatedBy: .equal, toItem: view.subviews[0], attribute: .width, multiplier: 0, constant: 0))
            self.view.layoutIfNeeded()
        }
        self.view.subviews[0].isHidden =  (self.title)! != "Home Work" ? true : false
        self.callLessonPlanScheduleApi((self.title)! == "Home Work" ? API.teacherLessonPlanScheduledHomeworkApi : API.teacherLessonPlanSchedule)
    }
    
    
    // MARK: - API Calling
    
    func callLessonPlanScheduleApi(_ webApi:String)
    {
        let params = ["StaffID":staffID!,
                      "FromDate":((self.view.viewWithTag(1) as! UIButton).titleLabel?.text)!,
                      "ToDate":((self.view.viewWithTag(2) as! UIButton).titleLabel?.text)!]
        
        print(params)
        
        selectedIndex = -1
        arrLessonPlanSchedule = []
        arrHomeWorkStatus = []
        
        Functions.callApi(vc: self, api: webApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrLessonPlan = json!["FinalArray"].array
                
                for values in arrLessonPlan! {
                    
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
                    let myDate = dateFormatter.date(from: values["Date"].stringValue)!
                    
                    dateFormatter.dateFormat = "dd/MM/yyyy"
                    let somedateString = dateFormatter.string(from: myDate)
                    
                    let lessonPlanModal:LessonPlanScheduleModel = LessonPlanScheduleModel.init(date: somedateString, standard: values["Standard"].stringValue, className: values["ClassName"].stringValue, subject: values["Subject"].stringValue, homeWork: (values["HomeWork"].stringValue).stringFromHTML(values["HomeWork"].stringValue)!, chapterName: (values["ChapterName"].stringValue).stringFromHTML(values["ChapterName"].stringValue)!, objective: (values["Objective"].stringValue).stringFromHTML(values["Objective"].stringValue)!, assQue: (values["AssessmentQue"].stringValue).stringFromHTML(values["AssessmentQue"].stringValue)!)
                    self.arrLessonPlanSchedule.append(lessonPlanModal)
                    
                    let homeWorkModal:LessonPlanScheduleModel = LessonPlanScheduleModel.init(date: somedateString, termId: values["TermID"].stringValue, stdId: values["StandardID"].stringValue, clsId: values["ClassID"].stringValue, subId: values["SubjectID"].stringValue)
                    self.arrHomeWorkStatus.append(homeWorkModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callLessonPlanScheduleApi(webApi)
                })
            }
            self.tblLessonPlanSchedule.reloadData()
        }
    }
    
    
    // MARK: - Button Click Actions
    
    func studentHomeWorkStatus(_ sender:UIButton)
    {
        lessonPlanScheduleModal = self.arrHomeWorkStatus[sender.tag]
        add(asChildViewController: homeWorkPopupVC, self)
    }
    
    private lazy var homeWorkPopupVC: HomeWorkPopupVC = {
        
        var viewController:HomeWorkPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "HomeWorkPopupVC") as! HomeWorkPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    @IBAction func btnChooseDateAction(_ sender:UIButton)
    {
        btnDate = sender
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        selector.optionCurrentDateRange.setStartDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        selector.optionCurrentDateRange.setEndDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    @IBAction func btnFilterAction(_ sender:UIButton)
    {
        self.callLessonPlanScheduleApi((self.title)! == "Home Work" ? API.teacherLessonPlanScheduledHomeworkApi : API.teacherLessonPlanSchedule)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension LessonPlanScheduleVC:WWCalendarTimeSelectorProtocol
{
    // MARK: - Calender Delegate
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        btnDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}


extension LessonPlanScheduleVC:UITableViewDelegate,UITableViewDataSource
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:LessonPlanScheduleCell = tableView.dequeueReusableCell(withIdentifier: "LessonPlanScheduleHeaderCell") as! LessonPlanScheduleCell
        
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        //        for cell in tableView.visibleCells as! [LessonPlanScheduleCell] {
        //            if(cell.btnExpand != nil){
        //                cell.btnExpand.transform = .identity
        //            }
        //        }
        
        headerView.btnExpand.transform = .identity
        if section == selectedIndex {
            UIView.animate(withDuration: 0.5, animations: {
                headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
            })
        }
        headerView.displayLessonPlanScheduleHeaderData(arrLessonPlanSchedule[section])
        return arrLessonPlanSchedule.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50))
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrLessonPlanSchedule.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            tblLessonPlanSchedule.estimatedRowHeight = DeviceType.isIpad ? 60 : 50
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblLessonPlanSchedule.rowHeight == 0 ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String = "LessonPlanScheduleCell"
        if(self.title == "Home Work"){
            strIdentifier = "HomeWorkCell"
        }
        let cell:LessonPlanScheduleCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! LessonPlanScheduleCell
        cell.delegate = self
        
        if(self.title == "Home Work"){
            cell.contentView.subviews[0].subviews[0].tag = indexPath.section
        }
        cell.displayLessonPlanScheduleData(arrLessonPlanSchedule[indexPath.section])
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblLessonPlanSchedule.reloadSections(IndexSet(integersIn: 0...arrLessonPlanSchedule.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblLessonPlanSchedule.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}
