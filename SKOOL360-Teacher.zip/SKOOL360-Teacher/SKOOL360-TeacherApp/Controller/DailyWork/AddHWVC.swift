//
//  AddHWVC.swift
//  SKOOL360-Teacher
//
//  Created by ADMS on 07/12/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

var selectedDailyWorkModel:DailyWorkModel!
class AddHWVC: CustomViewController {
    
    @IBOutlet var lblGrade:UILabel!
    @IBOutlet var lblSection:UILabel!
    @IBOutlet var txtHW:UITextView!
    @IBOutlet var txtCW:UITextView!
    @IBOutlet var hwConstant:NSLayoutConstraint!
    @IBOutlet var cwContant:NSLayoutConstraint!
    var height:CGFloat = 40
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        lblGrade.text = selectedDailyWorkModel.Standard
        lblSection.text = selectedDailyWorkModel.ClassName
        
        txtHW.attributedText = selectedDailyWorkModel.HomeWork
        txtCW.attributedText = selectedDailyWorkModel.ClassWork
        
        hwConstant.constant = height
        cwContant.constant = height
        
        if(selectedDailyWorkModel.HomeWork != NSAttributedString.init(string: "")){
            self.changeHeightOfTextView(txtHW)
        }
        
        if(selectedDailyWorkModel.ClassWork != NSAttributedString.init(string: "")){
            self.changeHeightOfTextView(txtCW)
        }        
        addBorder(self.view.subviews[1])
        
        NotificationCenter.default.addObserver(self, selector: #selector(nextPrevious(notification:)), name: Notification.Name("NextPrevious"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(dismissPicker(notification:)), name: Notification.Name("dismiss"), object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AddHWVC
{
    @IBAction func btnSubmitAction(_ sender:UIButton)
    {
        if txtCW.attributedText == NSAttributedString.init(string: "".trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)){
            Functions.showAlert(false, Message.cwNotFound)
            return
        }
        self.callUpdateHWCWApi()
    }
    
    func callUpdateHWCWApi()
    {
        let params = ["DayBookId" : selectedDailyWorkModel.DayBookID!,
                      "HW" : txtHW.attributedText.string,
                      "CW" : txtCW.attributedText.string]
        
        Functions.callApi(vc: self, api: API.updateHWCWApi, params: params) { (json, error) in
            if json != nil {
                Functions.showAlert(true, Message.hwCwSuccess)
                self.dismiss(animated: true, completion: nil)
            }
        }
    }
}

extension AddHWVC: UITextViewDelegate
{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        if let scrollView:UIScrollView = textView.superview as? UIScrollView {
            if textView == txtCW {
                scrollView.setContentOffset(CGPoint(x:0, y: textView.frame.size.height), animated: true)
            }else{
                scrollView.setContentOffset(.zero, animated: true)
            }
        }
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        self.changeHeightOfTextView(textView)
    }
    
    func changeHeightOfTextView(_ textView:UITextView)
    {
        let fixedWidth: CGFloat = textView.frame.size.width
        let newSize: CGSize = textView.sizeThatFits(CGSize(width: fixedWidth, height:CGFloat.greatestFiniteMagnitude))
        
        if height != newSize.height && height < (DeviceType.isIphone5 ? 80 : DeviceType.isIpad ? 150 : 100) {
            if let scrollView:UIScrollView = textView.superview as? UIScrollView {
                if textView == txtCW {
                    scrollView.setContentOffset(CGPoint(x:0, y: newSize.height), animated: true)
                }else{
                    scrollView.setContentOffset(.zero, animated: true)
                }
            }
        }
        
        height = newSize.height
        if(height < (DeviceType.isIphone5 ? 80 : DeviceType.isIpad ? 150 : 100)){
            if textView == txtHW {
                self.hwConstant.constant = height
            }else {
                self.cwContant.constant = height
            }
        }else {
            if textView == txtHW {
                self.hwConstant.constant = DeviceType.isIphone5 ? 80 : DeviceType.isIpad ? 150 : 100
            }else {
                self.cwContant.constant = DeviceType.isIphone5 ? 80 : DeviceType.isIpad ? 150 : 100
            }
        }
    }
    
    @objc func nextPrevious(notification:NSNotification)
    {
        let userInfo = notification.userInfo!
        let tagValues = (userInfo["Tag"] as! String).components(separatedBy: "|").flatMap { Int($0.trimmingCharacters(in: .whitespaces)) }
        
        if let nextField = txtHW.superview?.viewWithTag(tagValues[1] == -1 ? tagValues[0] - 1 : tagValues[0] + 1) as? UITextView {
            nextField.becomeFirstResponder()
        } else {
            NotificationCenter.default.post(name: Notification.Name("dismiss"), object: nil, userInfo: ["Tag":tagValues.first!])
        }
    }
    
    @objc func dismissPicker(notification:NSNotification) {
        
        if let scrollView:UIScrollView = txtHW.superview as? UIScrollView {
            scrollView.setContentOffset(.zero, animated: true)
        }
        view.endEditing(true)
    }
}
