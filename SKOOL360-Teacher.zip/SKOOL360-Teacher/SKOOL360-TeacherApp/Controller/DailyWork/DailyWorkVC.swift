//
//  LessonPlanScheduleVC.swift
//  Skool360Teacher
//
//  Created by Sweta on 11/10/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class DailyWorkVC: CustomViewController , DailyWorkCellDelegate {
    
    @IBOutlet var tblDailyWork:UITableView!
    
    var arrDailyWork = [DailyWorkModel]()
    var arrHomeWorkStatus = [DailyWorkModel]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblDailyWork.tableFooterView = UIView()
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callDailyWorkApi()
    }
    
    
    // MARK: - API Calling
    
    func callDailyWorkApi()
    {
        let params = ["StaffID":staffID!,
                      "FromDT":((self.view.viewWithTag(1) as! UIButton).titleLabel?.text)!,
                      "ToDT":((self.view.viewWithTag(2) as! UIButton).titleLabel?.text)!]
        
        print(params)
        
        selectedIndex = -1
        arrDailyWork = []
        
        Functions.callApi(vc: self, api: API.teacherDailyWorkApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrLessonPlan = json!["FinalArray"].array
                
                for values in arrLessonPlan! {
                    
                    let dailyWorkModal:DailyWorkModel = DailyWorkModel.init(date: values["Date"].stringValue, standard: values["Standard"].stringValue, className: values["Class"].stringValue, subject: values["Subject"].stringValue, workPlan: (values["WorkPlan"].stringValue).stringFromHTML(values["WorkPlan"].stringValue)!, homeWork: (values["HomeWork"].stringValue).stringFromHTML(values["HomeWork"].stringValue)!, classWork: (values["ClassWork"].stringValue).stringFromHTML(values["ClassWork"].stringValue)!, dayBookId: values["DayBookId"].stringValue)
                    self.arrDailyWork.append(dailyWorkModal)
                    
                    let homeWorkModal:DailyWorkModel = DailyWorkModel.init(date: values["Date"].stringValue, termId: values["TermId"].stringValue, stdId: values["StandardId"].stringValue, clsId: values["ClassId"].stringValue, subId: values["SubjectId"].stringValue)
                    self.arrHomeWorkStatus.append(homeWorkModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callDailyWorkApi()
                })
            }
            self.tblDailyWork.reloadData()
        }
    }
    
    
    // MARK: - Button Click Action
    
    func studentHomeWorkStatus(_ sender:UIButton)
    {
        dailyWorkModal = self.arrHomeWorkStatus[sender.tag]
        if self.arrDailyWork[sender.tag].HomeWork == NSAttributedString.init(string: "") {
            Functions.showAlert(false, Message.noHWFound)
            return
        }
        add(asChildViewController: homeWorkPopupVC, self)
    }
    
    private lazy var homeWorkPopupVC: HomeWorkPopupVC = {
        
        var viewController:HomeWorkPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "HomeWorkPopupVC") as! HomeWorkPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    @IBAction func btnChooseDateAction(_ sender:UIButton)
    {
        btnDate = sender
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!
        selector.optionCurrentDateRange.setStartDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        selector.optionCurrentDateRange.setEndDate((sender.titleLabel?.text?.toDate(dateFormat: "dd/MM/yyyy"))!)
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
    
    @IBAction func btnFilterAction(_ sender:UIButton)
    {
        self.callDailyWorkApi()
    }
    
    @IBAction func btnAddHWCWAction(_ sender:UIButton)
    {
        selectedDailyWorkModel = arrDailyWork[sender.tag]
        self.performSegue(withIdentifier: "AddHWCW", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination
        vc.title = "Add HW/CW"
        vc.customModalTransition = FashionTransition()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension DailyWorkVC:WWCalendarTimeSelectorProtocol
{
    // MARK: - Calender Delegate
    
    func WWCalendarTimeSelectorShouldSelectDate(_ selector: WWCalendarTimeSelector, date: Date) -> Bool {
        if date.timeIntervalSinceNow.sign == .minus || date.toString(dateFormat: "dd/MM/yyyy") == Date().toString(dateFormat: "dd/MM/yyyy") {
            //myDate is earlier than Now (date and time)
            return true
        } else {
            //myDate is equal or after than Now (date and time)
            return false
        }
    }
    
    func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        btnDate.setTitle(date.toString(dateFormat: "dd/MM/yyyy"), for: .normal)
    }
}


extension DailyWorkVC:UITableViewDelegate,UITableViewDataSource
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:DailyWorkCell = tableView.dequeueReusableCell(withIdentifier: "DailyWorkHeaderCell") as! DailyWorkCell
        
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        headerView.btnExpand.transform = .identity
        if section == selectedIndex {
            UIView.animate(withDuration: 0.5, animations: {
                headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
            })
        };
        headerView.displayWorkPlanHeaderData(arrDailyWork[section])
        return arrDailyWork.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50))
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrDailyWork.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            tblDailyWork.estimatedRowHeight = DeviceType.isIpad ? 60 : 50
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblDailyWork.rowHeight == 0 ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:DailyWorkCell = tableView.dequeueReusableCell(withIdentifier: "DailyWorkCell", for: indexPath) as! DailyWorkCell
        cell.delegate = self
        cell.contentView.subviews[0].subviews[0].subviews.forEach{$0.tag = indexPath.section }
        cell.displayWorkPlanData(arrDailyWork[indexPath.section])
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblDailyWork.reloadSections(IndexSet(integersIn: 0...arrDailyWork.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblDailyWork.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}
