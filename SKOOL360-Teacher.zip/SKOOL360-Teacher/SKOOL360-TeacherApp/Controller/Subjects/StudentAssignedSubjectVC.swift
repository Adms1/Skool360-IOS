//
//  StudentAssignedSubjectVC.swift
//  Skool360Teacher
//
//  Created by Sweta on 20/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

var arrClassDetails = [ClassModel]()
var dicSelectedSubjects:NSMutableDictionary = [:]
var arrSelectedSubjects:NSMutableArray = []

class StudentAssignedSubjectVC: UIViewController {
    
    @IBOutlet var tblAssignedSubjects:UITableView!
    @IBOutlet var tblHeaderView:UIView!
    @IBOutlet var btnFooter:UIButton!
    
    var dicClassDetails:NSMutableDictionary = [:]
    var arrSubjectData = [AssignedSubjectModel]()
    
    var strStandard:String!
    var strClass:String!
    var arrClass:NSMutableArray = []
    var arrStandard:NSMutableArray = []
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblAssignedSubjects.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("Assigned Subject")
        
        for data in arrClassDetails {
            let classModal = data
            dicClassDetails.setValue(classModal.ClassID, forKey: "\(classModal.Standard!)-\(classModal.Class!)")
            
            if(!arrClass.contains(classModal.Class!))
            {
                arrClass.add(classModal.Class!)
            }
            if(!arrStandard.contains(classModal.Standard!))
            {
                arrStandard.add(classModal.Standard!)
            }
        }
        
        if arrClassDetails.count > 0 {
            strStandard = arrClassDetails[0].Standard
            strClass = arrClassDetails[0].Class
            self.callStudentAssignedSubjectApi(dicClassDetails.keyedOrValueExist(key: "\(strStandard!)-\(strClass!)") as! String)
            
            self.displayData()
            
        }else{
            view.subviews.forEach({ $0.isHidden = true })
            Functions.showAlert(false, Message.noClassDetailFound)
        }
    }
    
    
    // MARK: - API Calling
    
    func callStudentAssignedSubjectApi(_ strClassID:String)
    {
        let params = ["StaffID":staffID!,
                      "ClassID":strClassID]
        
        print(params)
        
        self.arrSubjectData = []
        arrSelectedSubjects = []
        dicSelectedSubjects = [:]
        
        Functions.callApi(vc: self, api: API.teacherAssignedStudentSubjectApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrStudentSubject = json!["FinalArray"].array
                
                for values in arrStudentSubject! {
                    let subjectModal = AssignedSubjectModel.init(stuID: values["StudentID"].numberValue, stuName: values["StudentName"].stringValue, stuDetails: values["StudentSubject"].arrayObject! as NSArray)
                    self.arrSubjectData.append(subjectModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callStudentAssignedSubjectApi(strClassID)
                })
            }
            self.tblAssignedSubjects.reloadData()
        }
    }
    
    func callInsertAssignedSubject()
    {
        let params = ["ClassID":(dicClassDetails.keyedOrValueExist(key: "\(strStandard!)-\(strClass!)") as! String),
                      "StudentSubjectAry":arrSelectedSubjects.componentsJoined(by: "|")]
        
        print(params)
        
        Functions.callApi(vc: self, api: API.teacherInsertAssignedStudentSubjectApi, params: params) { (json,error) in
            
            if(json != nil) {
                Functions.showAlert(true, Message.subjectAddSuccess)
                
            }else if(error != nil) {
                Functions.showDialog(error?._code == NSURLErrorNotConnectedToInternet ? 1 : 2, finish: {
                    self.callInsertAssignedSubject()
                })
            }
        }
    }
    
    // MARK: - Display Data
    
    func displayData()
    {
        var idx = 1
        let arr = [100,200]
        
        for tag in arr
        {
            idx = 1
            for value in tag == 100 ? arrStandard : arrClass
            {
                self.tblHeaderView.viewWithTag(tag)?.viewWithTag(idx)?.isHidden = false
                
                self.tblHeaderView.viewWithTag(tag)?.viewWithTag(idx+10)?.isHidden = false
                
                (self.tblHeaderView.viewWithTag(tag)?.viewWithTag(idx) as! UIControl).isSelected = idx == 1 ? true : false
                
                (self.tblHeaderView.viewWithTag(tag)?.viewWithTag(idx+10) as! UILabel).text = value as? String
                
                idx += 1
            }
        }
    }
    
    
    // MARK: - Button Click Actions
    
    @IBAction func onValueChange(_ sender: AnyObject) {
        
        let tag:NSInteger = sender.superview!!.tag
        for control in ((self.tblHeaderView.viewWithTag(tag)?.subviews)!.flatMap{$0 as? UIControl}) {
            if control != sender as! UIControl {
                control.isSelected = false
            }else{
                control.isSelected = true
            }
        }
        
        switch tag {
        case 100:
            strStandard = (self.tblHeaderView.viewWithTag(tag)?.viewWithTag(sender.tag+10) as! UILabel).text
        case 200:
            strClass = (self.tblHeaderView.viewWithTag(tag)?.viewWithTag(sender.tag+10) as! UILabel).text
        default:
            break
        }
        self.callStudentAssignedSubjectApi(dicClassDetails.keyedOrValueExist(key: "\(strStandard!)-\(strClass!)") as! String)
    }
    
    
    // MARK: - Button Click Action
    
    @IBAction func insertAssignedSubject()
    {
        self.callInsertAssignedSubject()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension StudentAssignedSubjectVC:UITableViewDataSource,UITableViewDelegate,AssignedSubjectDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        return tblHeaderView
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return (((CGFloat((self.arrSubjectData[indexPath.row].StudentSubject?.count)!/3)) + (CGFloat((self.arrSubjectData[indexPath.row].StudentSubject?.count)!%3))) * 35) + 43
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrSubjectData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:AssignedSubjectCell = tableView.dequeueReusableCell(withIdentifier: "AssignedSubjectCell", for: indexPath) as! AssignedSubjectCell
        cell.delegate = self
        cell.displayData(subjectData: self.arrSubjectData[indexPath.row])
        return cell
    }
    
    // MARK: - AssignedSubject Delegate Action
    
    func changeBtnStatus()
    {
        btnFooter.isHidden = arrSelectedSubjects.count > 0 ? false : true
    }
}
