//
//  DialogBoxSettings.swift
//  DialogBox
//
//  Created by Dhawal on 20/08/17.
//  Copyright © 2017 Dhawal. All rights reserved.
//

import UIKit
import DialogBox

struct BoxAppearanceAlert {
    
    static var _1 : BoxAppearance {
        var appearance = BoxAppearance()
        
        // Layout
        appearance.layout.padding = 0.0
        appearance.layout.cornerRadius = 5.0
        appearance.layout.width = Float(UIScreen.main.bounds.size.width - (DeviceType.isIpad ? 100 : 40))
        
        // Background
        appearance.containerBackground.style = BoxBackgroundStyle.customColor
        
        // Title
//        appearance.title.textAlignment = NSTextAlignment.left
//        appearance.title.textColor = UIColor.darkGray
//        appearance.title.margin = "20|20|20|0"
//        
        // Message
        appearance.message.textAlignment = NSTextAlignment.left
        appearance.message.textColor = UIColor.darkGray
        appearance.message.margin = "20|20|20|0"
        
        // Animation
        appearance.animation = BoxAnimationType.bounce
        
        // Button
        appearance.button.bottomPosition.cornerRadius = 0
        let i:Int = Int(UIScreen.main.bounds.size.width - (DeviceType.isIpad ? 100 : 40) - 80)
        appearance.button.containerMargin = "\(i)|0|10|10"
        appearance.button.bottomPosition.horizontalSpacing = 0.0
        appearance.button.backgroundColor = UIColor.white
        appearance.button.textColor = GetColor.blue
        
        return appearance
    }
    
    static var _2 : BoxAppearance {
        var appearance = BoxAppearance()
        
        // Layout
        appearance.layout.padding = 0.0
        appearance.layout.cornerRadius = 5.0
        appearance.layout.width = Float(UIScreen.main.bounds.size.width - (DeviceType.isIpad ? 100 : 40))
        
        // Background
        appearance.containerBackground.style = BoxBackgroundStyle.customColor
        
        // Title
        appearance.title.textAlignment = NSTextAlignment.left
        appearance.title.textColor = UIColor.darkGray
        appearance.title.margin = "20|20|20|0"
        
        // Message
        appearance.message.textAlignment = NSTextAlignment.left
        appearance.message.textColor = UIColor.darkGray
        appearance.message.margin = "20|0|20|0"
        
        // Animation
        appearance.animation = BoxAnimationType.bounce
        
        // Button
        appearance.button.bottomPosition.cornerRadius = 0
        let i:Int = Int(appearance.layout.width/2)+40
        appearance.button.containerMargin = "\(i)|0|10|10"
        appearance.button.bottomPosition.horizontalSpacing = 0.0
        appearance.button.backgroundColor = UIColor.white
        appearance.button.textColor = GetColor.blue
        
        return appearance
    }
}

struct BoxAppearanceLoading {
    
    static var _1 : BoxAppearance {
        var appearance = BoxAppearance()
        
        appearance.position = BoxPosition.center
        appearance.positionMargin = 20
        appearance.autoDismiss = true
        
        // Layout
        appearance.layout.padding = 10
        appearance.layout.enableShadow = false
        appearance.layout.width = 100.0
        appearance.layout.backgroundColor = UIColor.white
        
        // Background
        appearance.containerBackground.tapToDismiss = true
        appearance.containerBackground.style = BoxBackgroundStyle.customColor
        appearance.containerBackground.color = UIColor.init(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.7)
        
        // Icon
        appearance.icon.type = BoxIconType.loading
        
        // Animation
        appearance.animation = BoxAnimationType.fade
        
        return appearance
    }
}


struct BoxAppearanceScreenMessages {
    
    static var _1 : BoxAppearance {
        var appearance = BoxAppearance()
        
        appearance.position = BoxPosition.center
        appearance.positionMargin = 20
        appearance.autoDismiss = true
        
        // Layout
        appearance.layout.padding = 10
        appearance.layout.enableShadow = false
        appearance.layout.width = Float(UIScreen.main.bounds.size.width - (DeviceType.isIpad ? 100 : 40))
        //        appearance.layout.backgroundColor = UIColor.clear
        
        // Background
        appearance.containerBackground.style = BoxBackgroundStyle.customColor
        //        appearance.containerBackground.color = UIColor.white
        
        // Message
        appearance.message.font = FontHelper.bold(size: DeviceType.isIpad ? 18 : 16)
        appearance.message.textColor = UIColor.darkGray
        
        // Icon
        appearance.icon.type = BoxIconType.image
        appearance.icon.image.name = "wifi"
        appearance.icon.size = CGSize(width: 100, height: 100)
        
        // Animation
        appearance.animation = BoxAnimationType.none
        
        // Button
        let i:Int = DeviceType.isIpad ? 160 : 80
        appearance.button.containerMargin = "\(i)|0|\(i)|0"
        appearance.button.titleFont = FontHelper.bold(size: DeviceType.isIpad ? 20 : 17)
        appearance.button.bottomPosition.cornerRadius = 20.0
        appearance.button.bottomPosition.maximumNoOfButtonsInSingleRow = 1
        appearance.button.backgroundColor = GetColor.blue
        return appearance
    }
    
    static var _2 : BoxAppearance {
        var appearance = BoxAppearance()
        
        appearance.position = BoxPosition.center
        appearance.positionMargin = 20
        appearance.autoDismiss = true
        
        // Layout
        appearance.layout.padding = 10
        appearance.layout.enableShadow = false
        appearance.layout.width = Float(UIScreen.main.bounds.size.width - (DeviceType.isIpad ? 100 : 40))
        //        appearance.layout.backgroundColor = UIColor.clear
        
        // Background
        appearance.containerBackground.style = BoxBackgroundStyle.customColor
        //        appearance.containerBackground.color = UIColor.white
        
        // Message
        appearance.message.font = FontHelper.bold(size: DeviceType.isIpad ? 18 : 16)
        appearance.message.textColor = UIColor.darkGray
        
        // Icon
        appearance.icon.type = BoxIconType.image
        appearance.icon.image.name = "no server"
        appearance.icon.size = CGSize(width: 100, height: 100)
        
        // Animation
        appearance.animation = BoxAnimationType.none
        
        // Button
        let i:Int = DeviceType.isIpad ? 160 : 80
        appearance.button.containerMargin = "\(i)|0|\(i)|0"
        appearance.button.titleFont = FontHelper.bold(size: DeviceType.isIpad ? 20 : 17)
        appearance.button.bottomPosition.cornerRadius = 20.0
        appearance.button.bottomPosition.maximumNoOfButtonsInSingleRow = 1
        appearance.button.backgroundColor = GetColor.blue
        return appearance
    }
}

