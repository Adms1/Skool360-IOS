//
//  AppDelegate.swift
//  Skool360Teacher
//
//  Created by Sweta on 13/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import UserNotifications
import GLNotificationBar

var pushData:[AnyHashable : Any] = [:]
var isFromPush:Bool = false
var isTerminate:Bool = false

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        if(launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] != nil) {
            if let userInfo = launchOptions![UIApplicationLaunchOptionsKey.remoteNotification] as? [AnyHashable : Any] {
                if staffID != nil {
                    isFromPush = true
                    isTerminate = true
                    pushData = userInfo["aps"] as! [AnyHashable : Any]
                    self.rootViewController("DeshboardVC")
                }
            }
        }else if staffID != nil {
            self.rootViewController("DeshboardVC")
        }
        return true
    }
    
    func rootViewController(_ strIdentifier:String)
    {
        let vc = Constants.storyBoard.instantiateViewController(withIdentifier: strIdentifier)
        self.window?.rootViewController = vc
        self.window?.makeKeyAndVisible()
    }
    
    func isUpdateAvailable() throws -> (Bool,String,String) {
        guard let info = Bundle.main.infoDictionary,
            let currentVersion = info["CFBundleShortVersionString"] as? String,
            let proName = info["CFBundleDisplayName"] as? String,
            let identifier = info["CFBundleIdentifier"] as? String,
            let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(identifier)") else {
                throw VersionError.invalidBundleInfo
        }
        let data = try Data(contentsOf: url)
        guard let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as? [String: Any] else {
            throw VersionError.invalidResponse
        }
        if let result = (json["results"] as? [Any])?.first as? [String: Any], let version = result["version"] as? String {
            return (version != currentVersion, proName, version)
        }
        throw VersionError.invalidResponse
    }
    
    func setupForUpdate(_ strAppName:String, _ strAppVersion:String)
    {
        let alert = UIAlertController(title: Message.appUpdateTitle, message: Message.appUpdateMsg.replacingOccurrences(of: "{}", with: strAppName).replacingOccurrences(of: "()", with: strAppVersion), preferredStyle: .alert)
        let yesButton = UIAlertAction(title: "Later", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            exit(0)
        })
        let noButton = UIAlertAction(title: "Update", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            let url:URL = URL(string: "itms://itunes.apple.com/us/app/apple-store/id1445385483?mt=8")!
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        })
        alert.addAction(yesButton)
        alert.addAction(noButton)
        self.window?.windowLevel = UIWindowLevelAlert + 1
        self.window?.makeKeyAndVisible()
        self.window?.rootViewController?.present(alert, animated: true, completion: { })
    }
    
    func registerForPushNotification(_ isRegister:Bool)
    {
        if(isRegister) {
            if #available(iOS 10.0, *) {
                let center = UNUserNotificationCenter.current()
                center.delegate = self
                center.requestAuthorization(options: [.alert, .sound, .badge]) {
                    [weak self] (granted, error) in
                    print("Permission granted: \(granted)")
                    
                    guard granted else {
                        print("Please enable \"Notifications\" from App Settings.")
                        guard let settingsUrl = URL(string: UIApplicationOpenSettingsURLString) else {
                            return
                        }
                        
                        if UIApplication.shared.canOpenURL(settingsUrl) {
                            UIApplication.shared.openURL(settingsUrl)
                        }
                        return
                    }
                    UIApplication.shared.registerForRemoteNotifications()
                }
            } else {
                let settings = UIUserNotificationSettings(types: [.alert, .sound, .badge], categories: nil)
                UIApplication.shared.registerUserNotificationSettings(settings)
                UIApplication.shared.registerForRemoteNotifications()
            }
        } else {
            UIApplication.shared.unregisterForRemoteNotifications()
        }
    }
    
    private lazy var wishVC: WishVC = {
        
        var viewController:WishVC = Constants.storyBoard.instantiateViewController(withIdentifier: "WishVC") as! WishVC
        add(asChildViewController: viewController, (self.window?.rootViewController?.presentedViewController ?? self.window?.rootViewController)!)
        return viewController
    }()
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        DispatchQueue.global().async {
            do {
                let update = try self.isUpdateAvailable().0
                if(update){
                    self.setupForUpdate(try self.isUpdateAvailable().1, try self.isUpdateAvailable().2)
                }
            } catch {
                print(error)
            }
        }
        self.birthday()
    }
    
    func birthday()
    {
        if(birthDate != nil) {
            if(birthdayWiseDone == nil || birthdayWiseDone == false) {
                if(birthDate == Date().toString(dateFormat: "dd/MM/yyyy")) {
                    self.openWishView()
                    UserDefaults.standard.set(true, forKey: "BirthdayWish")
                }
            }
        }
    }
    
    func openWishView()
    {
        add(asChildViewController: self.wishVC, self.window?.rootViewController?.presentedViewController ?? (self.window?.rootViewController)!)
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    // MARK: - Push Notification Delegates
    
    func application(_ application: UIApplication, didRegister notificationSettings: UIUserNotificationSettings) {
        application.registerForRemoteNotifications()
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let token = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        
        NSLog("Token: %@",token);
        
        UserDefaults.standard.set(token, forKey: "DeviceToken")
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        NSLog("Error: %@",error.localizedDescription);
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        
        NSLog("userInfo: %@",userInfo);
        
        if(application.applicationState == .active) {
            let notificationBar:GLNotificationBar = GLNotificationBar.init(title: "", message: (userInfo["aps"] as! [AnyHashable : Any])["alert"] as! String, preferredStyle: .simpleBanner, handler: { (_) in
                self.pushNavigation(userInfo["aps"] as! [AnyHashable : Any])
            })
            notificationBar.notificationSound("solemn", ofType: ".mp3", vibrate: true)
        }else{
            self.pushNavigation(userInfo["aps"] as! [AnyHashable : Any])
        }
    }
    
    func pushNavigation(_ dict:[AnyHashable : Any])
    {
        NSLog("userInfo: %@",dict);
        
        guard staffID != nil else {
            return
        }
        
        isFromPush = true
        pushData = dict
        
        if((dict["category"] as! String).caseInsensitiveCompare("StaffLeave") == .orderedSame){
            if(self.window?.rootViewController?.presentedViewController != nil) {
                if(self.window?.rootViewController?.presentedViewController?.isKind(of: LeaveDetailsVC.classForCoder()))! {
                    NotificationCenter.default.post(name: .refreshData, object: nil)
                    return
                }
            }
            self.rootViewController("DeshboardVC")
            self.window?.rootViewController?.performSegue(withIdentifier: "Leave Details", sender: self)
        }else if((dict["category"] as! String).caseInsensitiveCompare("Birthday") == .orderedSame){
            self.openWishView()
        }
    }
}

@available(iOS 10.0, *)
extension AppDelegate: UNUserNotificationCenterDelegate
{
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert, .badge, .sound])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        self.pushNavigation(response.notification.request.content.userInfo["aps"] as! [AnyHashable : Any])
        completionHandler()
    }
}

