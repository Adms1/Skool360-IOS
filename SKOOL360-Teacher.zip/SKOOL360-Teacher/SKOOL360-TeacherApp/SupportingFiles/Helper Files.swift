//
//  Help Files.swift
//  Chat
//
//  Created by Sweta on 01/08/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import TransitionButton
import Alamofire
import SwiftyJSON

// MARK: - API

var bundleName               = Bundle.main.infoDictionary?["CFBundleName"] as! String

struct API {
    
    static let mainUrl:String           = "http://anandniketanbhadaj.org/appService/5b9a72856992e144c74fc836ed6e76a2/appsUrl"
    //static let hostName:String          = newHostUrl ?? "http://103.250.144.109:8085/" // Live
    static let hostName:String          = "http://103.250.144.109:8085/" // Live
//    static let hostName:String          = "http://192.168.1.19:8086/" // Local
    
    static let baseUrl:String            = "\(hostName)\(bundleName.contains("Skool360") ? "MobileService.asmx/" : "MobileApp_Service.asmx/")"
    static let imageUrl:String          = hostName
    static let iconsLinkUrl:String      = "\(hostName)SKOOL360-Design-Icons/Teacher/"
    static let imagesLinkUrl:String     = "\(hostName)SKOOL360-Category-Images/Teacher/"
    static let fontLinkUrl:String       = "\(hostName)SKOOL360-Fonts/"
    static let downloadUrl:String       = "\(hostName)Backend/"
    
    // MARK:
    
    static let addDeviceDetailStaffApi:String                      = "\(baseUrl)AddDeviceDetailStaff"
    static let deleteDeviceDetailStaffApi:String                   = "\(baseUrl)DeleteDeviceDetailStaff"
    
    static let loginApi:String                                     = "\(baseUrl)StaffLogin"
    static let staffProfileApi:String                              = "\(baseUrl)StaffProfile"
    static let birthdayWishApi:String                              = "\(baseUrl)BirthdayWish"
    static let staffProfileCPwdApi:String                          = "\(baseUrl)StaffChangePassword"
    static let forgotPasswordApi:String                            = "\(baseUrl)ForgetIDPasswordStaff"
    
    static let attendenceApi:String                                = "\(baseUrl)StaffAttendence"
    static let attendenceInsertUpdateApi:String                    = "\(baseUrl)InsertAttendance"
    
    static let teacherTodayScheduleApi:String                      = "\(baseUrl)TeacherTodaySchedule"
    static let teacherLessonPlanSchedule:String                    = "\(baseUrl)TeacherLessonPlanSchedule"
    
    static let teacherDailyWorkApi:String                          = "\(baseUrl)TeacherDailyWork"
    static let updateHWCWApi:String                                = "\(baseUrl)UpdateHWCW"
    static let teacherWorkPlanApi:String                           = "\(baseUrl)TeacherWorkPlan"
    static let teacherUpdateWorkPlanCompletionApi:String           = "\(baseUrl)TeacherUpdateWorkPlanCompletion"
    static let teacherStudentHomeworkStatusApi:String              = "\(baseUrl)TeacherStudentHomeworkStatus"
    static let teacherStudentHomeworkStatusInsertUpdateApi:String  = "\(baseUrl)TeacherStudentHomeworkStatusInsertUpdate"
    
    static let teacherAssignedSubjectApi:String                    = "\(baseUrl)TeacherAssignedSubject"
    static let getAssignedSubjectApi:String                        = "\(baseUrl)GetAssignedSubject"
    static let teacherAssignedStudentSubjectApi:String             = "\(baseUrl)TeacherGetAssignStudentSubject"
    static let teacherInsertAssignedStudentSubjectApi:String       = "\(baseUrl)TeacherInsertAssignStudentSubject"
    
    static let getTermApi:String                                   = "\(baseUrl)GetTerm"
    static let teacherGetTestNameApi:String                        = "\(baseUrl)TeacherGetTestName"
    static let teacherGetTestMarksByTestApi:String                 = "\(baseUrl)TeacherGetTestMarksByTest"
    static let getStandardSectionForMarksApi:String                = "\(baseUrl)GetStandardSectionForMarks"
    static let getMarksApi:String                                  = "\(baseUrl)GetMarks"
    static let getTestForMarksApi:String                           = "\(baseUrl)GetTestForMarks"
    static let insertMarksApi:String                               = "\(baseUrl)InsertMarks"
    
    static let teacherGetTimeTableApi:String                       = "\(baseUrl)TeacherGetTimetable"
    static let insertTimetableApi:String                           = "\(baseUrl)InsertTimetable"
    static let getLectureDetailsApi:String                         = "\(baseUrl)GetLectureDetails"
    static let deleteTimetableApi:String                           = "\(baseUrl)DeleteTimetable"
    
    static let teacherGetTestSyllabusApi:String                    = "\(baseUrl)TeacherGetTestSyllabus"
    static let teacherInsertTestDetailApi:String                   = "\(baseUrl)TeacherInsertTestDetail"
    static let teacherGetTestNameGradeWiseApi:String               = "\(baseUrl)TeacherGetTestNameGradeWise"
    
    static let teacherGetClassSubjectWiseStudentApi:String         = "\(baseUrl)TeacherGetClassSubjectWiseStudent"
    static let ptmTeacherStudentGetDetailApi:String                = "\(baseUrl)PTMTeacherStudentGetDetail"
    static let ptmTeacherStudentInsertDetailApi:String             = "\(baseUrl)PTMTeacherStudentInsertDetail"
    static let ptmDeleteMeeting:String                             = "\(baseUrl)PTMDeleteMeeting"
    
    static let teacherLessonPlanApi:String                         = "\(baseUrl)TeacherLessonPlan"
    //static let pdf:String                                        = "\(downloadUrl)lessonplanpdf.aspx?ID="
    //static let word:String                                       = "\(downloadUrl)LessonPlanWord.aspx?ID="
    static let wordApi:String                                      = "\(downloadUrl)LessonPlanWord_Mobile.aspx?ID="
    static let teacherLessonPlanScheduledHomeworkApi:String        = "\(baseUrl)TeacherLessonPlanScheduledHomework"
    
    static let getStandardSectionApi:String                        = "\(baseUrl)GetStandardSection"
    static let getLeaveDaysApi:String                              = "\(baseUrl)GetLeaveDays"
    static let getHeadApi:String                                   = "\(baseUrl)GetHead"
    static let insertStaffLeaveRequestApi:String                   = "\(baseUrl)InsertStaffLeaveRequest"
    static let getStaffLeaveRequestApi:String                      = "\(baseUrl)GetStaffLeaveRequest"
    static let deleteStaffLeaveApi:String                          = "\(baseUrl)DeleteStaffLeave"
}

// MARK: - Constants

struct Constants {
    
    static let storyBoard              = UIStoryboard.init(name: "Main", bundle: nil)
    static let appDelegate             = UIApplication.shared.delegate as! AppDelegate
    static let window                  = UIApplication.shared.keyWindow
    static let teacherPlaceholder      = UIImage.init(named: "Teacher_Placeholder")
    static let dropDownPlaceholder     = "-Please Select-"
    static let documentsDirectoryURL   = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    static let FontNameArray:[String]  = ["Shruti.ttf", "Shivaji05.ttf", "Gujrati-Saral-1.ttf", "h-saral1.TTF", "h-saral2.TTF", "h-saral3.TTF", "Arvinder.ttf", "H-SARAL0.TTF", "G-SARAL2.TTF", "G-SARAL3.TTF", "G-SARAL4.TTF"]
}

// MARK: - Error Messages

struct Message {
    
    // ----- Login -----
    
    static let userNameError:String             = "Please enter username"
    static let passwordError:String             = "Please enter password"
    static let passwordValidationError:String   = "Password must be 3-12 characters."
    static let userError:String                 = "Invalid username/password"
    
    // ----- Profile -----
    
    static let currentPwdError:String           = "Please enter current password"
    static let currentPwdNotMatchError:String   = "Current password doesn't match."
    static let newPwdError:String               = "Please enter new password"
    static let newCPwdError:String              = "Please enter confirm new password"
    static let newCCPwdError:String             = "Confirm password should be same as new password"
    
    // ----- Request -----
    
    static let subjectError:String              = "Please enter subject"
    static let descriptionError:String          = "Please enter description"
    
    // ----- Marks -----
    
    static let sectionError:String              = "Please select section"
    static let testError:String                 = "Please select subject"
    
    // ----- Leave -----
    
    static let leaveDaysError:String            = "Please select leave days"
    static let headNameError:String             = "Please select head"
    static let reasonError:String               = "Please enter valid reason"
    
    // ----- Add TimeTable -----
    
    static let standardError:String             = "Please choose grade"
    static let classError:String                = "Please choose sections"
    static let subjectIdError:String            = "Please choose subject"
    static let startTimeHourError:String        = "Please choose start time hour"
    static let startTimeMinuteError:String      = "Please choose start time minute"
    static let endTimeHourError:String          = "Please choose end time hour"
    static let endTimeMinuteError:String        = "Please choose end time minute"
    
    // ----- Api Success Message -----
    
    static let attendenceAddSuccess:String         = "Attendance added successfully."
    static let attendenceUpdateSuccess:String      = "Attendance updated successfully."
    static let subjectAddSuccess:String            = "Subjects added successfully."
    static let testAddSuccess:String               = "Test added successfully."
    static let testUpdateSuccess:String            = "Test updated successfully."
    static let requestSentSuccess:String           = "Request sent successfully."
    static let homeworkStatusAddSuccess:String     = "HomeWork status added successfully."
    static let homeworkStatusUpdateSuccess:String  = "HomeWork status updated successfully."
    static let leaveDeleteSuccess:String           = "Leave deleted successfully."
    static let hwCwSuccess:String                  = "HomeWork/ClassWork added successfully."

    // ----- Api Failure Message -----
    
    static let timeOutError:String                 = "Please try again later."
    static let internetFailure:String              = "Network unavailable. \(timeOutError)"
    static let serverError:String                  = "Oops, Skool360 Bhadaj server is down keep calm and try after sometime. Thank you!"
    static let failure:String                      = "Something went wrong."
    static let noRecordFound:String                = "No records are found."
    static let noClassDetailFound:String           = "No class details are found."
    static let noHWFound:String                    = "Please add home work then update status."
    static let cwNotFound:String                   = "Please add classwork"

    // ----- Updation Message -----
    
    static let appUpdateTitle:String               = "Update Available"
    static let appUpdateMsg:String                 = "A new version of {} is available. Please update to version () now."
    
    // ----- Logout Message -----
    
    static let logOutMsg:String                    = "Are you sure you want to logout?"
    static let statusUpdate:String                 = "Are you sure you want to update status?"
    static let deleteLeave:String                  = "Are you sure you want to delete leave?"
}

struct FontType {
    
    static let regularFont:UIFont      = FontHelper.regular(size: DeviceType.isIpad ? 16 : 13)
    static let mediumFont:UIFont       = FontHelper.medium(size: DeviceType.isIpad ? 16 : 13)
    static let boldFont:UIFont         = FontHelper.bold(size: DeviceType.isIpad ? 16 : 13)
}

struct DeviceType {
    
    static let isIphone5:Bool          = { return UIScreen.main.bounds.size.width <= 320 }()
    static let isIpad                  = UIDevice.current.userInterfaceIdiom == .pad
}

struct GetColor {
    
    static var headerColor:UIColor = UIColor.rbg(r: 248, g: 150, b: 36)
    static var shadowColor:UIColor = UIColor.clear.withAlphaComponent(0.2)
    static var blue:UIColor        = UIColor.rbg(r: 23, g: 145, b: 216)
    static var green:UIColor       = UIColor.rbg(r: 107, g: 174, b: 24)
    static var red:UIColor         = UIColor.rbg(r: 255, g: 0, b: 0)
    static var orange:UIColor      = GetColor.headerColor
    static var yellow:UIColor      = UIColor.rbg(r: 216, g: 184, b: 52)
    static var pink:UIColor        = UIColor.rbg(r: 246, g: 68, b: 141)
}

struct FontHelper {
    static func regular(size: CGFloat) -> UIFont {
        return UIFont(name: "HelveticaNeue", size: size)!
    }
    
    static func medium(size: CGFloat) -> UIFont {
        return UIFont(name: "HelveticaNeue-Medium", size: size)!
    }
    
    static func bold(size: CGFloat) -> UIFont {
        return UIFont(name: "HelveticaNeue-Bold", size: size)!
    }
}

// MARK: - Store Data

var staffID: String?
{
    get {
        if let returnValue = UserDefaults.standard
            .object(forKey: "StaffID") as? String {
            return returnValue
        } else {
            return nil //Default value
        }
    }
    set {
        UserDefaults.standard.set(newValue, forKey: "StaffID")
        UserDefaults.standard.synchronize()
    }
}

var newHostUrl: String?
{
    get {
        if let returnValue = UserDefaults.standard
            .object(forKey: "HostUrl") as? String {
            return returnValue
        } else {
            return nil //Default value
        }
    }
    set {
        UserDefaults.standard.set(newValue, forKey: "HostUrl")
        UserDefaults.standard.synchronize()
    }
}

var birthDate: String?
{
    get {
        if let returnValue = UserDefaults.standard
            .object(forKey: "DOB") as? String {
            return returnValue
        } else {
            return nil //Default value
        }
    }
    set {
        UserDefaults.standard.set(newValue, forKey: "DOB")
        UserDefaults.standard.synchronize()
    }
}

var birthdayWiseDone: Bool?
{
    get {
        if let returnValue = UserDefaults.standard
            .object(forKey: "BirthdayWish") as? Bool {
            return returnValue
        } else {
            return nil //Default value
        }
    }
    set {
        UserDefaults.standard.set(newValue, forKey: "BirthdayWish")
        UserDefaults.standard.synchronize()
    }
}

var deviceToken: String?
{
    get {
        if let returnValue = UserDefaults.standard
            .object(forKey: "DeviceToken") as? String {
            return returnValue
        } else {
            return nil //Default value
        }
    }
    set {
        UserDefaults.standard.set(newValue, forKey: "DeviceToken")
        UserDefaults.standard.synchronize()
    }
}

// MARK: - Functions

func addBorder(_ obj:AnyObject)
{
    obj.layer.cornerRadius = 5.0
    obj.layer.borderColor  = GetColor.blue.cgColor
    obj.layer.borderWidth  = 0.5
}

func add(asChildViewController viewController: UIViewController, _ selfVC:UIViewController) {
    
    selfVC.addChildViewController(viewController)
    selfVC.view.addSubview(viewController.view)
    viewController.view.frame = selfVC.view.bounds
    viewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    viewController.didMove(toParentViewController: selfVC)
}

// MARK: - Class

class CustomButton: UIButton {
    
    @IBInspectable open var strImageName: String = "" {
        didSet {
            self.loadIconsFromLocal(strImageName)
        }
    }
}

class SquareButton: UIButton {
    
    override func awakeFromNib() {
        addBorder(self)
    }
}

class ShadowButton: UIButton {
    
    @IBInspectable open var strImageName: String = "" {
        didSet {
            self.loadIconsFromLocal(strImageName)
        }
    }
    
    override func awakeFromNib() {
        self.addShadowWithRadiusForButton(3, 0)
    }
}

class AnimatedButton: TransitionButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = GetColor.blue
        self.setTitle("LOGIN", for: .normal)
        self.setTitleColor(.white, for: .normal)
        self.titleLabel?.font = FontHelper.bold(size: 16)
        self.cornerRadius = 5.0
        self.spinnerColor = .white
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class CustomImageView: UIImageView {
    
    @IBInspectable open var strImageName: String = "" {
        didSet {
            self.loadIconsFromLocal(strImageName)
        }
    }
}

class PlaceHolderImageView: UIImageView {
    
    @IBInspectable open var strImageName: String!
    
    override func awakeFromNib() {
        self.image = UIImage.init(named: strImageName)?.withRenderingMode(.alwaysTemplate)
    }
}

class RoundedImageView: UIImageView {
    
    @IBInspectable open var borderColor: UIColor = UIColor.white {
        didSet {
            self.layer.borderColor  = borderColor.cgColor
        }
    }
    
    @IBInspectable open var strImageName: String = "" {
        didSet {
            self.loadIconsFromLocal(strImageName)
        }
    }
    
    override func awakeFromNib() {
        self.layer.cornerRadius = self.frame.size.width/2
        self.clipsToBounds      = true
        self.layer.borderWidth  = 2.0
    }
}

class CustomTextView: UITextView {
    
    override func awakeFromNib() {
        addBorder(self)
    }
}

class CustomTextField: UITextField {
    
    override func awakeFromNib() {
        addBorder(self)
    }
}

class ErrorVC: UIViewController {
    
    override func viewDidLoad() {
        
    }
}

class CustomLable: UILabel {
    
    @IBInspectable var topInset: CGFloat = 5.0
    @IBInspectable var bottomInset: CGFloat = 5.0
    @IBInspectable var leftInset: CGFloat = 5.0
    @IBInspectable var rightInset: CGFloat = 5.0
    
    override func drawText(in rect: CGRect) {
        let insets = UIEdgeInsets(top: topInset, left: leftInset, bottom: bottomInset, right: rightInset)
        super.drawText(in: UIEdgeInsetsInsetRect(rect, insets))
    }
    
    override var intrinsicContentSize: CGSize {
        get {
            var contentSize = super.intrinsicContentSize
            contentSize.height += topInset + bottomInset
            contentSize.width += leftInset + rightInset
            return contentSize
        }
    }
    
    override func awakeFromNib() {
        self.layer.cornerRadius = 3.0
        self.clipsToBounds      = true
        
        self.layer.borderColor  = UIColor.lightGray.withAlphaComponent(0.5).cgColor
        self.layer.borderWidth  = 0.5
    }
}

class HeaderView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(loadViewFromNib())
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        addSubview(loadViewFromNib())
    }
    
    private func loadViewFromNib() -> UIView {
        let headerView:UIView = UINib(nibName: "HeaderView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
        headerView.frame = self.bounds
        headerView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        headerView.addShadowWithRadius(2, 0)
        return headerView
    }
}

var isFromPTM:Bool = false
class CustomViewController: UIViewController {
    
    var selectedIndex:NSInteger = -1
    var btnDate:UIButton!
    var finishedLoadingInitialTableCells = false
    
    override func viewDidAppear(_ animated: Bool) {
        isFromPTM = false
        self.initalization()
    }
    
    func initalization()
    {
        if(!(self is DeshboardVC)) {
            (self.view.subviews[0].subviews[0].subviews[0] as! UIButton).setTitle(self.title?.uppercased(), for: .normal)
            (self.view.subviews[0].subviews[0].subviews[1] as! UIButton).addTarget(self, action: #selector(logOut), for: .touchUpInside)
            (self.view.subviews[0].subviews[0].subviews[2] as! UIButton).addTarget(self, action: #selector(back), for: .touchUpInside)
        }
    }
    
    @IBAction func logOut()
    {
        Functions.showCustomAlert("Logout", Message.logOutMsg) { (_) in
            let params = ["StaffID" : staffID!,
                          "DeviceID" : UIDevice.current.identifierForVendor!.uuidString]
            
            Functions.callApi(vc: self, api: API.deleteDeviceDetailStaffApi, params: params) { (json,error) in
                if(json != nil){
                    Constants.appDelegate.registerForPushNotification(false)
                    UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
                    Constants.appDelegate.rootViewController("ViewController")
                }
            }
        }
    }
    
    //    @objc(tableView:willDisplayCell:forRowAtIndexPath:) func tableView(_ tableView: UITableView, willDisplay cell:
    //        UITableViewCell, forRowAt indexPath: IndexPath) {
    //        let rotationAngleInRadians = 360.0 * CGFloat(M_PI/360.0)
    //        let rotationTransform = CATransform3DMakeRotation(rotationAngleInRadians, -500, 100, 0)
    ////        let rotationTransform = CATransform3DMakeRotation(rotationAngleInRadians, 0, 0, 1)
    //        cell.layer.transform = rotationTransform
    //        UIView.animate(withDuration: 1.0, animations: {cell.layer.transform = CATransform3DIdentity})
    //    }
    
    //    @objc(tableView:willDisplayCell:forRowAtIndexPath:) func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    //    {
    //        //1. Setup the CATransform3D structure
    //        var rotation = CATransform3DMakeRotation( CGFloat((90.0 * M_PI)/180), 0.0, 0.7, 0.4);
    //        rotation.m34 = 1.0 / -600
    //
    //
    //        //2. Define the initial state (Before the animation)
    //        cell.layer.shadowOffset = CGSize(width: 10.0, height: 10.0)
    //        cell.alpha = 0;
    //
    //        cell.layer.transform = rotation;
    //        cell.layer.anchorPoint = CGPoint(x: 0.0, y: 0.5)
    //
    //
    //        //3. Define the final state (After the animation) and commit the animation
    //        cell.layer.transform = rotation
    //        UIView.animate(withDuration: 0.8, animations:{cell.layer.transform = CATransform3DIdentity})
    //        cell.alpha = 1
    //        cell.layer.shadowOffset = CGSize(width: 0, height: 0)
    //        UIView.commitAnimations()
    //
    //    }
    
    //    @objc(tableView:willDisplayCell:forRowAtIndexPath:) func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
    //        //if (shownIndexes.contains(indexPath) == false) {
    //            //shownIndexes.append(indexPath)
    //
    ////            cell.transform = CGAffineTransform(translationX: 0, y: 0)
    ////            cell.layer.shadowColor = UIColor.black.cgColor
    ////            cell.layer.shadowOffset = CGSize(width: 10, height: 10)
    ////            cell.alpha = 0
    ////
    ////            UIView.beginAnimations("rotation", context: nil)
    ////            UIView.setAnimationDuration(0.5)
    ////            cell.transform = CGAffineTransform(translationX: 0, y: 0)
    ////            cell.alpha = 1
    ////            cell.layer.shadowOffset = CGSize(width: 0, height: 0)
    ////            UIView.commitAnimations()
    //        //}
    //
    //        cell.layer.transform = CATransform3DMakeScale(0.1,0.1,1)
    //        UIView.animate(withDuration: 0.3, animations: {
    //            cell.layer.transform = CATransform3DMakeScale(1.05,1.05,1)
    //        },completion: { finished in
    //            UIView.animate(withDuration: 0.1, animations: {
    //                cell.layer.transform = CATransform3DMakeScale(1,1,1)
    //            })
    //        })
    //    }
    
    @IBAction func back()
    {
        self.dismiss(animated: true, completion: nil)
    }
}

// MARK: - Extensions

extension String {
    func isValidEmail() -> Bool {
        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
        return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: characters.count)) != nil
    }
    
    func toDate( dateFormat format  : String) -> Date
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        if let date = dateFormatter.date(from: self)
        {
            return date
        }
        return Date()
    }
    
    func removeHtmlFromString(inPutString: String) -> String{
        var str:String = inPutString
        str = str.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
        str = str.replacingOccurrences(of: "&nbsp;", with: "")
        return str.components(separatedBy: .whitespacesAndNewlines).joined()
    }
    
    func stringFromHTML(_ string: String?) -> NSAttributedString?
    {
        guard let data = data(using: .utf8) else { return NSAttributedString() }
        do{
            let attrStr:NSAttributedString = try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
            
            let newStr:NSMutableAttributedString = attrStr.mutableCopy() as! NSMutableAttributedString
            
            var range:NSRange = (newStr.string as NSString).rangeOfCharacter(from: .whitespacesAndNewlines)
            
            // Trim leading characters from character set.
            while range.length != 0 && range.location == 0 {
                newStr.replaceCharacters(in: range, with: "")
                range = (newStr.string as NSString).rangeOfCharacter(from: .whitespacesAndNewlines)
            }
            
            // Trim trailing characters from character set.
            range = (newStr.string as NSString).rangeOfCharacter(from: .whitespacesAndNewlines, options: .backwards)
            while range.length != 0 && NSMaxRange(range) == newStr.length {
                newStr.replaceCharacters(in: range, with: "")
                range = (newStr.string as NSString).rangeOfCharacter(from: .whitespacesAndNewlines, options: .backwards)
            }
            return NSAttributedString.init(attributedString: newStr)
        } catch
        {
            print("html error\n",error)
        }
        return nil
    }
}

extension NSMutableDictionary {
    func sortedDictionary(_ dict:NSMutableDictionary)->([String],[String]) {
        
        let values = (dict.allKeys as! [String]).sorted {
            (s1, s2) -> Bool in return s1.localizedStandardCompare(s2) == .orderedAscending
        }
        
        var sortedArray:[String] = []
        for item in values {
            sortedArray.append(item.components(separatedBy: "-").last!)
        }
        return (values, sortedArray)
    }
    
    func keyedOrValueExist(key: Key) -> Value? {
        return self[key] ?? nil
    }
}

extension Date {
    func toString( dateFormat format  : String ) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
}

extension UIColor {
    class func rbg(r: CGFloat, g: CGFloat, b: CGFloat) -> UIColor {
        let color = UIColor.init(red: r/255, green: g/255, blue: b/255, alpha: 1)
        return color
    }
}

extension UIView {
    func shake() {
        let animation = CAKeyframeAnimation(keyPath: "transform.translation.x")
        animation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
        animation.duration = 0.6
        animation.values = [-20.0, 20.0, -20.0, 20.0, -10.0, 10.0, -5.0, 5.0, 0.0 ]
        layer.add(animation, forKey: "shake")
    }
    
    func roundCorners(_ corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
    
    func addShadowWithRadius(_ qty:CGFloat, _ radius:CGFloat)
    {
        if radius > 0 {
            self.layer.cornerRadius = 5.0
        }
        self.layer.shadowColor = GetColor.shadowColor.cgColor
        self.layer.shadowRadius = qty
        self.layer.shadowOffset = CGSize(width:0.0,height:qty)
        self.layer.shadowOpacity = 1.0
    }
}

extension UIButton {
    func makeSemiCircle(){
        let circlePath = UIBezierPath.init(arcCenter: CGPoint(x:self.bounds.size.width / 2, y:0), radius: self.bounds.size.height, startAngle: 0.0, endAngle: 180, clockwise: true)
        let circleShape = CAShapeLayer()
        circleShape.path = circlePath.cgPath
        self.layer.mask = circleShape
    }
    
    func addShadowWithRadiusForButton(_ qty:CGFloat, _ radius:CGFloat)
    {
        self.addShadowWithRadius(qty, radius)
    }
    
    func loadIconsFromLocal(_ iconName:String)
    {
        let fileURL = Constants.documentsDirectoryURL.appendingPathComponent("\(iconName).png")
        
        if FileManager.default.fileExists(atPath: fileURL.path) {
            self.setImage(UIImage.init(contentsOfFile: fileURL.path), for: .normal)
            return
        }
        
        let url:URL = URL.init(string: "\(API.iconsLinkUrl)\(iconName).png")!
        
        let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
        
        Alamofire.download(
            url,
            method: .get,
            parameters: nil,
            encoding: JSONEncoding.default,
            headers: nil,
            to: destination).downloadProgress(closure: { (progress) in
                
            }).response { response in
                
                if let localURL = response.destinationURL {
                    print(localURL)
                    self.setImage(UIImage.init(contentsOfFile: localURL.path), for: .normal)
                }
        }
    }
}

extension UIImageView {
    
    public func setImageWithFadeFromURL(url: URL, placeholderImage placeholder: UIImage? = nil, animationDuration: Double = 0.3, finish:@escaping (Void)->Void) {
        
        self.sd_setImage(with: url, placeholderImage: placeholder, options: .transformAnimatedImage){ (fetchedImage, error, cacheType, url) in
            if error != nil {
                print("Error loading Image from URL: \(String(describing: url))\n(error?.localizedDescription)")
                self.image = placeholder
                return
            }
            self.alpha = 0
            self.image = fetchedImage
            UIView.transition(with: self, duration: (cacheType == .none ? animationDuration : 0), options: .transitionCrossDissolve, animations: { () -> Void in
                self.alpha = 1
            }, completion: { (finished: Bool) in
                //                finish
            })
        }
    }
    
    public func cancelImageLoad() {
        self.sd_cancelCurrentImageLoad()
    }
    
    func getImagesfromLocal(_ strImageName:String)
    {
        let strNewImageName:String = "\(strImageName.replacingOccurrences(of: "/", with: "_")).png"
        
        let fileURL = Constants.documentsDirectoryURL.appendingPathComponent("\(strNewImageName)")
        
        if FileManager.default.fileExists(atPath: fileURL.path) {
            print("Image Is there")
            self.image = UIImage.init(contentsOfFile: fileURL.path)
        }else{
            self.storeImages(fileURL,strNewImageName)
        }
    }
    
    func storeImages(_ imageUrl:URL ,_ imageName:String)
    {
        let strImageLink:String = "\(API.imagesLinkUrl)\(imageName.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!)"
        
        self.sd_setImage(with: URL.init(string: strImageLink), completed: { (fetchedImage, error, _, _) in
            
            if(error != nil){
                return
            }
            
            do {
                try UIImagePNGRepresentation(fetchedImage!)!.write(to: imageUrl)
                print("Image added successfully")
            } catch {
                print(error)
            }
        })
    }
    
    func loadIconsFromLocal(_ iconName:String)
    {
        let fileURL = Constants.documentsDirectoryURL.appendingPathComponent("\(iconName).png")
        
        if FileManager.default.fileExists(atPath: fileURL.path) {
            self.image = UIImage.init(contentsOfFile: fileURL.path)
            return
        }
        
        let url:URL = URL.init(string: "\(API.iconsLinkUrl)\(iconName).png")!
        
        let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
        
        Alamofire.download(
            url,
            method: .get,
            parameters: nil,
            encoding: JSONEncoding.default,
            headers: nil,
            to: destination).downloadProgress(closure: { (progress) in
                
            }).response { response in
                
                if let localURL = response.destinationURL {
                    print(localURL)
                    self.image = UIImage.init(contentsOfFile: localURL.path)
                }
        }
    }
}

extension UIViewController {
    func getDynamicFont()
    {
        var font:CGFont!
        var error: Unmanaged<CFError>?
        var success:Bool = false
        
        for fontName in Constants.FontNameArray {
            
            //let strFontName:String = "\(fontName).ttf"
            let url:URL = URL.init(string: "\(API.fontLinkUrl)\(fontName)")!
            let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
            
            Alamofire.download(
                url,
                method: .get,
                parameters: nil,
                encoding: JSONEncoding.default,
                headers: nil,
                to: destination).downloadProgress(closure: { (progress) in
                    
                }).response { response in
                    
                    if let localURL = response.destinationURL {
                        //print(localURL)
                        
                        let data = try? Data(contentsOf: localURL)
                        font = CGFont(CGDataProvider(data: data! as CFData)!)
                        
                        success = CTFontManagerRegisterGraphicsFont(font, &error)
                        if !success {
                            print("Error loading font. Font is possibly already registered.")
                        }
                    }
            }
        }
    }
}

extension UICollectionViewCell {
    func scaleWithBounceAnimation(){
        self.transform = CGAffineTransform(scaleX: 0, y: 0)
        UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 10.0, options: UIViewAnimationOptions(rawValue: 0), animations: {
            self.transform = CGAffineTransform.identity
        })
    }
}

extension Notification.Name {
    static let refreshData          = Notification.Name(
        rawValue: "refreshData")
}


// MARK: - Enums

enum ErrorType {
    case userName, password, confirmPassword
    case subject, description
}

enum VersionError: Error {
    case invalidResponse, invalidBundleInfo
}
