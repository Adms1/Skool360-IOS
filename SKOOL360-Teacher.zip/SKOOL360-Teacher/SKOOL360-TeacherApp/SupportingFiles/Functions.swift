//
//  Functions.swift
//  FirebaseChatDemo
//
//  Created by Sweta on 26/07/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import DialogBox
import Alamofire
import SwiftyJSON

class Functions: NSObject {
    
    class func getDeshBoardCategory() -> [String]
    {
        switch bundleName {
        case "Shilaj (Teacher)":
            return ["Schedule","Subjects","Time Table","Attendance","Lesson Plan","Home Work","Test/Syllabus","Marks","PTM"]
        default:
            return ["Schedule","Subjects","Time Table","Attendance","Daily Work","Test/Syllabus","Marks","Leave Details","Settings"]
        }
    }
    
    class func callApi(vc:UIViewController, api:String, params:[String:String] ,completionHandler:@escaping (JSON?,Error?) -> Void)
    {
        let headers = [
            "Content-Type": "application/x-www-form-urlencoded"
        ]
        
        let dialogBox = DialogBox.init()
        if api != API.loginApi {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                dialogBox.show(title: nil, message: "Loading...", boxApp: BoxAppearanceLoading._1)
            }
        }
        
        Alamofire.request(api, method: .post, parameters: params, headers: headers).validate().responseJSON { response in
            switch response.result {
            case .success(let value):
                
                let json = JSON(value)
                print(json)
                
                if(json["Success"] == "True" || json["succcess"] == "1") {
                    vc.childViewControllers.forEach{$0.view.removeFromSuperview()}
                    vc.childViewControllers.forEach{$0.removeFromParentViewController()}
                    completionHandler(json,nil)
                }
                else {
                    if api == API.loginApi {
                        self.showAlert(false, Message.userError)
                    }else if api == API.insertStaffLeaveRequestApi || api == API.forgotPasswordApi || api == API.teacherInsertTestDetailApi {
                        self.showAlert(false, (json["Message"].stringValue))
                    }else if(api == API.attendenceInsertUpdateApi || api == API.teacherStudentHomeworkStatusInsertUpdateApi || api == API.teacherInsertAssignedStudentSubjectApi || api == API.teacherInsertTestDetailApi){
                        self.showAlert(false, Message.failure)
                    }else if(api != API.teacherGetTestNameGradeWiseApi && api != API.getTestForMarksApi && api != API.getStandardSectionForMarksApi){
                        //self.showAlert(false, Message.noRecordFound)
                        let errorPopupVC:ErrorVC = Constants.storyBoard.instantiateViewController(withIdentifier: "ErrorVC") as! ErrorVC
                        add(asChildViewController: errorPopupVC, vc)
                    }
                    completionHandler(nil,nil)
                }
                
                if api != API.loginApi {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        dialogBox.dismiss()
                    }
                }
                
            case .failure(let error):
                if api != API.loginApi {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        dialogBox.dismiss()
                    }
                }
                
                if error._code == NSURLErrorNotConnectedToInternet || error._code == -1004 || error._code == -1011 {
                    completionHandler(nil,error)
                }else if error._code == NSURLErrorTimedOut {
                    self.showAlert(false, Message.timeOutError)
                    if api == API.loginApi {
                        completionHandler(nil,nil)
                    }
                }
            }
        }
    }
    
    class func downloadFileApi(url:URL, completion:@escaping (URL) -> Void)
    {
        let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
        
        Alamofire.download(
            url,
            method: .get,
            parameters: nil,
            encoding: JSONEncoding.default,
            headers: nil,
            to: destination).downloadProgress(closure: { (progress) in
                
                if(progress.totalUnitCount > 0) {
                    let str:String = "\((progress.completedUnitCount * 100)/(progress.totalUnitCount)) %"
                    
                    let per:Float = (str as NSString).floatValue
                    let progress:Float = per/100
                    
                    //ZVProgressHUD.show(title: str, progress: progress)
                }
            }).response { response in
                
                //ZVProgressHUD.dismiss()
                if let localURL = response.destinationURL {
                    print(localURL)
                    completion(localURL)
                }
        }
    }
    
    class func showDialog(_ dialogueNo:Int, finish:@escaping ()->Void)
    {
        DialogBox.show(title: nil, message: dialogueNo == 1 ? Message.internetFailure : Message.serverError, superView: Constants.window , boxApp: dialogueNo == 1 ? BoxAppearanceScreenMessages._1 : BoxAppearanceScreenMessages._2, buttonTitle: "Try Again", buttonAppearance: nil) {
            finish()
        }
    }
    
    class func showAlert(_ isSuccess:Bool,_ msg:String) -> Bool
    {
        let dialogBox = DialogBox.init()
        dialogBox.addButton(title: "OK", buttonAppearance: nil) {
            print("Pressed OK")
        }
        dialogBox.show(title: nil, message: msg, boxApp: BoxAppearanceAlert._1)
        return false
    }
    
    class func showCustomAlert(_ title:String, _ msg:String, isDone:@escaping (Bool) -> Void)
    {
        let dialogBox = DialogBox.init()
        dialogBox.addButton(title: "YES", buttonAppearance: nil) {
            print("Pressed YES")
            isDone(true)
        }
        dialogBox.addButton(title: "NO", buttonAppearance: nil) {
            print("Pressed NO")
        }
        dialogBox.show(title: title, message: msg, boxApp: BoxAppearanceAlert._2)
    }
}
