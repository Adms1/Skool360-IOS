//
//  ServiceModels.swift
//  Skool360Teacher
//
//  Created by ADMS on 14/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

class ClassModel {
    
    var StandardID:String?
    var ClassID:String?
    var Standard:String?
    var Class:String?
    
    init(standardID:String, classID:String, standard:String, cls:String)
    {
        self.StandardID = standardID
        self.ClassID = classID
        self.Standard = standard
        self.Class = cls
    }
}

class ClsModel {
    var Class:String?
    init(cls:String)
    {
        self.Class = cls
    }
}

class StdModel {
    var Standard:String?
    init(standard:String)
    {
        self.Standard = standard
    }
}

class StudentAttendenceModel {
    
    var StandardID:NSNumber?
    var ClassID:NSNumber?
    var AttendenceStatus:String?
    var StudentID:NSNumber?
    var StudentName:String?
    var AttendanceID:NSNumber?
    var StudentImage:String?
    
    var TotalOnDuty:NSNumber?
    var ShilajModalValue:ShilajStudentAttendenceModel?
    
    var Date:String?
    
    init(attendenceStatus:String, studentID:NSNumber, studentName:String, attendenceID:NSNumber,studentImage:String)
    {
        self.AttendenceStatus = attendenceStatus
        self.StudentID = studentID
        self.StudentName = studentName
        self.AttendanceID = attendenceID
        self.StudentImage = studentImage
    }
    
    init(standardID:NSNumber, classID:NSNumber, Date:String)
    {
        self.StandardID = standardID
        self.ClassID = classID
        self.Date = Date
    }
    
    init(ShilajModal:ShilajStudentAttendenceModel)
    {
        self.ShilajModalValue = ShilajModal
    }
    
    init(ShilajModal:ShilajStudentAttendenceModel, TotalOnDuty:NSNumber)
    {
        self.ShilajModalValue = ShilajModal
        self.TotalOnDuty = TotalOnDuty
    }
}

class ShilajStudentAttendenceModel {
    
    var Total:NSNumber?
    var TotalAbsent:NSNumber?
    var TotalPresent:NSNumber?
    var TotalLeave:NSNumber?
    
    init(Total:NSNumber, TotalAbsent:NSNumber, TotalPresent:NSNumber, TotalLeave:NSNumber)
    {
        self.Total = Total
        self.TotalAbsent = TotalAbsent
        self.TotalPresent = TotalPresent
        self.TotalLeave = TotalLeave
    }
}

class ScheduleModel {
    
    var Lecture:NSNumber?
    var Standard:String?
    var ClassName:String?
    var Subject:String?
    var Timing:String?
    
    init(lecture:NSNumber, standard:String, classname:String, subject:String, timing:String)
    {
        self.Lecture = lecture
        self.Standard = standard
        self.ClassName = classname
        self.Subject = subject
        self.Timing = timing
    }
    
    init(standard:String, classname:String, subject:String)
    {
        self.Standard = standard
        self.ClassName = classname
        self.Subject = subject
    }
}

class AssignedSubjectModel {
    
    var StudentID:NSNumber?
    var StudentName:String?
    var StudentSubject:NSArray?
    
    var CheckedStatus:String?
    var Subject:String?
    var SubjectID:NSNumber?
    
    init(stuID:NSNumber, stuName:String, stuDetails:NSArray)
    {
        self.StudentID = stuID
        self.StudentName = stuName
        self.StudentSubject = stuDetails
    }
    
    init(chkStatus:String, subject:String, subjectID:NSNumber)
    {
        self.CheckedStatus = chkStatus
        self.Subject = subject
        self.SubjectID = subjectID
    }
}

class MarksModel {
    
    var StudentID:NSNumber?
    var StudentName:String?
    var GRNO:String?
    var Percentage:String?
    var TotalGained:NSNumber?
    var Total:NSNumber?
    var SubjectData = [MarksModel]()
    
    var Marks:String?
    var Subject:String?
    
    init(stuID:NSNumber, stuName:String, grno:String, per:String, outOff:NSNumber, total:NSNumber,subjectData:[MarksModel])
    {
        self.StudentID = stuID
        self.StudentName = stuName
        self.GRNO = grno
        self.Percentage = per
        self.TotalGained = outOff
        self.Total = total
        self.SubjectData = subjectData
    }
    
    init(marks:String, subject:String)
    {
        self.Marks = marks
        self.Subject = subject
    }
}

class TimeTableModel {
    
    var Lecture:String?
    var LectureID:String?
    var Subject:String?
    var StandardClass:String?
    //    var ProxyStatus:NSNumber?
    
    init(lecture:String, lectureId:String, subject:String, stdClass:String?)
    {
        self.Lecture = lecture
        self.LectureID = lectureId
        self.Subject = subject
        self.StandardClass = stdClass
        //self.ProxyStatus = proStatus
    }
}

class SyllabusModel {
    
    var TestName:String?
    var TSMasterID:NSNumber?
    var StandardClass:String?
    var SectionID:NSNumber?
    var Subject:String?
    var SubjectID:NSNumber?
    var TestDate:String?
    var TestID:NSNumber?
    var TestSyllabus:String?
    var SectionIDS:String?
    
    init(testName:String,TSmasterID:NSNumber, stdClass:String, sectionID:NSNumber, subject:String, subjectID:NSNumber, testDate:String, testID:NSNumber,sectionIDS:String)
    {
        self.TestName = testName
        self.TSMasterID = TSmasterID
        self.StandardClass = stdClass
        self.SectionID = sectionID
        self.Subject = subject
        self.SubjectID = subjectID
        self.TestDate = testDate
        self.TestID = testID
        self.SectionIDS = sectionIDS
    }
    
    init(testSyllabus:String)
    {
        self.TestSyllabus = testSyllabus
    }
    
    init(testName:String, testID:NSNumber)
    {
        self.TestName = testName
        self.TestID = testID
    }
}

class StudentModel {
    
    var StudentID:String?
    var StudentName:String?
    var GRNO:String?
    var Status:Bool?
    
    var MarkID:String?
    var Mark:String?
    
    init(stuID:String, stuName:String, grno:String, status:Bool)
    {
        self.StudentID = stuID
        self.StudentName = stuName
        self.GRNO = grno
        self.Status = status
    }
    
    init(stuID:String, stuName:String, grno:String, markId:String, mark:String)
    {
        self.StudentID = stuID
        self.StudentName = stuName
        self.GRNO = grno
        self.MarkID = markId
        self.Mark = mark
    }
}

class InboxSentModel {
    
    var ReadStatus:String?
    var UserName:String?
    var FromID:NSNumber?
    var ToID:NSNumber?
    var SubjectLine:String?
    var MessageID:NSNumber?
    var MeetingDate:String?
    var Description:String?
    
    init(readStatus:String, userName:String, fromID:NSNumber, toID:NSNumber, subLine:String, msgID:NSNumber, meetingDate:String, description:String)
    {
        self.ReadStatus = readStatus
        self.UserName = userName
        self.FromID = fromID
        self.ToID = toID
        self.SubjectLine = subLine
        self.MessageID = msgID
        self.MeetingDate = meetingDate
        self.Description = description
    }
}

class LessonPlanModel {
    
    var ID:NSNumber?
    var ChapterNo:String?
    var ChapterName:String?
    
    init(id:NSNumber, chapterNo:String, chapterName:String)
    {
        self.ID = id
        self.ChapterNo = chapterNo
        self.ChapterName = chapterName
    }
}

class LessonPlanScheduleModel {
    
    var Date:String!
    var Standard:String?
    var ClassName:String?
    var Subject:String?
    var HomeWork:NSAttributedString?
    var ChapterName:NSAttributedString?
    var Objective:NSAttributedString?
    var AssessmentQue:NSAttributedString?
    var TermID:String!
    var StandardID:String!
    var ClassID:String!
    var SubjectID:String!
    
    init(date:String, standard:String, className:String, subject:String, homeWork:NSAttributedString, chapterName:NSAttributedString, objective:NSAttributedString, assQue:NSAttributedString)
    {
        self.Date = date
        self.Standard = standard
        self.ClassName = className
        self.Subject = subject
        self.HomeWork = homeWork
        self.ChapterName = chapterName
        self.Objective = objective
        self.AssessmentQue = assQue
    }
    
    init(date:String, termId:String, stdId:String, clsId:String, subId:String)
    {
        self.Date = date
        self.TermID = termId
        self.StandardID = stdId
        self.ClassID = clsId
        self.SubjectID = subId
    }
}

class HomeWorkStatusModel {
    
    var StudentID:String?
    var StudentName:String?
    var HomeWorkID:String?
    var HomeWorkDetailID:String?
    var HomeWorkStatus:NSInteger?
    
    init(stuId:String, stuName:String, homeWorkId:String, homeWorkDetailId:String, homeWorkStatus:NSInteger)
    {
        self.StudentID = stuId
        self.StudentName = stuName
        self.HomeWorkID = homeWorkId
        self.HomeWorkDetailID = homeWorkDetailId
        self.HomeWorkStatus = homeWorkStatus
    }
}

class DailyWorkModel {
    
    var Date:String!
    var Standard:String?
    var ClassName:String?
    var Subject:String?
    var WorkPlan:NSAttributedString?
    var HomeWork:NSAttributedString?
    var ClassWork:NSAttributedString?
    var TermID:String!
    var StandardID:String!
    var ClassID:String!
    var SubjectID:String!
    
    init(date:String, standard:String, className:String, subject:String, workPlan:NSAttributedString, homeWork:NSAttributedString, classWork:NSAttributedString)
    {
        self.Date = date
        self.Standard = standard
        self.ClassName = className
        self.Subject = subject
        self.WorkPlan = workPlan
        self.HomeWork = homeWork
        self.ClassWork = classWork
    }
    
    init(date:String, termId:String, stdId:String, clsId:String, subId:String)
    {
        self.Date = date
        self.TermID = termId
        self.StandardID = stdId
        self.ClassID = clsId
        self.SubjectID = subId
    }
}

class LeaveModel {
    
    var LeaveID:String!
    var CreateDate:String!
    var LeaveStartDate:String!
    var LeaveEndDate:String!
    var LeaveDays:String!
    var Status:String!
    var ApproveRejectDate:String!
    var ApproveRejectDays:String!
    var ApproveRejectBy:String!
    var CL:String!
    var PL:String!
    var Reason:String!
    var HeadName:String!
    
    var Category:String!
    var Total:String!
    var Used:String!
    var Remaining:String!
    
    init(leaveId:String, createDate:String, leaveStartDate:String, leaveEndDate:String, leaveDays:String, status:String, arDate:String, arDays:String, arBy:String, cl:String, pl:String, reason:String, headName:String)
    {
        self.LeaveID = leaveId
        self.CreateDate = createDate
        self.LeaveStartDate = leaveStartDate
        self.LeaveEndDate = leaveEndDate
        self.LeaveDays = leaveDays
        self.Status = status
        self.ApproveRejectDate = arDate
        self.ApproveRejectDays = arDays
        self.ApproveRejectBy = arBy
        self.CL = cl
        self.PL = pl
        self.Reason = reason
        self.HeadName = headName
    }
    
    init(category:String, total:String, used:String, remaining:String)
    {
        self.Category = category
        self.Total = total
        self.Used = used
        self.Remaining = remaining
    }
}

class WorkPlanModel {
    
    var Standard:String?
    var ClassName:String?
    var Subject:String?
    var Month:String?
    var ArrWorkPlan:[WorkPlanModel]?
    var Work:String?
    var FromDate:String?
    var ToDate:String?
    var Status:NSInteger?
    var Remarks:String?
    var WorkID:String?
    var WorkPlanID:String?
    
    init(std:String, clsName:String, sub:String, month:String, arrWorkPlan:[WorkPlanModel])
    {
        self.Standard = std
        self.ClassName = clsName
        self.Subject = sub
        self.Month = month
        self.ArrWorkPlan = arrWorkPlan
    }
    
    init(work:String, fromDate:String, toDate:String, status:NSInteger, remarks:String, workId:String, workPlanId:String)
    {
        self.Work = work
        self.FromDate = fromDate
        self.ToDate = toDate
        self.Status = status
        self.Remarks = remarks
        self.WorkID = workId
        self.WorkPlanID = workPlanId
    }
}

class ForgotPasswordModel {
    
    let strPhoneNo :String?
    
    class func forgotPasswordValidation(_ strPhone:String) -> Bool
    {
        if strPhone.count == 0 {
            Functions.showAlert(false, Message.userNameError)
            return false
        }else if strPhone.count < 10 {
            Functions.showAlert(false, Message.userNameError)
            return false
        }
        return true
    }
    
    init(pno:String) {
        self.strPhoneNo = pno
    }
}
