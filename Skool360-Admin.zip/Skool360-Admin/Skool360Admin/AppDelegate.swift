//
//  AppDelegate.swift
//  Skool360Admin
//
//  Created by ADMS on 05/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import LGSideMenuController
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,UNUserNotificationCenterDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        //        if adminID != nil {
        self.registerForRemoteNotification()
        self.rootViewController()
        //        }
        
        /*if #available(iOS 10.0, *) {
         let center = UNUserNotificationCenter.current()
         center.requestAuthorization(options:[.badge, .alert, .sound]) { (granted, error) in
         // Enable or disable features based on authorization.
         }
         application.registerForRemoteNotifications()
         } else {
         // Fallback on earlier versions
         }
         
         if #available(iOS 10.0, *) {
         UNUserNotificationCenter.current().getNotificationSettings(){ (setttings) in
         
         switch setttings.soundSetting{
         case .enabled:
         
         print("enabled sound setting")
         
         case .disabled:
         
         print("setting has been disabled")
         
         case .notSupported:
         print("something vital went wrong here")
         }
         }
         } else {
         // Fallback on earlier versions
         }*/
        
        return true
    }
    
    func registerForRemoteNotification() {
        if #available(iOS 10.0, *) {
            let center  = UNUserNotificationCenter.current()
            center.delegate = self
            center.requestAuthorization(options: [.sound, .alert, .badge]) { (granted, error) in
                if error == nil{
                    //DispatchQueue.main.async { // Correct
                    UIApplication.shared.registerForRemoteNotifications()
                    //}
                }
            }
        }
        else {
            UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.sound, .alert, .badge], categories: nil))
            UIApplication.shared.registerForRemoteNotifications()
        }
    }
    
    func rootViewController()
    {
        if adminID == nil {
            let vc = Constants.storyBoard.instantiateViewController(withIdentifier: "Login")
            self.window?.rootViewController = vc
            return
        }
        
        let navigationController = Constants.storyBoard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        
        let mainViewController = Constants.storyBoard.instantiateInitialViewController() as! LGSideMenuController
        mainViewController.rootViewController = navigationController
        mainViewController.rightViewWidth = DeviceType.isIpad ? 320 : 270
        mainViewController.rightViewPresentationStyle = .scaleFromBig
        
        self.window?.rootViewController = mainViewController
        
        UIView.transition(with: window!, duration: 0.3, options: [.transitionCrossDissolve], animations: nil, completion: nil)
    }
    
    func isUpdateAvailable() throws -> (Bool,String,String) {
        guard let info = Bundle.main.infoDictionary,
            let currentVersion = info["CFBundleShortVersionString"] as? String,
            let proName = info["CFBundleDisplayName"] as? String,
            let identifier = info["CFBundleIdentifier"] as? String,
            let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(identifier)") else {
                throw VersionError.invalidBundleInfo
        }
        let data = try Data(contentsOf: url)
        guard let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as? [String: Any] else {
            throw VersionError.invalidResponse
        }
        if let result = (json["results"] as? [Any])?.first as? [String: Any], let version = result["version"] as? String {
            return (version != currentVersion, proName, version)
        }
        throw VersionError.invalidResponse
    }
    
    func setupForUpdate(_ strAppName:String, _ strAppVersion:String)
    {
        let alert = UIAlertController(title: Message.appUpdateTitle, message: Message.appUpdateMsg.replacingOccurrences(of: "{}", with: strAppName).replacingOccurrences(of: "()", with: strAppVersion), preferredStyle: .alert)
        let yesButton = UIAlertAction(title: "Later", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            exit(0)
        })
        let noButton = UIAlertAction(title: "Update", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            let url:URL = URL(string: "itms://itunes.apple.com/us/app/apple-store/id{#########}?mt=8")!
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        })
        alert.addAction(yesButton)
        alert.addAction(noButton)
        self.window?.windowLevel = UIWindowLevelAlert + 1
        self.window?.makeKeyAndVisible()
        self.window?.rootViewController?.present(alert, animated: true, completion: { })
    }
    
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let deviceTokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        print(deviceTokenString)
        NSLog("Device Token.....%@", deviceTokenString)
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        
        print("i am not available in simulator \(error)")
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        DispatchQueue.global().async {
            do {
                let update = try self.isUpdateAvailable().0
                if(update){
                    self.setupForUpdate(try self.isUpdateAvailable().1, try self.isUpdateAvailable().2)
                }
            } catch {
                print(error)
            }
        }
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
}

