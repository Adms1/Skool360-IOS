//
//  ServiceModal.swift
//  Skool360Admin
//
//  Created by ADMS on 09/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit

class StudentStaffModal {
    
    let Total  :String?
    let Present:String?
    let Absent :String?
    let Leave  :String?
    
    init(total:String, present:String, absent:String, leave:String) {
        self.Total = total
        self.Present = present
        self.Absent = absent
        self.Leave = leave
    }
}

class AccountModal {
    
    let TotalAmt:String?
    let TotalRcv:String?
    let TotalDue:String?
    
    init(totalAmt:String, totalRcv:String, totalDue:String) {
        self.TotalAmt = totalAmt
        self.TotalRcv = totalRcv
        self.TotalDue = totalDue
    }
}

class AttendanceModal {
    
    let StudentStatus:String?
    let Status       :String?
    let StaffStatus  :String?
    
    init(stuStatus:String, status:String, staffStatus:String) {
        self.StudentStatus = stuStatus
        self.Status = status
        self.StaffStatus = staffStatus
    }
}

struct StandardModal {
    
    let Standard      :String!
    let Class         :String!
    let TotalStudent  :String!
    let Present       :String!
    let Absent        :String!
    let Leave         :String!
}

struct AbsentModal {
    
    let Name     :String!
    let Standard :String!
    let Class    :String!
    let Days     :String!
}

struct CollectionModal {
    
    let TotalAmount  :String!
    let AmountType   :String!
    let StudentAmount:String!
}

struct StandardCollectionModal {
    
    let Standard:String!
    let Total   :String!
    let Received:String!
    let Dues    :String!
}

class SearchStudentsModal {
    
    var ParentName:String!
    var StudentName:String!
    var StudentID:String!
    var GRNO:String!
    var Grade:String!
    var Modal:SearchStudentsModal!
    
    init(studentName:String, grno:String, grade:String) {
        self.StudentName = studentName
        self.GRNO = grno
        self.Grade = grade
    }
    
    init(parentName:String, studentId:String, modal:SearchStudentsModal) {
        self.StudentID = studentId
        self.ParentName = parentName
        self.Modal = modal
    }
}

struct StudentDetailsModal {
    
    static var Tag:String = "Tag"
    static var StudentImage:String = "StudentImage"
    static var FirstName:String = "First Name"
    static var MiddleName:String = "Middle Name"
    static var LastName:String = "Last Name"
    static var DOB:String = "Date Of Birth"
    static var BirthPlace:String = "Birth Place"
    static var Age:String = "Age"
    static var Gender:String = "Gender"
    static var AadharNo:String = "Aadhaar Card No."
    static var StudentType:String = "Student Type"
    static var Term:String = "Term"
    static var AcedamicYear:String = "Acedamic Year"
    static var Grade:String = "Grade"
    static var Standard:String = "Standard"
    static var Section:String = "Section"
    static var Class:String = "Class"
    static var LastSchool:String = "Last School"
    static var DOA:String = "Date Of Admission"
    static var AdmissionTaken:String = "Admission Taken"
    static var BloodGrp:String = "Blood Group"
    static var House:String = "House"
    static var OldGRNO:String = "Old GRNO"
    static var Religion:String = "Religion"
    static var UserName:String = "User Name"
    static var Password:String = "Password"
    static var Status:String = "Status"
    static var GRNO:String = "GRNO"
    static var Nationality:String = "Nationality"
    static var RegistrationDate:String = "Registration Date"
    static var TransportKMs:String = "Transport KMs"
    static var PickupBus:String = "Pickup Bus"
    static var PickupPoint:String = "Pickup Point"
    static var PickupPointTime:String = "Pickup Point Time"
    static var DropBus:String = "Drop Bus"
    static var DropPoint:String = "Drop Point"
    static var DropPointTime:String = "Drop Point Time"
    
    static var FMFName:String = "First Name"
    static var FMLName:String = "Last Name"
    static var FMPhone:String = "Phone No."
    static var FMMobile:String = "Mobile No."
    static var FMEmail:String = "Email Address"
    static var FMQualification:String = "Qualification"
    static var FMOcupation:String = "Occupation"
    static var FMOrganization:String = "Organization"
    static var FMDesignation:String = "Designation"
    
    static var SMSNo:String = "SMS Communication No."
    static var City:String = "City"
    static var Address:String = "Address"
    static var ZipCode:String = "Zip Code"
    
    static var State:String = "State"
    static var MotherTongue:String = "Mother Tongue"
    static var SAOG:String = "Seeking Admission for Grade"
    static var TransportRequired:String = "Transport Required"
    static var PreviousSchoolAttended:String = "Previous School Attended"
    static var Board:String = "Board"
    static var SANS:String = "Sibling in Anand Niketan School"
    static var Branch:String = "Branch"
    static var Sibling1:String = "Name of Sibling 1"
    static var Sibling1Grade:String = "Sibling 1 Grade"
    static var Sibling2:String = "Name of Sibling 2"
    static var Sibling2Grade:String = "Sibling 2 Grade"
    static var Reference:String = "From where you got ref."
    static var DistanceFromSchoolKms:String = "Distance from School in Kms"
}

class FeesStructureModal {
    
    var Standard:String = ""
    var FeesType:String = ""
    var Term1Fees:String = ""
    var Term2Fees:String = ""
    var TermFees:String = ""
    var ArrayFees = [FeesStructureModal]()
    
    init(standard:String, arrayFees:[FeesStructureModal]) {
        self.Standard = standard
        self.ArrayFees = arrayFees
    }
    
    init(feesType:String, term1Fee:String, term2Fee:String) {
        self.FeesType = feesType
        self.Term1Fees = term1Fee
        self.Term2Fees = term2Fee
    }
    
    init(feesType:String, termFee:String) {
        self.FeesType = feesType
        self.TermFees = termFee
    }
}

struct DailyFeesCollectionModal {
    
    let StudentName     :String!
    let GRNO            :String!
    let Standard        :String!
    let TotalFees       :String!
    let TotalReceiveFees:String!
    let PendingFees     :String!
}

struct ImprestModal {
    
    let StudentName  :String!
    let GRNO         :String!
    let Standard     :String!
    let TotalImprest :String!
    let DeductImprest:String!
    let RemainImprest:String!
}

struct StudentDiscountModal {
    
    let StudentName:String!
    let GRNO       :String!
    let Standard   :String!
    let TotalFees  :String!
    let WaveOffAmt :String!
    let Discount   :String!
    let PayableAmt :String!
}

class TransportModal {
    
    var KMs:String!
    var Term1Fees:String!
    var Term2Fees:String!
    
    var PickupPointID:String!
    var PickupPoint:String!
    var Status:String!
    
    var VehicleName:String!
    var RegistrationNo:String!
    var PassngCapacity:String!
    
    var RouteNm:String!
    var Index:String!
    
    init(kms:String, term1Fee:String, term2Fee:String) {
        self.KMs = kms
        self.Term1Fees = term1Fee
        self.Term2Fees = term2Fee
    }
    
    init(index:String, pickUpPoint:String, status:String) {
        self.Index = index
        self.PickupPoint = pickUpPoint
        self.Status = status
    }
    
    init(index:String, vehicleName:String, regNo:String, passngCapacity:String) {
        self.Index = index
        self.VehicleName = vehicleName
        self.RegistrationNo = regNo
        self.PassngCapacity = passngCapacity
    }
    
    init(index:String, vehicleName:String, routeNm:String) {
        self.Index = index
        self.VehicleName = vehicleName
        self.RouteNm = routeNm
    }
}

class LedgerModal {
    
    var StudentName:String = ""
    var GRNO:String = ""
    var Grade:String = ""
    var Term:String = ""
    var SMSNo:String = ""
    var DOJ:String = ""
    
    var Date:String = ""
    var Paid:String = ""
    
    var TotalFees:String!
    var ReceiptFees:String!
    var RemainingFees:String!
    
    var PayFees:String = ""
    var CautionFee:String = ""
    var ReceiptNo:String = ""
    var PayMode:String = ""
    var AdmissionFee:String = ""
    var TuitionFee:String = ""
    var Transport:String = ""
    var ImprestFee:String = ""
    var LatesFee:String = ""
    var DiscountFee:String = ""
    var PreviousFees:String = ""
    var PayPaidFees:String = ""
    var CurrentOutstandingFees:String = ""
    var ArrayReceiptData = [LedgerModal]()
    
    init(stuName:String, grno:String, grade:String, term:String, smsNo:String, doj:String) {
        self.StudentName = stuName
        self.GRNO = grno
        self.Grade = grade
        self.Term = term
        self.SMSNo = smsNo
        self.DOJ = doj
    }
    
    /*init(prevFees:String, tutionFee:String, admissionFee:String, cautionFees:String, transport:String, imprest:String, lateFees:String, discount:String, payFees:String, paidFees:String, currentFees:String) {
     self.PreviousFees = prevFees
     self.TuitionFee = tutionFee
     self.AdmissionFee = admissionFee
     self.CautionFee = cautionFees
     self.Transport = transport
     self.ImprestFee = imprest
     self.LatesFee = lateFees
     self.DiscountFee = discount
     self.PayFees = payFees
     self.PayPaidFees = paidFees
     self.CurrentOutstandingFees = currentFees
     }*/
    
    init(totalFees:String, receiptFees:String, remainingFees:String) {
        self.TotalFees = totalFees
        self.ReceiptFees = receiptFees
        self.RemainingFees = remainingFees
    }
    
    init(date:String, paid:String, arrReceiptData:[LedgerModal]) {
        self.Date = date
        self.Paid = paid
        self.ArrayReceiptData = arrReceiptData
    }
    
    init(receiptNo:String, payMode:String, admissionFee:String, tutionFee:String, transport:String, imprest:String, lateFees:String, discount:String, prevFees:String, paidFees:String, currentFees:String) {
        self.ReceiptNo = receiptNo
        self.PayMode = payMode
        self.AdmissionFee = admissionFee
        self.TuitionFee = tutionFee
        self.Transport = transport
        self.ImprestFee = imprest
        self.LatesFee = lateFees
        self.DiscountFee = discount
        self.PreviousFees = prevFees
        self.PayPaidFees = paidFees
        self.CurrentOutstandingFees = currentFees
    }
}

struct StudentTransportModal {
    
    let StudentName    :String!
    let GRNO           :String!
    let Grade          :String!
    let RouteName      :String!
    let PickupPointName:String!
    let KM             :String!
    let StudentID      :String!
    var SMSMobileNo    :String!
}

struct ClassTeacherModal {
    
    let Name            :String!
    let Grade           :String!
    let Section         :String!
    let Pk_ClsTeacherID :String!
}

struct AssignSubjectModal {
    
    let Index      :String!
    let TeacherName:String!
    let Subject    :String!
}

struct ExamModal {
    
    let Index   :String!
    let TestName:String!
    let Grade   :String!
    let Subject :String!
    let TestDate:String!
}

class TimeTableModel {
    
    var Lecture:NSNumber?
    var Subject:String?
    var strTeacherName:String?
    var arrSubData = [TimeTableModel]()
    
    init(lecture:NSNumber, subData:[TimeTableModel])
    {
        self.Lecture    = lecture
        self.arrSubData = subData
    }
    
    init(subject:String, teacherName:String)
    {
        self.Subject        = subject
        self.strTeacherName = teacherName
    }
}

class MenuPermissionModel {
    
    var Index         :String!
    var Page_Nam      :String!
    var Page_UnderName:String!
    var PK_PageID     :String!
    var Status        :Bool!
    var IsUserUpdate  :Bool!
    var IsUserDelete  :Bool!
    var Page_URL      :String!
    
    init(index:String, pageName:String, pageUnderName:String, pageId:String, status:Bool, isUpdate:Bool, isDelete:Bool, pageUrl:String)
    {
        self.Index = index
        self.Page_Nam = pageName
        self.Page_UnderName = pageUnderName
        self.PK_PageID = pageId
        self.Status = status
        self.IsUserUpdate = isUpdate
        self.IsUserDelete = isDelete
        self.Page_URL = pageUrl
    }
}

class SMSModel {
    
    var Index:String!
    var StudentName:String!
    var FamilyName:String!
    var Standard:String!
    var Class:String!
    var SMSNo:String!
    var StudentID:String!
    var StandardID:String!
    var ClassID:String!
    var GRNO:String!
    var Status:String!
    
    var EmployeeName:String!
    var EmployeeID:String!
    
    var MobileNo:String!
    var Message:String!
    var Sendtime:String!
    var Rectime:String!
    var Deliverstatus:String!
    
    init(index:String, stuName:String, familyName:String, std:String, smsNo:String, stuId:String, stdId:String, clsId:String)
    {
        self.Index = index
        self.StudentName = stuName
        self.FamilyName = familyName
        self.Standard = std
        self.SMSNo = smsNo
        self.StudentID = stuId
        self.StandardID = stdId
        self.ClassID = clsId
    }
    
    init(index:String, stuName:String, grno:String, std:String, cls:String, smsNo:String, stuId:String, stdId:String, clsId:String, status:String)
    {
        self.Index = index
        self.StudentName = stuName
        self.GRNO = grno
        self.Standard = std
        self.Class = cls
        self.SMSNo = smsNo
        self.StudentID = stuId
        self.StandardID = stdId
        self.ClassID = clsId
        self.Status = status
    }
    
    init(index:String, empName:String, empId:String, empMobile:String)
    {
        self.Index = index
        self.EmployeeName = empName
        self.EmployeeID = empId
        self.SMSNo = empMobile
    }
    
    init(index:String, mobileNo:String, msg:String, sendTime:String, receiveTime:String, status:String)
    {
        self.Index = index
        self.MobileNo = mobileNo
        self.Message = msg
        self.Sendtime = sendTime
        self.Rectime = receiveTime
        self.Deliverstatus = status
    }
}

struct CircularModel {
    
    let Index          :String!
    let Cir_Date       :String!
    let Cir_Subject    :String!
    let Cir_Description:String!
    let Cir_Order      :String!
    let Cir_Status     :String!
}

class SMSMarksModel {
    
    var StudentName:String!
    var GRNO:String!
    var StudentID:String!
    var SMSNo:String!
    var MarksID:String!
    var Marks:String!
    
    init(stuName:String, grno:String, stuId:String, smsNo:String, marksId:String, marks:String)
    {
        self.StudentName = stuName
        self.GRNO = grno
        self.StudentID = stuId
        self.SMSNo = smsNo
        self.MarksID = marksId
        self.Marks = marks
    }
}

class PermissionModel {
    
    var Index:String!
    var Term:String!
    var TermDetail:String!
    var Standard:String!
    var Class:String!
    var Status:String!
    var AssignPermissionID:String!
    var EmployeeName:String!
    var EmployeeID:String!
    var EmployeeType:String!
    var strType:String!
    var strTestName:String!
    
    init(index:String, term:String, termDetail:String, standard:String, status:String)
    {
        self.Index = index
        self.Term = term
        self.TermDetail = termDetail
        self.Standard = standard
        self.Status = status
    }
    
    init(standard:String, cls:String, status:String)
    {
        self.Standard = standard
        self.Class = cls
        self.Status = status
    }
    
    init(index:String, permissionId:String, type:String, ename:String, eid:String)
    {
        self.Index = index
        self.AssignPermissionID = permissionId
        self.EmployeeType = type
        self.EmployeeName = ename
        self.EmployeeID = eid
    }
    
    init(permissionId:String, type:String, standard:String, cls:String, status:String, testName:String, term:String)
    {
        self.AssignPermissionID = permissionId
        self.strType = type
        self.Standard = standard
        self.Class = cls
        self.Status = status
        self.Term = term
        self.strTestName = testName
    }
}

class EnquiryModel {
    
    var Index:String!
    var StudentName:String!
    var StudentID:String!
    var Grade:String!
    var Gender:String!
    var Status:String!
    var Date:String!
    var StatusData = [EnquiryModel]()
    
    init(index:String, stuName:String, stuId:String, grade:String, gender:String, status:String, arrStatusData:[EnquiryModel])
    {
        self.Index = index
        self.StudentName = stuName
        self.StudentID = stuId
        self.Grade = grade
        self.Gender = gender
        self.Status = status
        self.StatusData = arrStatusData
    }
    
    init(status:String, date:String)
    {
        self.Status = status
        self.Date = date
    }
}

class StudentAttendanceModel {
    
    var StandardID:NSNumber?
    var ClassID:NSNumber?
    var AttendanceStatus:String?
    var StudentID:NSNumber?
    var StudentName:String?
    var AttendanceID:NSNumber?
    var StudentImage:String?
    
    var TotalOnDuty:NSNumber?
    var ShilajModalValue:ShilajStudentAttendanceModel?
    
    var Date:String?
    
    init(attendanceStatus:String, studentID:NSNumber, studentName:String, attendanceID:NSNumber,studentImage:String)
    {
        self.AttendanceStatus = attendanceStatus
        self.StudentID = studentID
        self.StudentName = studentName
        self.AttendanceID = attendanceID
        self.StudentImage = studentImage
    }
    
    init(standardID:NSNumber, classID:NSNumber, Date:String)
    {
        self.StandardID = standardID
        self.ClassID = classID
        self.Date = Date
    }
    
    init(ShilajModal:ShilajStudentAttendanceModel)
    {
        self.ShilajModalValue = ShilajModal
    }
    
    init(ShilajModal:ShilajStudentAttendanceModel, TotalOnDuty:NSNumber)
    {
        self.ShilajModalValue = ShilajModal
        self.TotalOnDuty = TotalOnDuty
    }
}

class ShilajStudentAttendanceModel {
    
    var Total:NSNumber?
    var TotalAbsent:NSNumber?
    var TotalPresent:NSNumber?
    var TotalLeave:NSNumber?
    
    init(Total:NSNumber, TotalAbsent:NSNumber, TotalPresent:NSNumber, TotalLeave:NSNumber)
    {
        self.Total = Total
        self.TotalAbsent = TotalAbsent
        self.TotalPresent = TotalPresent
        self.TotalLeave = TotalLeave
    }
}

struct ChequePaymentModel {
    
    var GRNO:String!
    var Date:String!
    var Status:String!
    var Amount:String!
    var ChequeNo:String!
    var Term:String!
    var ReceiptNo:String!
    var AdmissionFees:String!
    //    var CautionFee:String!
    var TuitionFees:String!
    var TransportFees:String!
    var Imprest:String!
    var LateFees:String!
    var Discount:String!
    var PreviousFees:String!
    var PayPaidFees:String!
    var CurrentOutstandingFees:String!
}

struct StudentModel {
    
    var StudentID:String!
    var StudentName:String!
    var GRNO:String!
    var Status:Bool!
    
    //    init(stuID:String, stuName:String, grno:String, status:Bool)
    //    {
    //        self.StudentID = stuID
    //        self.StudentName = stuName
    //        self.GRNO = grno
    //        self.Status = status
    //    }
}

class InboxSentModel {
    
    var ReadStatus:String?
    var UserName:String?
    var FromID:NSNumber?
    var ToID:NSNumber?
    var SubjectLine:String?
    var MessageID:NSNumber?
    var MeetingDate:String?
    var Description:String?
    
    init(readStatus:String, userName:String, fromID:NSNumber, toID:NSNumber, subLine:String, msgID:NSNumber, meetingDate:String, description:String)
    {
        self.ReadStatus = readStatus
        self.UserName = userName
        self.FromID = fromID
        self.ToID = toID
        self.SubjectLine = subLine
        self.MessageID = msgID
        self.MeetingDate = meetingDate
        self.Description = description
    }
}

struct UsersModel {
    
    let Name     :String!
    let Date     :String!
    let UserType :String!
}

struct HolidayModel {
    
    var Index      :String!
    var CategoryID :String!
    var HolidayID  :String!
    var Holiday    :String!
    var StartDate  :String!
    var EndDate    :String!
    var Description:String!
}

struct ViewLessonPlanModel {
    
    var Index             :String!
    var ID                :String!
    var ChapterNo         :String!
    var ChapterName       :NSAttributedString!
    var Objective         :NSAttributedString!
    var KeyPoint          :NSAttributedString!
    var AssessmentQuestion:NSAttributedString!
}

class LeaveModel {
    
    var LeaveID:String!
    var CreateDate:String!
    var LeaveStartDate:String!
    var LeaveEndDate:String!
    var LeaveDays:String!
    var Status:String!
    var ApproveRejectDate:String!
    var ApproveRejectDays:String!
    var ApproveRejectBy:String!
    var CL:String!
    var PL:String!
    var Reason:String!
    var HeadName:String!
    
    var Category:String!
    var Total:String!
    var Used:String!
    var Remaining:String!
    
    var EmployeeName:String!
    var EmployeeID:String!
    var ApplicationDate:String!
    var LeaveDate:String!
    var LeaveApproveID:String!
    
    var CLUsed:String!
    var CLTotal:String!
    var PLUsed:String!
    var PLTotal:String!
    
    init(leaveId:String, createDate:String, leaveStartDate:String, leaveEndDate:String, leaveDays:String, status:String, arDate:String, arDays:String, arBy:String, cl:String, pl:String, reason:String, headName:String)
    {
        self.LeaveID = leaveId
        self.CreateDate = createDate
        self.LeaveStartDate = leaveStartDate
        self.LeaveEndDate = leaveEndDate
        self.LeaveDays = leaveDays
        self.Status = status
        self.ApproveRejectDate = arDate
        self.ApproveRejectDays = arDays
        self.ApproveRejectBy = arBy
        self.CL = cl
        self.PL = pl
        self.Reason = reason
        self.HeadName = headName
    }
    
    init(category:String, total:String, used:String, remaining:String)
    {
        self.Category = category
        self.Total = total
        self.Used = used
        self.Remaining = remaining
    }
    
    init(empId:String, empName:String, plUsed:String, plTotal:String, clUsed:String, clTotal:String, total:String, used:String)
    {
        self.EmployeeID = empId
        self.EmployeeName = empName
        self.PLUsed = plUsed
        self.PLTotal = plTotal
        self.CLUsed = clUsed
        self.CLTotal = clTotal
        self.Total = total
        self.Used = used
    }
    
    init(empId:String, empName:String, applicationDate:String, leaveDate:String, leaveDays:String, status:String, reason:String, arDays:String, arBy:String, approveId:String)
    {
        self.EmployeeID = empId
        self.EmployeeName = empName
        self.ApplicationDate = applicationDate
        self.LeaveDate = leaveDate
        self.LeaveDays = leaveDays
        self.Status = status
        self.Reason = reason
        self.ApproveRejectDays = arDays
        self.ApproveRejectBy = arBy
        self.LeaveApproveID = approveId
    }
}

class TallyTransactionModel {
    
    var strVoucherID:String!
    var strStudentName:String!
    var strGRNO:String!
    var strGrade:String!
    var strAmount:String!
    var strStatus:String!
    
    init(voucherId:String, studentName:String, grno:String, grade:String, amount:String, status:String)
    {
        self.strVoucherID = voucherId
        self.strStudentName = studentName
        self.strGRNO = grno
        self.strGrade = grade
        self.strAmount = amount
        self.strStatus = status
    }
}

class DailyReportModel {
    
    var Index:String!
    var strDate:String!
    var strCreateBy:String!
    
    var strRouteProblem:String!
    var strDriverComplaint:String!
    var strParentsComplaint:String!
    var strTimingProblem:String!
    var strVehicleProblem:String!
    
    var strOther:String!
    
    var strBankBalance:String!
    var strPettyCash:String!
    var strExpenses:String!
    var strFeesReceived:String!
    var strDepositedInBank:String!
    
    var strLaptopIssued:String!
    var strTabletIssued:String!
    var strPrinting:String!
    var strIT:String!
    
    var strAdmissionInquiry:String!
    var strTotalNewAdmission:String!
    var strEventOftheYear:String!
    var strFBUpdate:String!
    var strMajorConcern:String!
    
    var strTSOS:String!
    var strNewAdmission:String!
    var strWithdrawals:String!
    var strSDU:String!
    var strOverallAdmin:String!
    var strNOTPA:String!
    var strTNOV:String!
    var strACOPBYPE:String!
    var strSuggestion:String!
    
    var strRepainMaintenance:String!
    var strToilets:String!
    var strWashArea:String!
    var strClassRoom:String!
    var strTeacherComplain:String!
    var strMaidsPA:String!
    var strGardner:String!
    
    init(index:String, date:String, createBy:String, routeProblem:String, driverComplaint:String, parentsComplaint:String, timingProblem:String, vehicleProblem:String, other:String) {
        
        self.Index = index
        self.strDate = date
        self.strCreateBy = createBy
        self.strRouteProblem = routeProblem
        self.strDriverComplaint = driverComplaint
        self.strParentsComplaint = parentsComplaint
        self.strTimingProblem = timingProblem
        self.strVehicleProblem = vehicleProblem
        self.strOther = other
    }
    
    init(index:String, date:String, createBy:String, bankBalance:String, pettyCash:String, expenses:String, feesReceived:String, depositedInBank:String, other:String) {
        
        self.Index = index
        self.strDate = date
        self.strCreateBy = createBy
        self.strBankBalance = bankBalance
        self.strPettyCash = pettyCash
        self.strExpenses = expenses
        self.strFeesReceived = feesReceived
        self.strDepositedInBank = depositedInBank
        self.strOther = other
    }
    
    init(index:String, date:String, createBy:String, laptopIssued:String, tabletIssued:String, printing:String, it:String, other:String) {
        
        self.Index = index
        self.strDate = date
        self.strCreateBy = createBy
        self.strLaptopIssued = laptopIssued
        self.strTabletIssued = tabletIssued
        self.strPrinting = printing
        self.strIT = it
        self.strOther = other
    }
    
    init(index:String, date:String, createBy:String, admissionInquiry:String, totalNewAdmission:String, eventOftheDay:String, fbUpdate:String, majorConcer:String, other:String) {
        
        self.Index = index
        self.strDate = date
        self.strCreateBy = createBy
        self.strAdmissionInquiry = admissionInquiry
        self.strTotalNewAdmission = totalNewAdmission
        self.strEventOftheYear = eventOftheDay
        self.strFBUpdate = fbUpdate
        self.strMajorConcern = majorConcer
        self.strOther = other
    }
    
    init(index:String, date:String, createBy:String, tsos:String, newAdmission:String, withdrawals:String, sdu:String, overallAdmin:String, notpa:String, tnov:String, acopbpe:String, suggestion:String, other:String) {
        
        self.Index = index
        self.strDate = date
        self.strCreateBy = createBy
        self.strTSOS = tsos
        self.strNewAdmission = newAdmission
        self.strWithdrawals = withdrawals
        self.strSDU = sdu
        self.strOverallAdmin = overallAdmin
        self.strNOTPA = notpa
        self.strTNOV = tnov
        self.strACOPBYPE = acopbpe
        self.strSuggestion = suggestion
        self.strOther = other
    }
    
    init(index:String, date:String, createBy:String, repairMaintenance:String, toilets:String, washArea:String, classRoom:String, teacherComplain:String, maidsPA:String, gardner:String, suggestion:String, other:String) {
        
        self.Index = index
        self.strDate = date
        self.strCreateBy = createBy
        self.strRepainMaintenance = repairMaintenance
        self.strToilets = toilets
        self.strWashArea = washArea
        self.strClassRoom = classRoom
        self.strTeacherComplain = teacherComplain
        self.strMaidsPA = maidsPA
        self.strGardner = gardner
        self.strSuggestion = suggestion
        self.strOther = other
    }
}

class InOutSummaryModel {
    
    var strTeacherName:String!
    var strDepartment:String!
    
    var strSun:String!
    var strMon:String!
    var strTue:String!
    var strWed:String!
    var strThu:String!
    var strFri:String!
    var strSat:String!
    
    var Day1:Int!
    var Day2:Int!
    var Day3:Int!
    var Day4:Int!
    var Day5:Int!
    var Day6:Int!
    var Day7:Int!
    
    var arrSummaryData:[InOutSummaryModel] = []
    
    init(teacherName:String, department:String, summaryData:[InOutSummaryModel]) {
        self.strTeacherName = teacherName
        self.strDepartment = department
        self.arrSummaryData = summaryData
    }
    
    init(day1: Int, day2: Int, day3: Int, day4: Int, day5: Int, day6: Int, day7: Int, sun: String, mon: String, tue: String, wed: String, thu: String, fri: String, sat:String) {
        
        self.Day1 = day1
        self.Day2 = day2
        self.Day3 = day3
        self.Day4 = day4
        self.Day5 = day5
        self.Day6 = day6
        self.Day7 = day7
        
        self.strSun = sun
        self.strMon = mon
        self.strTue = tue
        self.strWed = wed
        self.strThu = thu
        self.strFri = fri
        self.strSat = sat
    }
}

class EmployeePresentModel {
    
    var strDate:String!
    var strName:String!
    var strDepartment:String!
    var strDesignation:String!
    var strShift:String!
    
    var strCode:String!
    var strInOutTime:String!
    var strDuration:String!
    
    init(date:String, name:String, department:String, designation:String, shift:String)
    {
        self.strDate = date
        self.strName = name
        self.strDepartment = department
        self.strDesignation = designation
        self.strShift = shift
    }
    
    init(date:String, name:String, code:String, inOutTime:String, duration:String)
    {
        self.strDate = date
        self.strName = name
        self.strCode = code
        self.strInOutTime = inOutTime
        self.strDuration = duration
    }
}

class HomeWorkStatusModel {
    
    var StudentID:String?
    var StudentName:String?
    var HomeWorkID:String?
    var HomeWorkDetailID:String?
    var HomeWorkStatus:NSInteger?
    
    init(stuId:String, stuName:String, homeWorkId:String, homeWorkDetailId:String, homeWorkStatus:NSInteger)
    {
        self.StudentID = stuId
        self.StudentName = stuName
        self.HomeWorkID = homeWorkId
        self.HomeWorkDetailID = homeWorkDetailId
        self.HomeWorkStatus = homeWorkStatus
    }
}

class GalleryModel {
    
    var strGalleryID:String!
    var strTitle:String!
    var strComment:String!
    var strDate:String!
    var arrImages:[GalleryModel] = []
    
    var strDetailID:String!
    var strImage:String!
    
    init(galleryId:String, title:String, comment:String, date:String, images:[GalleryModel])
    {
        self.strGalleryID = galleryId
        self.strTitle = title
        self.strComment = comment
        self.strDate = date
        self.arrImages = images
    }
    
    init(detailId:String, image:String)
    {
        self.strDetailID = detailId
        self.strImage = image
    }
}
