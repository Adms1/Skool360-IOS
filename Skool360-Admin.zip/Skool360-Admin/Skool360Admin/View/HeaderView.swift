//
//  HeaderView.swift
//  Skool360Admin
//
//  Created by ADMS on 22/12/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit

class HeaderView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(loadViewFromNib())
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        addSubview(loadViewFromNib())
    }
    
    private func loadViewFromNib() -> UIView {
        let headerView:UIView = UINib(nibName: "HeaderView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
        headerView.frame = self.bounds
        headerView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        return headerView
    }
}
