//
//  DailyFeesStructureVC.swift
//  Skool360Admin
//
//  Created by ADMS on 30/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class DailyFeesCollectionVC: CustomViewController {
    
    @IBOutlet var tblDailyFeesCollection:UITableView!
    
    var arrDailyFeesData = [DailyFeesCollectionModal]()
    var strPaymentMode:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (success) in
            self.addDropDown()
            self.callDailyFeesCollectionApi()
        }
    }
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addSelectTermDropDown()
                    
                    //                case 3:
                //                    self.addStandardDropDown(view)
                default:
                    self.addSelectPaymentModeDropDown()
                }
                i += 1
            }
            else if(view.tag == i){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                i += 1
            }
        }
    }
    
    func addSelectTermDropDown()
    {
        let arrTerms = ["Term 1", "Term 2"]
        let strValue:String = arrTerms[Int(strTermDetail)! - 1]
        
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(2)?.frame)!)
        dropDown.options = arrTerms
        dropDown.tableHeight = CGFloat(arrTerms.count * 35)
        dropDown.selectedIndex = Int(strTermDetail)! - 1
        dropDown.title.text = strValue
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            strTermDetail = "\(index+1)"
        }
        self.view.addSubview(dropDown)
    }
    
    func addSelectPaymentModeDropDown()
    {
        strPaymentMode = "All"
        
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(3)?.frame)!)
        dropDown.options = self.dicData[self.title!] as! [String]
        dropDown.tableHeight = CGFloat(3 * 35)
        dropDown.selectedIndex = 3
        dropDown.title.text = strPaymentMode
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strPaymentMode = option
        }
        self.view.addSubview(dropDown)
    }
    
    
    func callDailyFeesCollectionApi()
    {
        let params = ["TermID" : strTermID,
                      "TermDetailID" : strTermDetail,
                      "FromDate" : ((self.view.viewWithTag(4) as! UIButton).titleLabel?.text)!,
                      "ToDate" : ((self.view.viewWithTag(5) as! UIButton).titleLabel?.text)!,
                      "PaymentMode" : strPaymentMode!]
        
        print(params)
        
        arrDailyFeesData = []
        selectedIndex = -1
        previousIndex = -1
        
        Functions.callApi(api: API.dailyFeeCollectionApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayDailyfees = json!["FinalArray"].array
                
                for value in arrayDailyfees! {                
                    
                    var arrFeeReceiptDetail:[DailyFeesCollectionModal] = []
                    let array:[JSON] = value["FeeReceiptDetail"].arrayValue
                    
                    for subValue in array {
                        arrFeeReceiptDetail.append(DailyFeesCollectionModal.init(createDate: subValue["CreateDate"].stringValue, term: subValue["Term"].stringValue, feesAmt: subValue["Amount"].stringValue, paymentMode: subValue["PaymentMode"].stringValue, transId: subValue["EncryptedTransID"].stringValue, url: subValue["URL"].stringValue))
                    }
                    self.arrDailyFeesData.append(DailyFeesCollectionModal.init(studentName: value["Name"].stringValue, grno: value["GRNO"].stringValue, standard: value["Standard"].stringValue, cls: value["Class"].stringValue, amount: value["Amount"].stringValue, totalAmt: value["TotalAmt"].stringValue, openingBalance: value["OpeningBalance"].stringValue, feesReceiptDetail: arrFeeReceiptDetail))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDailyFeesCollectionApi()
                })
            }
            self.tblDailyFeesCollection.reloadData()
        }
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callDailyFeesCollectionApi()
    }
    
    private lazy var usersPopupVC: UsersPopupVC = {
        
        var viewController:UsersPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "UsersPopupVC") as! UsersPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension DailyFeesCollectionVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:DailyFeesCollectionCell = tableView.dequeueReusableCell(withIdentifier: "DailyFeesCollectionHeaderCell") as! DailyFeesCollectionCell
        
        headerView.headerHeight.constant = section == 0 ? DeviceType.isIpad ? 45 : 40 : 0
        headerView.lblDay.superview?.addShadowWithRadius(2.0, 0, 0)
        
        //        if(section == previousIndex) {
        //            headerView.lblDay.textColor = .red
        //        }else
        if section == selectedIndex {
            headerView.lblDay.textColor = GetColor.green
        }else{
            headerView.lblDay.textColor = .red
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblDay.superview?.tag = section
        headerView.lblDay.superview?.addGestureRecognizer(tapGesture)
        
        headerView.displayHeaderData(arrDailyFeesData[section])
        return arrDailyFeesData.count > 0 ? headerView.contentView : nil
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrDailyFeesData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        tableView.estimatedSectionHeaderHeight = 90
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrDailyFeesData[section].FeeReceiptDetail.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 120
        return 0//indexPath.section == selectedIndex ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:DailyFeesCollectionCell = tableView.dequeueReusableCell(withIdentifier: "DailyFeesCollectionCell", for: indexPath) as! DailyFeesCollectionCell
        
        cell.rowHeight.constant = indexPath.row == 0 ? DeviceType.isIpad ? 40 : 35 : 0
        cell.topHeight.constant = indexPath.row == 0 ? 45 : 0
        
        cell.contentView.subviews.forEach{$0.isHidden = indexPath.row > 0}
        
        cell.contentView.subviews[0].isHidden = false
        cell.contentView.subviews[2].isHidden = false
        
        //cell.displayData(arrDailyFeesData[indexPath.section], indexPath.row)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(viewReceipt(_:)))
        cell.contentView.tag = indexPath.section
        cell.lblDay.superview?.tag = indexPath.row
        cell.lblDay.superview?.addGestureRecognizer(tapGesture)
        
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        selectedDailyFeesModel = arrDailyFeesData[(gesture.view?.tag)!]
        arrSelectedDailyFeesModel = arrDailyFeesData[(gesture.view?.tag)!].FeeReceiptDetail
        add(asChildViewController: self.usersPopupVC, self)
        return
        
        if(previousIndex != -1){
            //tblDailyFeesCollection.reloadSections(NSIndexSet(index: previousIndex) as IndexSet, with: .automatic)
        }
        
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblDailyFeesCollection.reloadData()
        self.tblDailyFeesCollection.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
        
        previousIndex = selectedIndex
    }
    
    @objc func viewReceipt(_ gesture:UIGestureRecognizer)
    {
        let superTag:Int = (gesture.view?.superview!.tag)!
        let tag:Int = (gesture.view?.tag)!
        
        webUrl = URL.init(string: API.hostName + "/" + arrDailyFeesData[superTag].FeeReceiptDetail[tag].URL)
        //add(asChildViewController: self.viewMarksVC, self)
    }
}
