//
//  StudentLedgerVC.swift
//  Skool360Admin
//
//  Created by ADMS on 20/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class StudentLedgerVC: CustomViewController {
    
    @IBOutlet var tblFeesData:UITableView!
    
    var arrStudentsData:[String] = []
    var arrGRNOData:[String] = []
    
    var arrStudentsSearchData:[String] = []
    var arrGRNOSearchData:[String] = []
    
    var dicStudentDetail:NSMutableDictionary = [:]
    
    var studentDataModal:LedgerModal?
    
    var arrFeesData = [LedgerModal]()
    var arrReceiptData = [LedgerModal]()
    
    var activateField:DropDownTextField!
    var strStudentId:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for view in self.view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.selectedColor = GetColor.blue
            radioButton.deselectedColor = .lightGray
            if(radioButton.tag == 1){
                radioButton.select(animated: true)
            }
            
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
            radioButton.addGestureRecognizer(tapGesture)
        }
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.callFeesStructureApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (success) in
            self.addAutoCompleteMenu()
            self.callSearchByApi((self.view.viewWithTag(4) as! UITextField).text!)
        }
    }
    
    // MARK: Api Calling
    
    func callSearchByApi(_ inputValue:String)
    {        
        let params = ["SearchType" : "Current Student",
                      "InputValue" : inputValue]
        
        Functions.callApi(api: API.admin_StudentSearchByStuName, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrGetData = json!["FinalArray"].array
                for values in arrGetData! {
                    
                    self.arrStudentsData.append(values["Name"].stringValue)
                    self.arrStudentsSearchData = self.arrStudentsData
                    
                    self.arrGRNOData.append(values["GRNO"].stringValue)
                    self.arrGRNOSearchData = self.arrGRNOData
                    self.dicStudentDetail.setValue(values["StudentID"].stringValue, forKey: values["Name"].stringValue)
                    self.dicStudentDetail.setValue(values["StudentID"].stringValue, forKey: values["GRNO"].stringValue)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSearchByApi(inputValue)
                })
            }
        }
    }
    
    @objc func callFeesStructureApi()
    {
        let params = ["studentid" : strStudentId!,
                      "TermID":strTermID]
        
        print(params)
        
        self.arrReceiptData = []
        self.arrFeesData = []
        studentDataModal = nil
        selectedIndex = -1
        
        Functions.callApi(api: API.getPaymentLedger, params: params) { (json,error) in
            
            if(json != nil){
                
                let dictFees = json!["FinalArray"].array?.first
                
                self.studentDataModal = LedgerModal.init(stuName: dictFees!["StudentName"].stringValue, grno: dictFees!["GRNO"].stringValue, grade: "\(dictFees!["Standard"].stringValue) - \(dictFees!["ClassName"].stringValue)", term: dictFees!["Term"].stringValue, smsNo:dictFees!["SMSNo"].stringValue, doj:dictFees!["Date of Joining"].stringValue)
                
                //self.studentFeesModal = LedgerModal.init(prevFees: dictFees!["PreviousBalance"].stringValue, tutionFee: dictFees!["TutionFees"].stringValue, admissionFee: dictFees!["AdmissionFees"].stringValue, cautionFees: dictFees!["CautionFees"].stringValue, transport: dictFees!["TransportFees"].stringValue, imprest: dictFees!["Imprest"].stringValue, lateFees: dictFees!["TermLateFee"].stringValue, discount: dictFees!["TermDiscount"].stringValue, payFees: dictFees!["TermDuePay"].stringValue, paidFees: dictFees!["TermPaid"].stringValue, currentFees: dictFees!["TermTotal"].stringValue)
                
                let arrayFeesNames = self.dicData[self.title!] as! [String]
                
                for (i,name) in arrayFeesNames.enumerated() {
                    var studentFeesModal:LedgerModal!
                    
                    switch(i)
                    {
                    case 4,6:
                        studentFeesModal = LedgerModal.init(totalFees: dictFees!["\(name)"].stringValue, receiptFees: dictFees!["Receipt\(name)"].stringValue, remainingFees: dictFees!["Remaining\(name)"].stringValue)
                        self.arrReceiptData.append(LedgerModal.init(date: name, paid: "  ", arrReceiptData:[]))
                        
                    case 7:
                        studentFeesModal = LedgerModal.init(totalFees: dictFees!["\(name)TermFees"].stringValue, receiptFees: dictFees!["ReceiptTermFees"].stringValue, remainingFees: dictFees!["RemainingTermFees"].stringValue)
                        self.arrReceiptData.append(LedgerModal.init(date: "\(name) Term Fees", paid: "  ", arrReceiptData:[]))
                        
                    default:
                        studentFeesModal = LedgerModal.init(totalFees: dictFees!["\(name)Fees"].stringValue, receiptFees: dictFees!["Receipt\(name)Fees"].stringValue, remainingFees: dictFees!["Remaining\(name)Fees"].stringValue)
                        self.arrReceiptData.append(LedgerModal.init(date: "\(name) Fees", paid: "  ", arrReceiptData:[]))
                    }
                    self.arrFeesData.append(studentFeesModal)
                }
                
                /*
                 */
                
                Functions.callApi(api: API.getAllPaymentLedger, params: params) { (json,error) in
                    
                    if(json != nil){
                        
                        let dictData = json!["FinalArray"].array?.first
                        let arrayReceipts:[JSON] = dictData!["Data"].array!
                        
                        var arrReceipt = [LedgerModal]()
                        for value in arrayReceipts {
                            let ledgerModal = LedgerModal.init(receiptNo: value["ReceiptNo"].stringValue, payMode: value["PayMode"].stringValue, admissionFee: value["AdmissionFee"].stringValue, tutionFee: value["TuitionFee"].stringValue, transport: value["Transport"].stringValue, imprest: value["ImprestFee"].stringValue, lateFees: value["LatesFee"].stringValue, discount: value["DiscountFee"].stringValue, prevFees: value["PreviousFees"].stringValue, paidFees: value["PayPaidFees"].stringValue, currentFees: value["CurrentOutstandingFees"].stringValue)
                            
                            arrReceipt.append(ledgerModal)
                        }
                        self.arrReceiptData.append(LedgerModal.init(date: dictData!["PayDate"].stringValue, paid: dictData!["Paid"].stringValue, arrReceiptData:arrReceipt))
                        self.tblFeesData.reloadData()
                        
                    }else{
                        self.tblFeesData.reloadData()
                    }
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callFeesStructureApi()
                })
            }
        }
    }
    
    // MARK: Function for Radio Button Selection
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in self.view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        let radioButton:LTHRadioButton = gesture.view as! LTHRadioButton
        radioButton.select(animated: true)
        
        /*
         */
        
        (self.view.viewWithTag(3) as! UILabel).text = radioButton.tag == 1 ? "Student Name" : "GRNO"
        (self.view.viewWithTag(4) as! UITextField).text = nil
        (self.view.viewWithTag(4) as! UITextField).placeholder = (self.view.viewWithTag(3) as! UILabel).text
        self.dismissKeyboard()
        self.view.layoutIfNeeded()
        
        self.addAutoCompleteMenu()
    }
    
    // MARK: Function for Choose Options for Term
    
    func addDropDown()
    {
        for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            let dd:UIDropDown = view as! UIDropDown
            if(dd.table != nil){
                dd.hideTable()
            }
            view.removeFromSuperview()
        }
        self.addTermDropDown(self.view.viewWithTag(-1)!)
    }
    
    // MARK: AutoCompleteMenu
    
    func addAutoCompleteMenu()
    {
        for view in self.view.subviews.filter({($0.isKind(of: DropDownTextField.classForCoder()))}) {
            
            let dropDownTextField:DropDownTextField = view as! DropDownTextField
            activateField = dropDownTextField
            
            dropDownTextField.dropDownTableView.tag = 1
            dropDownTextField.dropDownTableView.dataSource = self
            dropDownTextField.dropDownTableView.delegate = self
            
            dropDownTextField.dropDownTableView.isHidden = true
            dropDownTextField.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        }
        self.addDropDown()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension StudentLedgerVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activateField = textField as! DropDownTextField
        textField.becomeFirstResponder()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if((self.view.viewWithTag(3) as! UILabel).text == "GRNO" && range.location > 4){
            return false
        }
        return true
    }
    
    @objc func textFieldDidChange(_ textField: DropDownTextField) {
        
        activateField = textField
        switch (self.view.viewWithTag(3) as! UILabel).text! {
        case "GRNO":
            let filtered = arrGRNOSearchData.filter { $0.range(of: textField.text!, options: .caseInsensitive) != nil }
            arrGRNOData = textField.text == "" ? arrGRNOSearchData : filtered
            if(arrGRNOData.count == 0){
                textField.dropDownTableView.isHidden = true
                return
            }
            
        default:
            let filtered = arrStudentsSearchData.filter { $0.range(of: textField.text!, options: .caseInsensitive) != nil }
            arrStudentsData = textField.text == "" ? arrStudentsSearchData : filtered
            if(arrStudentsData.count == 0){
                textField.dropDownTableView.isHidden = true
                return
            }
        }
        
        textField.dropDownTableView.isHidden = false
        textField.dropDownTableView.reloadData()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        dismissKeyboard()
        return true
    }
    
    func dismissKeyboard(){
        if activateField != nil {
            if activateField.dropDownTableView.isHidden == false {
                activateField.resignFirstResponder()
                activateField.dropDownTableView.isHidden = true
            }
            self.view.endEditing(true)
        }
    }
}

extension StudentLedgerVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        if tableView.tag != 1 && studentDataModal != nil
        {
            var strIdentifier:String = "LedgerTopCell"
            if(section > 0){
                strIdentifier = "LedgerDateCell"
            }
            
            let headerView:LedgerCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier) as! LedgerCell
            
            if section == 0
            {
                headerView.displayStudentData(studentDataModal!)
            }
            else
            {
                headerView.displayData()
                
                let btnExpand:UIButton? = headerView.contentView.subviews[0].subviews[1].subviews[2] as? UIButton
                let viewShadow:UIView! = headerView.contentView.subviews[0].subviews[1]
                
                headerView.displayDetailsData(arrReceiptData[section-1])
                
                if(section == 1)
                {
                    (headerView.contentView.subviews[0].subviews[0] as! UILabel).text = "Account Details :"
                }
                else{
                    (headerView.contentView.subviews[0].subviews[0] as! UILabel).text = "Receipt Details :"
                }
                
                btnExpand?.transform = .identity
                if section == selectedIndex {
                    viewShadow.addShadowWithRadius(3.0, 0, 0)
                    UIView.animate(withDuration: 0.5, animations: {
                        btnExpand?.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI/2))
                    })
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
                viewShadow.tag = section
                viewShadow.addGestureRecognizer(tapGesture)
            }
            return headerView.contentView
        }
        else {
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return tableView.tag == 1 ? 0 : section == 0 ?  DeviceType.isIpad ? 150 : 130 : section == 1 || section > arrFeesData.count ? DeviceType.isIpad ? 100 : 95 : DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if studentDataModal != nil {
            return arrReceiptData.count + 1
        }else {
            return tableView.tag == 1 ? 1 : 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 1 {
            switch (self.view.viewWithTag(3) as! UILabel).text! {
            case "GRNO":
                return arrGRNOData.count
            default:
                return arrStudentsData.count
            }
        }
        switch (section) {
        case 0:
            return 0
            
        default:
            if(section <= arrFeesData.count){
                return arrFeesData.count > 0 ? 1 : 0
            }else{
                return section == selectedIndex ? arrReceiptData[section-1].ArrayReceiptData.count : 0
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView.tag == 1 {
            return DeviceType.isIpad ? 40 : 30
        }
        switch (indexPath.section) {
        case 0:
            return DeviceType.isIpad ? 95 : 85
            
        default:
            if(indexPath.section <= arrFeesData.count){
                return indexPath.section == selectedIndex ? DeviceType.isIpad ? 105 : 95 : 0
            }else{
                return indexPath.section == selectedIndex ? DeviceType.isIpad ? 285 : 247 : 0
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView.tag == 1 {
            var cell = activateField.dropDownTableView.dequeueReusableCell(withIdentifier: "Cell")
            if cell == nil {
                cell = UITableViewCell(style: .default, reuseIdentifier: "Cell")
                cell?.selectionStyle = .none
            }
            
            var array:[String] = []
            switch (self.view.viewWithTag(3) as! UILabel).text! {
            case "GRNO":
                array =  arrGRNOData
            default:
                array =  arrStudentsData
            }
            
            cell?.textLabel?.font = UIFont.systemFont(ofSize: 12)
            cell!.textLabel!.text = array[indexPath.row]
            
            return cell!
        }else {
            
            var strIdentifier:String = "LedgerCell"
            if(indexPath.section != tableView.numberOfSections-1) {
                strIdentifier = "LedgerFeesCell"
            }
            
            let cell:LedgerCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! LedgerCell
            
            if(indexPath.section <= arrFeesData.count) {
                cell.displayAccountData(arrFeesData[indexPath.section-1], arrReceiptData[indexPath.section-1].Date)
            }else {
                cell.displayReceiptData(arrReceiptData[indexPath.section-1].ArrayReceiptData[indexPath.row])
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView.tag == 1 {
            let cell = activateField.dropDownTableView.cellForRow(at: indexPath)
            activateField.text = cell?.textLabel?.text
            
            self.dismissKeyboard()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                
                self.strStudentId = self.dicStudentDetail.value(forKey: (cell?.textLabel?.text)!) as! String
                self.callFeesStructureApi()
            }
        }
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblFeesData.reloadData()
        self.tblFeesData.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
    }
}
