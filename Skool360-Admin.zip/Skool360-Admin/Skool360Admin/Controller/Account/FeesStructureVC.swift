//
//  FeesStructureVC.swift
//  Skool360Admin
//
//  Created by ADMS on 30/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class FeesStructureVC: CustomViewController {
    
    @IBOutlet var tblFeeStructure:UITableView!
    
    var arrFeesStructure = [FeesStructureModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.callFeesStructureApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (success) in
            self.addTermDropDown(self.view.viewWithTag(2)!)
            self.callFeesStructureApi()
        }
    }
    
    
    @objc func callFeesStructureApi()
    {
        let params = ["Term_ID" : strTermID]
        
        print(params)
        
        arrFeesStructure = []
        
        Functions.callApi(api: API.admin_AccountFeesStructureApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayFees = json!["FinalArray"].array
                
                var arrFeesStr = ["Admission Fee","Caution Money","Tuition Fee","Imprest"]
                
                for value in arrayFees! {
                    
                    var arrFees = [FeesStructureModal]()
                    arrFees.append(FeesStructureModal.init(feesType: "Detail", term1Fee: "Term 1", term2Fee: "Term 2"))
                    
                    for i in 0..<arrFeesStr.count {
                        let strAmountType:String = arrFeesStr[i]
                        
                        let feesModal:FeesStructureModal = FeesStructureModal.init(feesType: strAmountType, term1Fee: value["Term 1 \(strAmountType)"].stringValue, term2Fee: value["Term 2 \(strAmountType)"].stringValue)
                        
                        arrFees.append(feesModal)
                    }
                    self.arrFeesStructure.append(FeesStructureModal.init(standard: value["Standard"].stringValue, arrayFees: arrFees))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callFeesStructureApi()
                })
            }
            self.tblFeeStructure.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension FeesStructureVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:FeeStructureCell = tableView.dequeueReusableCell(withIdentifier: "FeeStructureHeaderCell") as! FeeStructureCell
        
        headerView.displayHeaderData(arrFeesStructure[section])
        
        headerView.contentView.subviews[0].subviews[1].transform = .identity
        if section == selectedIndex {
            headerView.contentView.subviews[0].addShadowWithRadius(3.0, 0, 0)
            UIView.animate(withDuration: 0.5, animations: {
                headerView.contentView.subviews[0].subviews[1].transform = CGAffineTransform(rotationAngle: CGFloat(M_PI/2))
            })
        }
        
        for view in headerView.contentView.subviews[0].subviews.filter({($0.isKind(of: UILabel.classForCoder()))}) {
            let lbl:UILabel = view as! UILabel
            lbl.font = FontType.mediumFont
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        return  arrFeesStructure.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrFeesStructure.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == selectedIndex ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:FeeStructureCell = tableView.dequeueReusableCell(withIdentifier: "FeeStructureCell", for: indexPath) as! FeeStructureCell
        
        for view in cell.contentView.subviews[0].subviews{
            if(view.isKind(of: UIImageView.classForCoder())) {
                let imgView:UIImageView = view as! UIImageView
                indexPath.row > 0 ? imgView.image = UIImage.init(named: "") : imgView.loadIconsFromLocal("BlueBox")
            }else{
                let lbl:UILabel = view as! UILabel
                lbl.textColor = indexPath.row > 0 ? .black : .white
                lbl.font = indexPath.row > 0 ?  lbl.tag == 1 ? FontType.mediumFont : FontType.regularFont : FontType.boldFont
                if(lbl.tag == -1){
                    lbl.backgroundColor = indexPath.row > 0 ? UIColor.lightGray.withAlphaComponent(0.3) : .white
                }
            }
        }
        
        let feesModal:[FeesStructureModal] = arrFeesStructure[indexPath.section].ArrayFees
        cell.displayData(feesModal[indexPath.row],indexPath.row > 0 ? true : false)
        
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblFeeStructure.reloadSections(IndexSet(integersIn: 0...arrFeesStructure.count-1), with: .automatic)
        self.tblFeeStructure.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
    }
}
