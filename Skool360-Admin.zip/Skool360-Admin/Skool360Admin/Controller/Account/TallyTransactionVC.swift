//
//  TallyTransactionVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 05/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class TallyTransactionVC: CustomViewController {
    
    @IBOutlet weak var tblTallyTransaction:UITableView!
    
    var arrTallyTransactionData = [TallyTransactionModel]()
    var status:Int = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for view in view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.arrStandards.insert("All", at: 0)
            self.addDropDown()
            self.callGetTallyTransaction()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension TallyTransactionVC
{
    func callGetTallyTransaction()
    {
        arrTallyTransactionData = []
        
        let params = ["StartDate" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDate" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!,
                      "Status" : "\(status)",
            "StandardID" : strStdID!]
        
        print(params)
        
        Functions.callApi(api: API.tallyTransactionListApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrTallyData = json!["FinalArray"].array
                
                for values in arrTallyData! {
                    let tallyTransactionModel:TallyTransactionModel = TallyTransactionModel.init(voucherId: values["VoucherNo"].stringValue, studentName: values["StudentName"].stringValue, grno: values["GRNO"].stringValue, grade: values["Standard"].stringValue, amount: values["Amount"].stringValue, status: values["Status"].stringValue)
                    
                    self.arrTallyTransactionData.append(tallyTransactionModel)
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetTallyTransaction()
                })
            }
            self.tblTallyTransaction.reloadData()
        }
    }
}

extension TallyTransactionVC
{
    func addDropDown()
    {
        var i = 100
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 100:
                    self.addStandardDropDown(view)
                    
                case 200:
                    self.addStatusDropDown()
                    
                default:
                    break
                }
                i += 100
            }
        }
    }
    
    func addStatusDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(200)!.frame)
        dropDown.options = ["All", "Pending Receipt", "Receipt Generated"]
        dropDown.tableHeight = CGFloat(3 * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = "All"
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.status = index - 1
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton) {
        self.callGetTallyTransaction()
    }
}

extension TallyTransactionVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrTallyTransactionData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrTallyTransactionData.count > 0 ? DeviceType.isIpad ? 50 : 45 : 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView:TallyTransactionCell = tableView.dequeueReusableCell(withIdentifier: "TallyTransactionHeaderCell") as! TallyTransactionCell
        return arrTallyTransactionData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TallyTransactionCell = tableView.dequeueReusableCell(withIdentifier: "TallyTransactionCell") as! TallyTransactionCell
        cell.displayTallyTransactionDetails(arrTallyTransactionData[indexPath.row])
        return cell
    }
}
