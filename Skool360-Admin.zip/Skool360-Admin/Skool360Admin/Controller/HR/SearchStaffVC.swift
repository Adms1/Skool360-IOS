//
//  SearchStaffVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 23/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class SearchStaffVC: CustomViewController {
    
    @IBOutlet weak var tblSearchStaff:UITableView!
    
    var dicDepartment:NSMutableDictionary!
    var dicDesignation:NSMutableDictionary!
    
    var arrDepartment:[String] = []
    var arrDesignation:[String] = []
    
    var strDepartmentID:String = "0"
    var strDesignationID:String = "0"
    
    var arrSearchStaffs = [SearchStaffModal]()
    var arrData:[JSON] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (_) in
            self.callGetDepartmentApi {
                self.callGetDesignationApi {
                    self.callGetStaffDetails()
                    self.addDropDown()
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SearchStaffVC
{
    // MARK: - API Calling
    
    func callGetDepartmentApi(completion:@escaping () -> ())
    {
        dicDepartment = [:]
        
        Functions.callApi(api: API.getDepartmentApi, params: [:]) { (json, error) in
            
            if(json != nil){
                
                let arrDepartment = json!["FinalArray"].array
                
                for values in arrDepartment! {
                    self.dicDepartment.setValue(values["DepartmentId"].stringValue, forKey: values["DepartmentName"].stringValue)
                }
                self.arrDepartment = self.dicDepartment.sortedDictionary(self.dicDepartment).0
                self.arrDepartment.insert("-Select-", at: 0)
                
                completion()
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetDepartmentApi {}
                })
            }
        }
    }
    
    func callGetDesignationApi(completion:@escaping () -> ())
    {
        dicDesignation = [:]
        
        Functions.callApi(api: API.getDesignationApi, params: [:]) { (json, error) in
            
            if(json != nil){
                
                let arrDepartment = json!["FinalArray"].array
                
                for values in arrDepartment! {
                    self.dicDesignation.setValue(values["DesignationId"].stringValue, forKey: values["DesignationName"].stringValue)
                }
                self.arrDesignation = self.dicDesignation.sortedDictionary(self.dicDesignation).0
                self.arrDesignation.insert("-Select-", at: 0)
                
                completion()
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetDesignationApi {}
                })
            }
        }
    }
    
    func callGetStaffDetails()
    {
        arrData = []
        arrSearchStaffs = []
        
        let params = ["TermID" : strTermID,
                      "DepartmentId" : strDepartmentID,
                      "DesignationId" : strDesignationID]
        
        Functions.callApi(api: API.getStaffFullDetailApi, params: params) { (json, error) in
            
            if(json != nil){
                
                self.arrData = json!["FinalArray"].array!
                
                for value in self.arrData {
                    
                    let searchStaffModal:SearchStaffModal = SearchStaffModal.init(name: value["Name"].stringValue, code: value["Emp Code"].stringValue, fhName: value["Father/HusbandName"].stringValue, dob: value["Date Of Birth"].stringValue, department: value["Department"].stringValue)
                    
                    self.arrSearchStaffs.append(searchStaffModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetStaffDetails()
                })
            }
            self.tblSearchStaff.reloadData()
        }
    }
}

extension SearchStaffVC
{
    // MARK: - Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 1:
                    self.addTermDropDown(view)
                    
                case 2:
                    self.addDepartmentDropDown()
                    
                case 3:
                    self.addDesignationDropDown()
                    
                default:
                    break
                }
                i += 1
            }
        }
    }
    
    func addDepartmentDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(2)?.frame)!)
        
        dropDown.options = arrDepartment
        dropDown.tableHeight = arrDepartment.count > 5 ? CGFloat(5 * 35) : CGFloat(arrDepartment.count * 35)
        dropDown.title.text = arrDepartment[0]
        dropDown.selectedIndex = 0
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strDepartmentID = index == 0 ? "0" : self.dicDepartment[option] as! String
        }
        self.view.addSubview(dropDown)
    }
    
    func addDesignationDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(3)?.frame)!)
        
        dropDown.options = arrDesignation
        dropDown.tableHeight = arrDesignation.count > 5 ? CGFloat(5 * 35) : CGFloat(arrDesignation.count * 35)
        dropDown.title.text = arrDesignation[0]
        dropDown.selectedIndex = 0
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strDesignationID = index == 0 ? "0" : self.dicDesignation[option] as! String
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callGetStaffDetails()
    }
}

extension SearchStaffVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:SearchStaffCell = tableView.dequeueReusableCell(withIdentifier: "SearchStaffHeaderCell") as! SearchStaffCell
        
        return arrSearchStaffs.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrSearchStaffs.count > 0 ? 50 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSearchStaffs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SearchStaffCell = tableView.dequeueReusableCell(withIdentifier: "SearchStaffCell", for: indexPath) as! SearchStaffCell
        cell.displayData(arrSearchStaffs[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc:StaffDetailsVC = Constants.storyBoard.instantiateViewController(withIdentifier: "StaffDetailsVC") as! StaffDetailsVC
        vc.dicStaffData = arrData[indexPath.row].dictionary!
        vc.title = "Staff Details"
        self.navigationController?.pushPopTransition(vc,true)
    }
}
