//
//  StaffDetailVC.swift
//  Skool360Admin
//
//  Created by ADMS on 25/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import SwiftyJSON

class StaffDetailsVC: CustomViewController {
    
    @IBOutlet var tblStaffDetails:UITableView!
    
    var arrStaffHeaderTitle = ["Personal Details","Office Details"]
    var arrStaffHeaderColor:[UIColor] = [GetColor.darkBlue,GetColor.green]
    var dicStaffData:Dictionary<String, JSON> = [:]
    var dicStaffDetails:NSMutableDictionary = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblStaffDetails.estimatedRowHeight = 30.0
        getStaffDetailsApi()
    }
    
    func getStaffDetailsApi()
    {
        for (index, value) in self.arrStaffHeaderTitle.enumerated() {
            
            var arrStaffDetailTitle:[String] = []
            
            switch(index) {
            case 0:
                arrStaffDetailTitle = [StaffDetailsModal.Name, StaffDetailsModal.Code, StaffDetailsModal.Gender, StaffDetailsModal.DOB, StaffDetailsModal.BloodGroup, StaffDetailsModal.MaritalStatus, StaffDetailsModal.MobileNo, StaffDetailsModal.EmailID, StaffDetailsModal.FatherHusbandName, StaffDetailsModal.Religion, StaffDetailsModal.BankName, StaffDetailsModal.BankAccountNo, StaffDetailsModal.PFAccountNo, StaffDetailsModal.PAN, StaffDetailsModal.ECA, StaffDetailsModal.AS, StaffDetailsModal.RMC, StaffDetailsModal.Comments, StaffDetailsModal.EmergencyNo, StaffDetailsModal.Status, StaffDetailsModal.Term, StaffDetailsModal.Shift, StaffDetailsModal.UserName, StaffDetailsModal.Password]
                
                self.fillData(nil, arrStaffDetailTitle, value)
                
            case 1:
                arrStaffDetailTitle = [StaffDetailsModal.Department, StaffDetailsModal.Designation, StaffDetailsModal.AppointmentOrder, StaffDetailsModal.DOJ, StaffDetailsModal.FO, StaffDetailsModal.Responsibilities, StaffDetailsModal.Board]
                
                self.fillData(nil, arrStaffDetailTitle, value)
                
            default:
                break
            }
        }
        self.tblStaffDetails.reloadData()
    }
    
    func fillData(_ str:String?, _ arrayTitle:[String], _ key:String)
    {
        var arrStaffDetailValue:[String] = []
        
        for value in arrayTitle {
            let itemKey:String = str == nil ? value : "\(str!) \(value)"
            
            if(itemKey == "Status"){
                arrStaffDetailValue.append((dicStaffData[itemKey]?.stringValue)! == "1" ? "Active" : "InActive")
            }else if(itemKey == "Password"){
                arrStaffDetailValue.append(String((dicStaffData[itemKey]?.stringValue)!.characters.map { _ in return "•" }))
            }else {
                arrStaffDetailValue.append((dicStaffData[itemKey]?.stringValue)!)
            }
        }
        self.dicStaffDetails.setValue([arrayTitle,arrStaffDetailValue], forKey: key)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension StaffDetailsVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:StudentProfileCell = tableView.dequeueReusableCell(withIdentifier: "StaffProfileHeaderCell") as! StudentProfileCell
        
        headerView.displayHeaderData(arrStaffHeaderTitle[section], arrStaffHeaderColor[section], selectedIndex == section ? true : false)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        return  headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dicStaffDetails.count > 0 ? arrStaffHeaderTitle.count : 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == selectedIndex {
            return UITableViewAutomaticDimension
        }else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == selectedIndex ? ((dicStaffDetails[arrStaffHeaderTitle[section]] as! NSArray).firstObject as! NSArray).count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:StudentProfileCell = tableView.dequeueReusableCell(withIdentifier: "StaffProfileCell", for: indexPath) as! StudentProfileCell
        
        let array:NSArray = (dicStaffDetails[arrStaffHeaderTitle[indexPath.section]] as! NSArray)
        let arrTitle:[String] = array.firstObject as! [String]
        let arrValue:[String] = array.lastObject as! [String]
        
        cell.bottomSpace.constant = indexPath.row ==  arrTitle.count - 1 ? 1.0 : -1.0
        
        cell.displayRegisterLeftStudentData([arrTitle[indexPath.row], arrValue[indexPath.row]], selectedIndex == indexPath.section ? true : false)
        
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblStaffDetails.reloadSections(IndexSet(integersIn: 0...arrStaffHeaderTitle.count-1), with: .automatic)
        if selectedIndex != -1 {
            self.tblStaffDetails.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: true)
        }
    }
}
