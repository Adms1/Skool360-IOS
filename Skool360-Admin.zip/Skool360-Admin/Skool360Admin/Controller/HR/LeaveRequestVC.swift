//
//  LeaveRequestVC.swift
//  Bhadaj (Teacher)
//
//  Created by ADMS on 30/08/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

var isFromStudent:Bool = false
var notificationModel:NotificationModel!
class LeaveRequestVC: CustomViewController {
    
    @IBOutlet var btnSend:UIButton!
    @IBOutlet var btnStartDate:UIButton!
    @IBOutlet var btnEndDate:UIButton!
    @IBOutlet var tblLeaveDetails:UITableView!
    
    var dicLeaveStatus:[String:String] = [:]
    var arrLeaveStatus:[String] = []
    var arrLeaveDetails = [LeaveModel]()
    
    var leaveDays:Double = 0.6
    var strLeaveStatusID:String!
    var strLeaveStatus:String = "Pending"
    var selectedLeaveModel:LeaveModel!
    var strType:String = "Leave Date"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblLeaveDetails.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).setTitle(notificationModel != nil ? notificationModel.Date : isFromPush ? pushData["Date"] as! String : "", for: .normal)
            }
        }
        
        var i = 10
        for view in view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag == 1 && notificationModel == nil && !isFromPush){
                    radioButton.select(animated: true)
                }else if((notificationModel != nil || isFromPush) && radioButton.tag == 2){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
        
        strType = notificationModel != nil || isFromPush ? "Application Date" : "Leave Date"
        strLeaveStatus = "Pending"
        
        NotificationCenter.default.addObserver(self, selector: #selector(callGetStatusApi), name: .refreshData, object: nil)
        
        self.callGetStatusApi()
    }
    
    private lazy var leaveModifyPopupVC: LeaveModifyPopupVC = {
        
        var viewController:LeaveModifyPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "LeaveModifyPopupVC") as! LeaveModifyPopupVC
        viewController.modifyLeaveBlock = { array in
            
            let idx:NSInteger = self.arrLeaveDetails.index(where: {$0 === selectedLeaveModifyModel})!
            self.arrLeaveDetails[idx].LeaveDate = "\(array[0])-\(array[1])"
            self.arrLeaveDetails[idx].ApproveRejectDays = array[2]
            self.strLeaveStatusID = self.dicLeaveStatus[self.arrLeaveStatus[1]]
            
            self.callUpdateLeaveStatusApi(idx)
        }
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension LeaveRequestVC
{
    @objc func callGetStatusApi()
    {
        arrLeaveStatus = []
        dicLeaveStatus = [:]
        
        Functions.callApi(api: API.getLeaveStatusApi, params: [:]) { (json,error) in
            if(json != nil){
                
                let arrStatus = json!["FinalArray"].array
                
                for values in arrStatus! {
                    self.dicLeaveStatus[values["StatusName"].stringValue] = values["LeaveStatusID"].stringValue
                    
                    if isFromStudent {
                        self.arrLeaveStatus.append(values["StatusName"].stringValue.components(separatedBy: " ").first!)
                    }else {
                        self.arrLeaveStatus.append(values["StatusName"].stringValue)
                    }
                }
                self.addDropDown()
                if(isFromStudent) {
                    self.callGetAllStudentLeaveRequestApi()
                }else {
                    self.callGetAllStaffLeaveRequestApi()
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetStatusApi()
                })
            }
        }
    }
    
    func callGetAllStaffLeaveRequestApi()
    {
        arrLeaveDetails = []
        selectedIndex = -1
        
        let params = ["Type":strType,
                      "FromDate" : btnStartDate.title(for: .normal)!,
                      "ToDate" : btnEndDate.title(for: .normal)!,
                      "LeaveStatusID" : strLeaveStatusID!,
                      "UserID" : adminID!]
        
        Functions.callApi(api: API.getAllStaffLeaveRequestApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrLDetails = json!["FinalArray"].array
                
                for values in arrLDetails! {
                    let leaveLDModel:LeaveModel = LeaveModel.init(empId: values["EmployeeID"].stringValue, empName: values["EmployeeName"].stringValue, applicationDate: values["ApplicationDate"].stringValue, leaveDate: values["LeaveDates"].stringValue, leaveDays: values["LeaveDays"].stringValue, status: values["StatusName"].stringValue, reason: values["Reason"].stringValue, arDays: values["ApproveDays"].stringValue, arBy: values["ApproveByName"].stringValue, approveId: values["PK_LeaveApproveID"].stringValue)
                    
                    if(isFromPush || notificationModel != nil) {
                        if(leaveLDModel.LeaveApproveID == (isFromPush ? pushData["ID"] as! String : notificationModel.PkID)) {
                            self.selectedIndex = 0
                            self.arrLeaveDetails.append(leaveLDModel)
                        }
                    }else{
                        self.arrLeaveDetails.append(leaveLDModel)
                    }
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetAllStaffLeaveRequestApi()
                })
            }
            self.tblLeaveDetails.reloadData()
        }
    }
    
    func callGetAllStudentLeaveRequestApi()
    {
        arrLeaveDetails = []
        selectedIndex = -1
        
        let params = ["Type":strType,
                      "FromDate" : btnStartDate.title(for: .normal)!,
                      "ToDate" : btnEndDate.title(for: .normal)!,
                      "Status" : strLeaveStatus]
        
        Functions.callApi(api: API.getAllStudentLeaveRequestApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrLDetails = json!["FinalArray"].array
                
                for (i,values) in arrLDetails!.enumerated() {
                    let leaveLDModel:LeaveModel = LeaveModel.init(empId: values["Comment"].stringValue, empName: values["StudentName"].stringValue, applicationDate: values["ApplicationDate"].stringValue, leaveDate: values["LeaveDate"].stringValue, leaveDays: values["Standard"].stringValue + " - " + values["ClassName"].stringValue, status: values["Status"].stringValue, reason: values["Reason"].stringValue, arDays: values["ApproveDays"].stringValue, arBy: values["ApproveByName"].stringValue, approveId: values["PK_LeaveID"].stringValue)
                    
                    if(isFromPush || notificationModel != nil) {
                        if(leaveLDModel.LeaveApproveID == (isFromPush ? pushData["ID"] as! String : notificationModel.PkID)) {
                            self.selectedIndex = i
                        }
                    }
                    self.arrLeaveDetails.append(leaveLDModel)
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetAllStaffLeaveRequestApi()
                })
            }
            self.tblLeaveDetails.reloadData()
            if(self.selectedIndex != -1){
                self.tblLeaveDetails.scrollToRow(at: NSIndexPath.init(row: 0, section: self.selectedIndex) as IndexPath, at: .none, animated: false)
            }
        }
    }
    
    func callUpdateLeaveStatusApi(_ idx:NSInteger)
    {
        var params:[String:String] = [:]
        if(isFromStudent)
        {
            params = ["PK_LeaveID" : arrLeaveDetails[idx].LeaveApproveID!,
                      "Status" : strLeaveStatusID!,
                      "UserID" : adminID!]
        }
        else {
            params = ["PK_LeaveApproveID":arrLeaveDetails[idx].LeaveApproveID!,
                      "LeaveStatusID" : strLeaveStatusID!,
                      "FromDate" : (arrLeaveDetails[idx].LeaveDate.components(separatedBy: "-").first)!,
                      "ToDate" : (arrLeaveDetails[idx].LeaveDate.components(separatedBy: "-").last)!,
                      "ApproveDays" : arrLeaveDetails[idx].ApproveRejectDays!,
                      "EmployeeID" : arrLeaveDetails[idx].EmployeeID!,
                      "UserID" : adminID!]
        }
        
        Functions.callApi(api: isFromStudent ? API.updateStudentLeaveRequestStatusApi : API.updateLeaveStatusApi, params: params) { (json,error) in
            if(json != nil){
                self.strLeaveStatusID = self.dicLeaveStatus[self.arrLeaveStatus[0]]
                selectedLeaveModifyModel = nil
                if(notificationModel != nil) {
                    let idx:NSInteger = arrNotificationData.index(where: {$0 === notificationModel})!
                    arrNotificationData.remove(at: idx)
                }
                
                if(isFromStudent) {
                    self.callGetAllStudentLeaveRequestApi()
                }else {
                    self.callGetAllStaffLeaveRequestApi()
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callUpdateLeaveStatusApi(idx)
                })
            }
        }
    }
}

extension LeaveRequestVC
{
    // MARK: - Add DropDown
    
    func addDropDown()
    {
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == 100){
                
                self.strLeaveStatusID = self.dicLeaveStatus[arrLeaveStatus[0]]
                let dropDown:UIDropDown = UIDropDown(frame: view.frame)
                dropDown.tableHeight = CGFloat(arrLeaveStatus.count * 35)
                dropDown.options = arrLeaveStatus
                dropDown.selectedIndex = 0
                dropDown.title.text = arrLeaveStatus[0]
                
                dropDown.didSelect { (option, index) in
                    dropDown.hideTable()
                    self.strLeaveStatusID = self.dicLeaveStatus[option]
                    self.strLeaveStatus = option.components(separatedBy: " ").first!
                }
                self.view.addSubview(dropDown)
            }
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 2 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        if let radioButton:LTHRadioButton = view.viewWithTag(tag) as? LTHRadioButton {
            radioButton.select(animated: true)
        }
        strType = tag == 1 ? "Leave Date" : "Application Date"
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        if(isFromStudent) {
            self.callGetAllStudentLeaveRequestApi()
        }else {
            self.callGetAllStaffLeaveRequestApi()
        }
    }
}

extension LeaveRequestVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:LeaveCell = tableView.dequeueReusableCell(withIdentifier: "LeaveHeader\(isFromStudent ? "S" : "T")Cell") as! LeaveCell
        
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0, 0)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        headerView.btnExpand.transform = .identity
        if section == selectedIndex {
            UIView.animate(withDuration: 0.5, animations: {
                headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
            })
        };
        headerView.displayLeaveRequestHeaderDetails(arrLeaveDetails[section])
        return arrLeaveDetails.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return arrLeaveDetails.count > 0 ? (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50)) : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrLeaveDetails.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblLeaveDetails.rowHeight == 0 ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if isFromStudent {
            strIdentifier = "LeaveSCell\(strLeaveStatus == "Pending" ? "1" : "2")"
        }else {
            strIdentifier = "LeaveTCell\(strLeaveStatus == "Pending" ? "1" : "2")"
        }
        
        let cell:LeaveCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! LeaveCell
        cell.displayLeaveRequestDetails(arrLeaveDetails[indexPath.section])
        
        cell.btnActionBlock = { sender in
            switch (sender.titleLabel?.text)! {
            case "APPROVE", "REJECT":
                if(isFromStudent) {
                    self.strLeaveStatusID = (sender.titleLabel?.text)! == "APPROVE" ? "Approved" : "Rejected"
                }else {
                    self.strLeaveStatusID = self.dicLeaveStatus[self.arrLeaveStatus[(sender.titleLabel?.text)! == "APPROVE" ? 1 : 2]]
                }
                self.callUpdateLeaveStatusApi(indexPath.section)
            default:
                selectedLeaveModifyModel = self.arrLeaveDetails[indexPath.section]
                add(asChildViewController: self.leaveModifyPopupVC, self)
            }
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblLeaveDetails.reloadSections(IndexSet(integersIn: 0...arrLeaveDetails.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblLeaveDetails.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}
