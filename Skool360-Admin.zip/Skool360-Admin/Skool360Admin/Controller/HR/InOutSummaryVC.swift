//
//  InOutSummaryVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 09/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class InOutSummaryVC: CustomViewController {
    
    @IBOutlet weak var tblInOutSummary:UITableView!
    
    var arrInOutSummaryData = [InOutSummaryModel]()
    var month:Int = 0
    var year:Int = 0
    var weeksCount:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        self.addDropDown()
        self.callInOutSummaryDataApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension InOutSummaryVC
{
    @objc func callInOutSummaryDataApi()
    {
        arrInOutSummaryData = []
        
        let strMonth = month > 9 ? "\(month)" : "0\(month)"
        
        let params = ["Month" : strMonth,
            "Year" : "\(year)"]
        
        let date = "01/\(strMonth)/\(year)".toDate(dateFormat: "dd/MM/yyyy")
        let calendar = Calendar.current
        let weekRange = calendar.range(of: .weekOfMonth,
                                       in: .month,
                                       for: date)
        let weeksCount = weekRange?.count ?? 0
        
        let dayRange = calendar.range(of: .day,
                                      in: .month,
                                      for: date)
        let daysCount = dayRange?.count ?? 0
        
        Functions.callApi(api: API.employeeInOutSummaryApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrSummary = json!["FinalArray"].array
                
                for values in arrSummary! {
                    
                    var dayNo:Int = 0
                    
                    var arrSummaryData:[InOutSummaryModel] = []
                    for i in 0..<weeksCount {
                        var arrValues:[Int] = []
                        for (n,_) in DateFormatter().weekdaySymbols.enumerated() {
                            if(i == 0 && n+1 >= (Calendar.current.dateComponents([.weekday], from: date).weekday)!) {
                                dayNo += 1
                            }else if(i > 0 && dayNo < daysCount+1){
                                dayNo += 1
                            }
                            arrValues.append(dayNo > daysCount ? 0 : dayNo)
                        }
                        
                        let inOutSummaryModel:InOutSummaryModel = InOutSummaryModel.init(day1: arrValues[0], day2: arrValues[1], day3: arrValues[2], day4: arrValues[3], day5: arrValues[4], day6: arrValues[5], day7: arrValues[6], sun: values["\(arrValues[0])"].stringValue, mon: values["\(arrValues[1])"].stringValue, tue: values["\(arrValues[2])"].stringValue, wed: values["\(arrValues[3])"].stringValue, thu: values["\(arrValues[4])"].stringValue, fri: values["\(arrValues[5])"].stringValue, sat: values["\(arrValues[6])"].stringValue)
                        
                        arrSummaryData.append(inOutSummaryModel)
                    }
                    self.arrInOutSummaryData.append(InOutSummaryModel.init(teacherName: values["Name"].stringValue, department: values["Department"].stringValue, summaryData: arrSummaryData))
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInOutSummaryDataApi()
                })
            }
            self.tblInOutSummary.reloadData()
        }
    }
}

extension InOutSummaryVC
{
    func addDropDown()
    {
        var i = 300
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag == i){
                view.isHidden = true
                
                switch(i)
                {
                case 300:
                    self.addMonthDropDown()
                    
                case 301:
                    self.addYearDropDown()
                    
                default:
                    break
                }
                i += 1
            }
        }
    }
    
    func addMonthDropDown()
    {
        let date = Date()
        let calendar = Calendar.current
        let month = calendar.component(.month, from: date)
        
        self.month = month
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(300)!.frame)
        dropDown.options = DateFormatter().monthSymbols
        dropDown.tableHeight = CGFloat(5 * 35)
        dropDown.selectedIndex = month-1
        dropDown.title.text = DateFormatter().monthSymbols[month-1]
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.month = index+1
        }
        self.view.addSubview(dropDown)
    }
    
    func addYearDropDown()
    {
        let date = Date()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: date)
        
        self.year = year
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(301)!.frame)
        dropDown.options = ["\(year-1)", "\(year)", "\(year+1)"]
        dropDown.tableHeight = CGFloat(3 * 35)
        dropDown.selectedIndex = 1
        dropDown.title.text = "\(year)"
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.year = Int(option)!
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton){
        self.callInOutSummaryDataApi()
    }
}

extension InOutSummaryVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:InOutSummaryCell = tableView.dequeueReusableCell(withIdentifier: "InOutSummaryHeaderCell") as! InOutSummaryCell
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0, 0)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        headerView.btnExpand.transform = .identity
        if section == selectedIndex {
            UIView.animate(withDuration: 0.5, animations: {
                headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
            })
        };
        headerView.displayInOutSummaryHeaderDetails(arrInOutSummaryData[section], index: section+1)
        
        return arrInOutSummaryData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return arrInOutSummaryData.count > 0 ? (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50)) : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrInOutSummaryData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            return indexPath.row == 0 ? 40 : 75
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblInOutSummary.rowHeight == 0 ? 0 : self.arrInOutSummaryData[section].arrSummaryData.count + 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:InOutSummaryCell = tableView.dequeueReusableCell(withIdentifier: indexPath.row == 0 ? "InOutSummaryCell1" : "InOutSummaryCell", for: indexPath) as! InOutSummaryCell
        
        if(indexPath.row > 0){
            cell.displayInOutSummaryDetails(arrInOutSummaryData[indexPath.section].arrSummaryData[indexPath.row-1])
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblInOutSummary.reloadSections(IndexSet(integersIn: 0...arrInOutSummaryData.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblInOutSummary.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}

