//
//  EmployeePresentDetailsVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 10/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class EmployeePresentDetailsVC: CustomViewController {
    
    @IBOutlet weak var tblEmployeePresentDetails:UITableView!
    
    var arrEmployeePresentData = [EmployeePresentModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblEmployeePresentDetails.tableFooterView = UIView()
        
        for view in self.view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callEmployeeDataApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension EmployeePresentDetailsVC
{
    @objc func callEmployeeDataApi()
    {
        arrEmployeePresentData = []
        
        let params = ["StartDate" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDate" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!]
        
        Functions.callApi(api: (self.title?.contains("In Out"))! ? API.employeeInOutDetailsApi : API.employeePresentDetailsApi, params: params) { (json,error) in
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for (i,values) in arrData!.enumerated() {
                    if(self.title?.contains("In Out"))! {
                        let employeePresentModel:EmployeePresentModel = EmployeePresentModel.init(date: values["OnDate"].stringValue, name: values["EmployeeName"].stringValue, code: values["EmployeeCode"].stringValue, inOutTime: values["InOutDetails"].stringValue, duration: values["WorkingHours"].stringValue)
                        self.arrEmployeePresentData.append(employeePresentModel)
                    }else {
                        let employeePresentModel:EmployeePresentModel = EmployeePresentModel.init(date: values["Date"].stringValue, name: values["EmployeeName"].stringValue, department: values["Department"].stringValue, designation: values["Designation"].stringValue, shift: values["Shift"].stringValue)
                        
                        self.arrEmployeePresentData.append(employeePresentModel)
                    }
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callEmployeeDataApi()
                })
            }
            self.tblEmployeePresentDetails.reloadData()
        }
    }
}

extension EmployeePresentDetailsVC
{
    @IBAction func btnSearchAction(_ sender:UIButton) {
        self.callEmployeeDataApi()
    }
}

extension EmployeePresentDetailsVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:EmployeePresentCell = tableView.dequeueReusableCell(withIdentifier: "EmployeePresentHeaderCell\((self.title?.contains("In Out"))! ? "1" : "")") as! EmployeePresentCell
        
        return arrEmployeePresentData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrEmployeePresentData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrEmployeePresentData.count > 0 ? arrEmployeePresentData.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:EmployeePresentCell = tableView.dequeueReusableCell(withIdentifier: "EmployeePresentCell\((self.title?.contains("In Out"))! ? "1" : "")", for: indexPath) as! EmployeePresentCell
        if(self.title?.contains("In Out"))! {
            cell.displayEmployeeInOutData(arrEmployeePresentData[indexPath.row])
        }else {
            cell.displayEmployeePresentData(arrEmployeePresentData[indexPath.row])
        }
        return cell
    }
}
