//
//  SentInboxVC.swift
//  Skool360Teacher
//
//  Created by ADMS on 29/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import SwiftyJSON

class SentInboxVC: UITableViewController, SentInboxCellDelegate {
    
    var selectedIndex:NSInteger = -1
    var arrIndexSentData = [InboxSentModel]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableFunctions()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callInboxSentApi()
    }
    
    func tableFunctions()
    {
        self.tableView.tableFooterView = UIView()
        
        self.tableView.estimatedRowHeight = 120
        self.tableView.rowHeight = UITableViewAutomaticDimension
        
        self.tableView.estimatedSectionHeaderHeight = 50
        self.tableView.sectionHeaderHeight = UITableViewAutomaticDimension
    }
    
    
    // MARK: - Api Calling
    
    func callInboxSentApi()
    {
        let params = ["UserID":"0",
                      "UserType":"Staff",
                      "MessgaeType":self.title == "Inbox" ? (self.title)! : "Sent"
        ]
        
        print(params)
        
        self.arrIndexSentData = []
        
        Functions.callApi(api: API.ptmTeacherStudentGetDetailApi, params: params) { (json, error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                self.arrIndexSentData = []
                for values in arrData! {
                    
                    let inboxSendModal = InboxSentModel.init(readStatus: values["ReadStatus"].stringValue, userName: values["UserName"].stringValue, fromID:values["FromID"].numberValue, toID:values["ToID"].numberValue, subLine: values["SubjectLine"].stringValue, msgID: values["MessageID"].numberValue, meetingDate: values["MeetingDate"].stringValue, description: values["Description"].stringValue)
                    
                    self.arrIndexSentData.append(inboxSendModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInboxSentApi()
                })
            }
            self.tableView.reloadData()
        }
    }
    
    func callDeleteRequestApi(_ index:NSInteger)
    {
        let params = ["MessageID":(arrIndexSentData[index].MessageID?.stringValue)!]
        
        print(params)
        
        Functions.callApi(api: API.ptmDeleteMeeting, params: params) { (json, error) in
            
            if(json != nil){
                self.arrIndexSentData.remove(at: index)
                self.selectedIndex = -1
                self.tableView.reloadData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeleteRequestApi(index)
                })
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:SentInboxCell = tableView.dequeueReusableCell(withIdentifier: "SentInboxHeaderCell") as! SentInboxCell
        
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0, 0)
        if(section > 0){
            headerView.viewHeight.constant = -5.0
            headerView.contentView.subviews[0].subviews[0].isHidden = true
        }else{
            headerView.viewHeight.constant = 35.0
            headerView.contentView.subviews[0].subviews[0].isHidden = false
        }
        
        var attributedString:NSMutableAttributedString! = NSMutableAttributedString()
        let str:String = headerView.lblView.text!
        var attributes = [NSAttributedStringKey : Any]()
        
        if(section == selectedIndex) {
            attributes = [NSAttributedStringKey(rawValue: NSAttributedStringKey.foregroundColor.rawValue): GetColor.green,NSAttributedStringKey.underlineStyle:NSUnderlineStyle.styleSingle.rawValue,NSAttributedStringKey.font:FontType.mediumFont]
        }else {
            attributes = [NSAttributedStringKey(rawValue: NSAttributedStringKey.foregroundColor.rawValue): GetColor.red,NSAttributedStringKey.underlineStyle:NSUnderlineStyle.styleSingle.rawValue,NSAttributedStringKey.font:FontType.mediumFont]
        }
        attributedString = NSMutableAttributedString(string: str, attributes: attributes)
        headerView.lblView.attributedText = attributedString
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblView.tag = section
        headerView.lblView.addGestureRecognizer(tapGesture)
        
        headerView.displayHeaderData(inboxSentModal: arrIndexSentData[section])
        return headerView.contentView
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        self.tableView.estimatedSectionHeaderHeight = (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50))
        return UITableViewAutomaticDimension
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return arrIndexSentData.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            self.tableView.estimatedRowHeight = DeviceType.isIpad ? 60 : 50
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String = "SentCell"
        if(self.title == "Inbox") {
            strIdentifier = "InboxCell"
        }
        
        let cell:SentInboxCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! SentInboxCell
        if(self.title == "Sent") {
            cell.btnDelete.tag = indexPath.section
            cell.delegate = self
        }
        cell.displayData(inboxSentModal: arrIndexSentData[indexPath.section])
        return cell
    }
    
    func deleteRequest(_ sender: UIButton) {
        self.callDeleteRequestApi(sender.tag)
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        self.callRequestStatusApi(Index)
    }
    
    func callRequestStatusApi(_ idx:NSInteger)
    {
        let modalData:InboxSentModel = arrIndexSentData[idx]
        if(modalData.ReadStatus == "Pending" && self.title == "Inbox"){
            
            let params = ["MessageID":(modalData.MessageID?.stringValue)!,
                          "Flag":"Student",
                          "FromID":(modalData.FromID?.stringValue)!,
                          "ToID":(modalData.ToID?.stringValue)!,
                          "MeetingDate":(modalData.MeetingDate)!,
                          "SubjectLine":(modalData.SubjectLine)!,
                          "Description":(modalData.Description)!
            ]
            
            print(params)
            
            Functions.callApi(api: API.ptmTeacherStudentInsertDetailApi, params: params) { (json, error) in
                
                if(json != nil){
                    
                    modalData.ReadStatus = "Read"
                    self.arrIndexSentData.remove(at: idx)
                    self.arrIndexSentData.insert(modalData, at: idx)
                    self.refreshTable()
                    
                }else if(error != nil) {
                    Functions.showDialog(finish: {
                        self.callRequestStatusApi(idx)
                    })
                }
            }
        }
        refreshTable()
    }
    
    func refreshTable()
    {
        //self.tableView.reloadSections(IndexSet(integersIn: 0...arrIndexSentData.count - 1) as IndexSet, with: .automatic)
        
        self.tableView.reloadData()
        
        if(selectedIndex != -1){
            self.tableView.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: true)
        }
    }
}
