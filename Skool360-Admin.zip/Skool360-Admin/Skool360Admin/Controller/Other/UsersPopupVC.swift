//
//  HomeWorkPopupVC.swift
//  Shilaj (Teacher)
//
//  Created by ADMS on 07/11/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

var strDate:String!
var arrSelectedDailyFeesModel = [DailyFeesCollectionModal]()
var selectedDailyFeesModel:DailyFeesCollectionModal!
class UsersPopupVC: UIViewController {
    
    @IBOutlet var tblUsers:UITableView!
    var arrAllUsers = [UsersModel]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblUsers.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //callGetUsersApi()
        tblUsers.reloadData()
    }
    
    private lazy var viewMarksVC: ViewMarksPopupVC = {
        
        var viewController:ViewMarksPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "ViewMarksPopupVC") as! ViewMarksPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    // MARK: - API Calling
    
    func callGetUsersApi()
    {
        arrAllUsers = []
        
        Functions.callApi(api: API.getLoginDetailsDatewiseApi, params: ["Date" : strDate]) { (json,error) in
            
            if(json != nil){
                
                let arrUsers = json!["FinalArray"].array
                
                for values in arrUsers! {
                    
                    self.arrAllUsers.append(UsersModel(Name: values["Employee Name"].stringValue, Date: values["Login Details"].stringValue.getDate(), UserType: values["Type"].stringValue))
                }
                
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetUsersApi()
                    })
                }
                self.btnClose()
            }
            self.tblUsers.reloadData()
        }
    }
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension UsersPopupVC:UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:DailyFeesCollectionCell = tableView.dequeueReusableCell(withIdentifier: "DailyFeesCollectionHeaderCell") as! DailyFeesCollectionCell
        
        for view in headerView.contentView.subviews[0].subviews.filter({($0.isKind(of: UILabel.classForCoder()))}) {
            let lbl:UILabel = view as! UILabel
            lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 14 : 11)
        }
        
        headerView.displayHData(selectedDailyFeesModel)
        
        return arrSelectedDailyFeesModel.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrSelectedDailyFeesModel.count > 0 ? 140 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrSelectedDailyFeesModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:DailyFeesCollectionCell = tableView.dequeueReusableCell(withIdentifier: "DailyFeesCollectionCell", for: indexPath) as! DailyFeesCollectionCell
        cell.displayData(arrSelectedDailyFeesModel[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        webUrl = URL.init(string: API.hostName + arrSelectedDailyFeesModel[indexPath.row].URL)
        add(asChildViewController: self.viewMarksVC, self)
    }
}
