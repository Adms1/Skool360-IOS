//
//  HomeWorkPopupVC.swift
//  Shilaj (Teacher)
//
//  Created by ADMS on 07/11/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit

var strDate:String!
class UsersPopupVC: UIViewController {
    
    @IBOutlet var tblUsers:UITableView!
    var arrAllUsers = [UsersModel]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        callGetUsersApi()
    }
    
    
    // MARK: - API Calling
    
    func callGetUsersApi()
    {
        arrAllUsers = []
        
        Functions.callApi(api: API.getLoginDetailsDatewiseApi, params: ["Date" : strDate]) { (json,error) in
            
            if(json != nil){
                
                let arrUsers = json!["FinalArray"].array
                
                for values in arrUsers! {
                    
                    self.arrAllUsers.append(UsersModel(Name: values["Employee Name"].stringValue, Date: values["Login Details"].stringValue.getDate(), UserType: values["Type"].stringValue))
                }
                
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetUsersApi()
                    })
                }
                self.btnClose()
            }
            self.tblUsers.reloadData()
        }
    }
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension UsersPopupVC:UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:UserCell = tableView.dequeueReusableCell(withIdentifier: "UserHeaderCell") as! UserCell
        
        for view in headerView.contentView.subviews.filter({($0.isKind(of: UILabel.classForCoder()))}) {
            let lbl:UILabel = view as! UILabel
            lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 16 : 13)
        }
        return arrAllUsers.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrAllUsers.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrAllUsers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:UserCell = tableView.dequeueReusableCell(withIdentifier: "UserCell", for: indexPath) as! UserCell
        cell.displayUsersData(arrAllUsers[indexPath.row])
        return cell
    }
}
