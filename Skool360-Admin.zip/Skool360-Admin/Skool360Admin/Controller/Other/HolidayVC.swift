//
//  HolidayVC.swift
//  Skool360Admin
//
//  Created by ADMS on 08/02/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class HolidayVC: CustomViewController {
    
    @IBOutlet var tblHoliday:UITableView!
    @IBOutlet var btnAddUpdate:UIButton!
    
    var dicHolidayCategory:NSMutableDictionary! = [:]
    var arrHolidayData = [HolidayModel]()
    
    var strCategoryName:String!
    var strCategoryID:String!
    var strHolidayID:String = "0"
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.resetData()
        self.callGetHolidayCategoryApi()
    }
    
    func resetData()
    {
        for view in view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
        
        strHolidayID = "0"
        btnAddUpdate.setTitle(ButtonType.add.rawValue, for: .normal)
        (self.view.viewWithTag(5) as! UITextView).text = "Description"
        (self.view.viewWithTag(5) as! UITextView).textColor = UIColor.gray.withAlphaComponent(0.3)
        self.view.endEditing(true)
    }
    
    // MARK: - API Calling
    
    func callGetHolidayApi()
    {
        arrHolidayData = []
        
        Functions.callApi(api: API.getHolidayApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrHolidayData = json!["FinalArray"].array
                
                for (index,value) in arrHolidayData!.enumerated() {
                    
                    self.arrHolidayData.append(HolidayModel(Index: "\(index+1)", CategoryID:value["PK_CategoryID"].stringValue, HolidayID: value["PK_HolidayID"].stringValue, Holiday: value["Category"].stringValue, StartDate: value["StartDT"].stringValue, EndDate: value["EndDT"].stringValue, Description: value["Description"].stringValue))
                }
                
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetHolidayCategoryApi()
                    })
                }
            }
            self.tblHoliday.reloadData()
        }
    }
    
    func callGetHolidayCategoryApi()
    {
        dicHolidayCategory = [:]
        
        Functions.callApi(api: API.getHolidayCategoryApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrHolidayCategory = json!["FinalArray"].array
                
                for values in arrHolidayCategory! {
                    self.dicHolidayCategory.setValue(values["Pk_CategoryId"].stringValue, forKey: values["Category"].stringValue)
                }
                self.callGetHolidayApi()
                self.addHolidayCategoryDropDown()
                
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetHolidayCategoryApi()
                    })
                }
            }
        }
    }
    
    func callInsertHolidayApi()
    {
        let params = ["StDt" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDT" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!,
                      "Description" : ((self.view.viewWithTag(5) as! UITextView).text)!,
                      "Category" : strCategoryName!,
                      "PK_CategoryID" : strCategoryID!,
                      "PK_HolidayID" : strHolidayID]
        
        print(params)
        
        Functions.callApi(api: API.insertHolidayApi, params: params) { (json,error) in
            
            if(json != nil){
                let msg:String = self.btnAddUpdate.titleLabel?.text == ButtonType.add.rawValue ? Message.recordInsert : Message.recordUpdate
                Functions.showAlert(false, msg)
                
                for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                    view.removeFromSuperview()
                }
                self.addHolidayCategoryDropDown()
                
                self.resetData()
                self.callGetHolidayApi()
                
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callInsertHolidayApi()
                    })
                }
            }
        }
    }
    
    
    func addHolidayCategoryDropDown()
    {
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(2)?.frame)!)
        
        let arrayHoliday = self.dicHolidayCategory.sortedDictionary(self.dicHolidayCategory).0
        strCategoryName = arrayHoliday[0]
        strCategoryID = self.dicHolidayCategory[strCategoryName] as! String
        
        dropDown.options = arrayHoliday
        dropDown.tableHeight = arrayHoliday.count > 5 ? CGFloat(5 * 35) : CGFloat(arrayHoliday.count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = strCategoryName
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strCategoryName = option
            self.strCategoryID = self.dicHolidayCategory[option] as! String
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnInsertUpdateData(_ sender:UIButton)
    {
        self.callInsertHolidayApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension HolidayVC:UITextViewDelegate
{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        if(textView.text == "Description"){
            textView.text = nil
            textView.textColor = .black
        }
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if(text == "\n") {
            if(textView.text.count == 0){
                textView.text = "Description"
                textView.textColor = UIColor.gray.withAlphaComponent(0.3)
            }
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text.count == 0){
            textView.text = "Description"
            textView.textColor = UIColor.gray.withAlphaComponent(0.3)
        }
    }
}

extension HolidayVC:UITableViewDataSource,UITableViewDelegate,CustomCellDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:HolidayCell = tableView.dequeueReusableCell(withIdentifier: "HolidayHeaderCell") as! HolidayCell
        
        return arrHolidayData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrHolidayData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrHolidayData.count > 0 ? arrHolidayData.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:HolidayCell = tableView.dequeueReusableCell(withIdentifier: "HolidayCell", for: indexPath) as! HolidayCell
        
        cell.btnEdit.tag = indexPath.row
        cell.delegate = self
        
        cell.displayData(arrHolidayData[indexPath.row])
        return cell
    }
    
    func performAction(_ sender:UIButton)
    {
        btnAddUpdate.setTitle(ButtonType.update.rawValue, for: .normal)
        
        let holidayModalData:HolidayModel = arrHolidayData[sender.tag]
        
        //1
        
        strCategoryName = holidayModalData.Holiday
        strHolidayID = holidayModalData.HolidayID
        strCategoryID = holidayModalData.CategoryID
        
        for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            let dropDown:UIDropDown = view as! UIDropDown
            dropDown.title.text = strCategoryName
            dropDown.selectedIndex = (self.dicHolidayCategory.allKeys as! [String]).index(of: strCategoryName)
        }
        
        // 2
        (self.view.viewWithTag(3) as! UIButton).setTitle(holidayModalData.StartDate, for: .normal)
        (self.view.viewWithTag(4) as! UIButton).setTitle(holidayModalData.EndDate, for: .normal)
        
        (self.view.viewWithTag(5) as! UITextView).text = holidayModalData.Description
        (self.view.viewWithTag(5) as! UITextView).textColor =  .black
    }
}
