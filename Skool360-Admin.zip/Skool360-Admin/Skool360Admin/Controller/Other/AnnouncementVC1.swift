//
//  CircularVC1.swift
//  Skool360Admin
//
//  Created by ADMS on 19/12/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit

class AnnouncementVC1: CustomViewController {
    
    @IBOutlet var tblCircular:UITableView!
    
    var arrCircularData = [CircularModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblCircular.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetCircularDataApi()
    }
    
    func callGetCircularDataApi()
    {
        self.arrCircularData = []
        
        Functions.callApi(api: API.getAnnouncementDataApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for (index,value) in arrData!.enumerated() {
                    self.arrCircularData.append(CircularModel(Index: "\(index+1)", Cir_Date: value["Cir_Date"].stringValue, Cir_Subject: value["Cir_Subject"].stringValue, Cir_Description: value["Cir_Description"].stringValue, Cir_Order: value["Cir_Order"].stringValue, Cir_Status: value["Cir_Status"].stringValue))
                }
            }else{
                Functions.showAlert(false, Message.noRecordFound)
            }
            self.tblCircular.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AnnouncementVC1:UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:CircularCell = tableView.dequeueReusableCell(withIdentifier: "CircularHeaderCell") as! CircularCell
        for view in headerView.contentView.subviews[0].subviews.filter({($0.isKind(of: UILabel.classForCoder()))}) {
            let lbl:UILabel = view as! UILabel
            lbl.font = FontHelper.medium(size: DeviceType.isIpad ? 16 : DeviceType.isIphone5 ? 10 : 13)
        }
        return arrCircularData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrCircularData.count > 0 ? 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrCircularData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:CircularCell = tableView.dequeueReusableCell(withIdentifier: "CircularCell", for: indexPath) as! CircularCell
        cell.displayCircularData(arrCircularData[indexPath.row])
        return cell
    }
}
