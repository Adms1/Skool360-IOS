//
//  DeshboardVC.swift
//  Skool360Admin
//
//  Created by ADMS on 05/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit

class DeshboardVC: CustomViewController {
    
    @IBOutlet var collectionView:UICollectionView!
    var arrHeaderTitle:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.getDynamicFont()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        arrHeaderTitle = dicData["Main"] as! [String]
        collectionView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension DeshboardVC:UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/2, height: collectionView.frame.size.width/2);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrHeaderTitle.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:DeshBoardCell = collectionView.dequeueReusableCell(withReuseIdentifier: "DeshBoardCell", for: indexPath) as! DeshBoardCell
        cell.bgView.addShadowWithRadius(3.0,15.0, 0)
        cell.displayData("Main",arrHeaderTitle[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let vc:MainVC = Constants.storyBoard.instantiateViewController(withIdentifier: "MainVC") as! MainVC
        vc.title = arrHeaderTitle[indexPath.row]
        arrData = dicData[vc.title!] as! [String]
        self.navigationController?.pushPopTransition(vc,true)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        let animation = CABasicAnimation(keyPath: "cornerRadius")
        animation.fromValue = cell.frame.size.width
        cell.layer.cornerRadius = 0
        animation.toValue = 0
        animation.duration = 1
        cell.layer.add(animation, forKey: animation.keyPath)
    }
}
