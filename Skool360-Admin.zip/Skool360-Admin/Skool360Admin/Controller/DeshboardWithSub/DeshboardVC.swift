//
//  DeshboardVC.swift
//  Skool360Admin
//
//  Created by ADMS on 05/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import SwiftyJSON

var dictPermission:NSMutableDictionary!
class DeshboardVC: CustomViewController {
    
    @IBOutlet var collectionView:UICollectionView!
    @IBOutlet var btnNotification:UIButton!
    @IBOutlet var lblCount:UILabel!
    var arrHeaderTitle:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.getDynamicFont()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        btnNotification.layer.cornerRadius = btnNotification.frame.size.width/2
        lblCount.isHidden = true
        
        self.callGetPermissionApi {
            self.callGetNotificationsApi {
                if isTerminate && isFromPush {
                    self.setNotificationViewController()
                }
            }
        }
    }
    
    func callGetPermissionApi(completion:@escaping () -> ()){
        dictPermission = [:]
        
        let params = ["UserID" : adminID!]
        
        print(params)
        
        Functions.callApi(api: API.getPermissionDataApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for value in arrData! {
                    var subPermission:[String:String] = [:]
                    
                    let array:[JSON] = value["Detail"].array as! [JSON]
                    for subValue in array {
                        subPermission[subValue["PageName"].stringValue] = "\(subValue["Status"].stringValue)-\(subValue["IsUserUpdate"].stringValue)-\(subValue["IsUserDelete"].stringValue)"
                    }
                    dictPermission.setValue(subPermission, forKey: value["Name"].stringValue)
                }
                print(dictPermission)
                
                self.arrHeaderTitle = (dictPermission.allKeys as! [String]).filter { (self.dicData["Main"] as! [String]).contains($0) }
                self.arrHeaderTitle = (self.dicData["Main"] as! [String]).filter { self.arrHeaderTitle.contains($0) }
                self.collectionView.reloadData()
                completion()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetPermissionApi {
                        self.callGetNotificationsApi {}
                    }
                })
            }
            completion()
        }
    }
    
    func callGetNotificationsApi(completion:@escaping () -> ())
    {
        let params = ["StaffID" : adminID!]
        
        print(params)
        
        Functions.callApi(api: API.adminMessageApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                UserDefaults.standard.setValue(json!["DOB"].stringValue, forKey: "DOB")
                Constants.appDelegate.birthday()
                
                var arrNData = [NotificationModel]()
                
                for value in arrData! {
                    let notificationModel:NotificationModel = NotificationModel.init(nId: value["ID"].stringValue, name: value["Name"].stringValue, department: value["Department"].stringValue, uType: value["Type"].stringValue, nType: value["NotificationType"].stringValue, flag: value["Flag"].boolValue, date: value["Date"].stringValue, msg: value["Message"].stringValue, pkid: value["PKID"].stringValue)
                    
                    arrNData.append(notificationModel)
                }
                self.lblCount.text = "\(arrNData.filter{$0.Flag == false}.count)"
                self.lblCount.isHidden = self.lblCount.text == "0"
                completion()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetNotificationsApi {}
                })
            }
            completion()
        }
    }
    
    func setNotificationViewController()
    {
        if((pushData["category"] as! String).caseInsensitiveCompare("Birthday") == .orderedSame){
            Constants.appDelegate.openWishView()
        }
    }
    
    @IBAction func btnNotificationAction(_ sender:UIButton)
    {
        guard !(lblCount.isHidden) else {
            Functions.showAlert(false, "No any notification found")
            return
        }
        let vc:NotificationVC = Constants.storyBoard.instantiateViewController(withIdentifier: "Notifications") as! NotificationVC
        vc.title = "Notifications"
        self.navigationController?.pushPopTransition(vc,true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension DeshboardVC:UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/2, height: collectionView.frame.size.width/2);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrHeaderTitle.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:DeshBoardCell = collectionView.dequeueReusableCell(withReuseIdentifier: "DeshBoardCell", for: indexPath) as! DeshBoardCell
        cell.bgView.addShadowWithRadius(3.0,15.0, 0)
        cell.displayData("Main",arrHeaderTitle[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        isTerminate = false
        isFromPush = false
        
        let vc:MainVC = Constants.storyBoard.instantiateViewController(withIdentifier: "MainVC") as! MainVC
        vc.title = arrHeaderTitle[indexPath.row]
        
        arrData = []
        for (key,value) in dictPermission.value(forKey: arrHeaderTitle[indexPath.row]) as! [String:String] {
            if((dicData[vc.title!] as! [String]).contains(key) && value.components(separatedBy: "-")[0] == "true") {
                arrData.append(key)
            }
        }
        //arrData = (dicData[vc.title!] as! [String]).filter { arrData.contains($0) }
        arrData = dicData[vc.title!] as! [String]
        self.navigationController?.pushPopTransition(vc,true)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        let animation = CABasicAnimation(keyPath: "cornerRadius")
        animation.fromValue = cell.frame.size.width
        cell.layer.cornerRadius = 0
        animation.toValue = 0
        animation.duration = 1
        cell.layer.add(animation, forKey: animation.keyPath)
    }
}
