//
//  WishVC.swift
//  ANBC - Teacher
//
//  Created by ADMS on 01/11/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import SwiftGifOrigin

class WishVC: UIViewController {
    
    @IBOutlet var imgBirthday:UIImageView!
    @IBOutlet var lblName:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        imgBirthday.loadGif(name: "birthday")
        lblName.text = isFromPush ? (pushData["Name"] as! String).replacingOccurrences(of: "||", with: " ").replacingOccurrences(of: "|", with: " ") : "Anand Niketan Bhadaj"
        
        let strMain:String = isFromPush ? pushData["Name"] as! String : "Anand|Niketan|Bhadaj"
        let stringInputArr:[String] = strMain.replacingOccurrences(of: "||", with: "|").components(separatedBy: "|")
        
        let attribute = NSMutableAttributedString.init(string: lblName.text!)
        
        for (_,value) in stringInputArr.enumerated() {
            var range = (lblName.text! as NSString).range(of: value)
            range = NSMakeRange(range.location, 1)
            attribute.addAttribute(NSAttributedStringKey.foregroundColor, value: GetColor.pink, range: range)
        }
        lblName.attributedText = attribute
    }
    
    @IBAction func btnClose()
    {
        self.view.removeFromSuperview()
        self.removeFromParentViewController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
