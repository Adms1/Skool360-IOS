//
//  AssignSubjectVC.swift
//  Skool360Admin
//
//  Created by ADMS on 23/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class AssignSubjectVC: CustomViewController {
    
    @IBOutlet var tblAssignSubject:UITableView!
    @IBOutlet var btnAddUpdate:UIButton!
    
    var arrAssignSubjectData = [AssignSubjectModal]()
    var strAssignID:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var i = 10
        for view in view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag == 2){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.callGetTeachersApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(false) { (success) in
            self.callGetSubjectApi(completion: { (success) in
                self.callGetTeachersApi()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSubjectApi(completion:@escaping (Bool) -> Void)
    {
        dicSubjects = [:]
        
        Functions.callApi(api: API.getSubjectApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySubjects = json!["FinalArray"].array
                
                for value in arraySubjects! {
                    self.dicSubjects.setValue(value["Pk_SubjectID"].stringValue, forKey: value["Subject"].stringValue)
                }
                self.arrSubjects = self.dicSubjects.sortedDictionary(self.dicSubjects).0
                completion(true)
            }
        }
    }
    
    @objc func callGetTeachersApi()
    {
        dicTeachers = [:]
        
        Functions.callApi(api: API.getTeachersByTermIDApi, params: ["TermID" : strTermID]) { (json,error) in
            
            if(json != nil){
                
                let arrayTeachers = json!["FinalArray"].array
                
                for value in arrayTeachers! {
                    self.dicTeachers.setValue(value["EmployeeID"].stringValue, forKey: value["EmployeeName"].stringValue)
                }
                self.arrTeachers = self.dicTeachers.sortedDictionary(self.dicTeachers).0
                self.callGetAssignSubjectsDetailsApi()
            }
        }
    }
    
    @objc func callGetAssignSubjectsDetailsApi()
    {
        self.arrAssignSubjectData = []
        
        Functions.callApi(api: API.getSubjectAssginApi, params: ["Term" : strTermID]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for (index,value) in arrData!.enumerated() {
                    self.arrAssignSubjectData.append(AssignSubjectModal(Index: "\(index+1)", TeacherName: value["TeacherName"].stringValue, Subject: value["Subject"].stringValue, Pk_AssignID: value["Pk_AssignID"].stringValue, Status: value["Status"].stringValue))
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetAssignSubjectsDetailsApi()
                })
            }
            
            for view in self.view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                let dropDown:UIDropDown = view as! UIDropDown
                if(dropDown.table != nil){
                    dropDown.hideTable()
                }
                dropDown.removeFromSuperview()
            }
            
            self.addDropDown()
            self.tblAssignSubject.reloadData()
        }
    }
    
    func callInsertAssignSubjectApi(_ strAssignID:String)
    {
        let params = ["Term" : strTermID,
                      "SubjectID" : self.strSubID!,
                      "Pk_EmployeID" : self.strEmpID!,
                      "Status" : "\(self.strStatusMode)",
                      "Pk_AssignID" : strAssignID]
        
        print(params)
        
        Functions.callApi(api: API.insertAssignSubjectApi, params: params) { (json,error) in
            
            if(json != nil){
                //let value = json!["FinalArray"].array?.first
                
                //                let assignSubjectModal:AssignSubjectModal = AssignSubjectModal.init(index: "\(self.arrAssignSubjectData.count+1)", name: value!["TeacherName"].stringValue, subject: value!["Subject"].stringValue)
                //
                //                self.arrAssignSubjectData.append(assignSubjectModal)
                //                self.tblAssignSubject.reloadData()
                Functions.showAlert(false, strAssignID == "0" ? Message.recordInsert : Message.recordUpdate)
                self.resetData()
                self.callGetAssignSubjectsDetailsApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertAssignSubjectApi(strAssignID)
                })
            }
        }
    }
    
    func callDeleteAssignSubjectsApi(_ strAssignID:String)
    {
        let params = ["Pk_AssignID" : strAssignID]
        
        print(params)
        
        Functions.callApi(api: API.deleteAssginSubjectApi, params: params) { (json,error) in
            
            if(json != nil){
                
                Functions.showAlert(false, Message.recordDelete)
                self.resetData()
                self.callGetAssignSubjectsDetailsApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeleteAssignSubjectsApi(strAssignID)
                })
            }
        }
    }
    
    func resetData()
    {
        for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            view.removeFromSuperview()
        }
        self.addDropDown()
        btnAddUpdate.setTitle(ButtonType.save.rawValue, for: .normal)
        self.resetRadioButton(.active)
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 2 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        let radioButton:LTHRadioButton = view.viewWithTag(tag) as! LTHRadioButton
        radioButton.select(animated: true)
        strStatusMode = tag-1
    }
    
    func resetRadioButton(_ mode:StatusMode)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        strStatusMode = mode == .active ? 1 : 0
        let radioButton:LTHRadioButton = view.viewWithTag(strStatusMode+1) as! LTHRadioButton
        radioButton.select(animated: true)
    }
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 3
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 3:
                    self.addTermDropDown(view)
                    
                case 4:
                    self.addTeacherDropDown()
                    
                default:
                    self.addSubjectDropDown()
                }
                i += 1
            }
        }
    }
    
    func addTeacherDropDown()
    {
        self.strEmpID = dicTeachers.value(forKey: self.arrTeachers[0]) as! String
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(4)!.frame)
        dropDown.options = self.arrTeachers
        dropDown.tableHeight = self.arrTeachers.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrTeachers .count * 35)
        dropDown.selectedIndex = 0
        dropDown.tag = 4
        dropDown.title.text = self.arrTeachers[0]
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strEmpID = self.dicTeachers.value(forKey: option) as! String
        }
        self.view.addSubview(dropDown)
    }
    
    func addSubjectDropDown()
    {
        self.strSubID = dicSubjects.value(forKey: self.arrSubjects[0]) as! String
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(5)!.frame)
        dropDown.options = self.arrSubjects
        dropDown.tableHeight = self.arrSubjects.count > 5 ? CGFloat(5 * 35) : CGFloat(self.arrSubjects .count * 35)
        dropDown.selectedIndex = 0
        dropDown.tag = 5
        dropDown.title.text = self.arrSubjects[0]
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strSubID = self.dicSubjects.value(forKey: option) as! String
        }
        self.view.addSubview(dropDown)
    }
    
    @IBAction func btnInsertData(_ sender:UIButton)
    {
        if strEmpID == "0" {
            Functions.showAlert(false, Message.selectEmployee)
            return
        }
        self.callInsertAssignSubjectApi(sender.title(for: .normal) == ButtonType.update.rawValue ? self.strAssignID : "0")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AssignSubjectVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:AssignSubjectCell = tableView.dequeueReusableCell(withIdentifier: "AssignSubjectHeaderCell") as! AssignSubjectCell
        
        return arrAssignSubjectData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrAssignSubjectData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAssignSubjectData.count > 0 ? arrAssignSubjectData.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:AssignSubjectCell = tableView.dequeueReusableCell(withIdentifier: "AssignSubjectCell", for: indexPath) as! AssignSubjectCell
        
        cell.displayData(arrAssignSubjectData[indexPath.row])
        let arrBtns = cell.contentView.subviews[0].subviews.filter{$0 is UIButton}
        arrBtns.forEach{$0.tag = indexPath.row}
        return cell
    }
    
    @IBAction func btnEditAction(_ sender:UIButton)
    {
        if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[1] == "true") {
            
            btnAddUpdate.setTitle(ButtonType.update.rawValue, for: .normal)
            
            let assignSubjectModel:AssignSubjectModal = self.arrAssignSubjectData[sender.tag]
            self.strAssignID = assignSubjectModel.Pk_AssignID
            
            // 4,5
            for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                let dropDown:UIDropDown = view as! UIDropDown
                
                var strValue:String!
                switch(dropDown.tag)
                {
                case 4:
                    strValue = assignSubjectModel.TeacherName
                    self.strEmpID = "0"
                    if let empId = self.dicTeachers.value(forKey: strValue) as? String {
                        self.strEmpID = empId
                    }
                    if self.strEmpID != "0" {
                        dropDown.selectedIndex = arrTeachers.index(of: strValue)!
                    }else{
                        strValue = "-Please select-"
                    }
                case 5:
                    strValue = assignSubjectModel.Subject
                    self.strSubID = self.dicSubjects.value(forKey: strValue) as! String
                    dropDown.selectedIndex = self.arrSubjects.index(of: strValue)!
                default:
                    strValue = strTerm
                }
                dropDown.title.text = strValue
            }
            self.resetRadioButton(assignSubjectModel.Status == "Active" ? .active : .inActive)
        }else{
            Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "edit"))
        }
    }
    
    @IBAction func btnDeleteAction(_ sender:UIButton)
    {
        if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[2] == "true") {
            Functions.showCustomAlert("Delete", Message.deleteConfirmation) { (_) in
                self.callDeleteAssignSubjectsApi(self.arrAssignSubjectData[sender.tag].Pk_AssignID)
            }
        }else{
            Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "delete"))
        }
    }
}

