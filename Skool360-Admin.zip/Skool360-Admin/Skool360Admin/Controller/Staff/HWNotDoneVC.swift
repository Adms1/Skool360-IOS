//
//  HWNotDoneVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 12/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class HWNotDoneVC: CustomViewController {
    
    @IBOutlet weak var tblHW:UITableView!
    @IBOutlet weak var btnStartDate:UIButton!
    @IBOutlet weak var btnInsertUpdate:UIButton!
    
    var arrHomeWorkStatus = [HomeWorkStatusModel]()
    var arrHomeWorkStatusChanges:[String] = []
    var strHomeWorkStatus = 0
    var status:Int = 2
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.resetData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTeachersApi { (_) in
            self.addDropDown()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension HWNotDoneVC
{
    func callGetTeachersApi(completion:@escaping (Bool) -> Void)
    {
        dicTeachers = [:]
        
        Functions.callApi(api: API.getTeacherlistApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrayTeachers = json!["FinalArray"].array
                
                for value in arrayTeachers! {
                    self.dicTeachers.setValue(value["EmployeeID"].stringValue, forKey: value["EmployeeName"].stringValue)
                }
                self.arrTeachers = self.dicTeachers.sortedDictionary(self.dicTeachers).0
                completion(true)
            }
        }
    }
    
    func callGetStdSectionsApi()
    {
        let params = ["EmployeeID" : self.strEmpID!]
        
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardTeacherApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayStdSection = json!["FinalArray"].array
                
                for value in arrayStdSection! {
                    self.dicStdSections.setValue("\(value["StandardID"].stringValue)-\(value["ClassID"].stringValue)", forKey: value["Standard"].stringValue)
                }
                self.arrStandards = self.dicStdSections.sortedDictionary(self.dicStdSections).0
                self.addStdSectionsDropDown()
            }
        }
    }
    
    func callGetSubjectsApi()
    {
        let params = ["EmployeeID" : self.strEmpID!,
                      "StandardID" : self.strStdID!,
                      "ClassID" : self.strClassID!]
        
        dicSubjects = [:]
        
        Functions.callApi(api: API.getSubjectByTeacherApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arraySubject = json!["FinalArray"].array
                
                for value in arraySubject! {
                    self.dicSubjects.setValue(value["SubjectID"].stringValue, forKey: value["Subject"].stringValue)
                }
                self.arrSubjects = self.dicSubjects.sortedDictionary(self.dicSubjects).0
                self.addSubDropDown()
            }
        }
    }
    
    func callHomeWorkStatusApi()
    {
        let params = ["TermID":"0",
                      "Date":(btnStartDate.title(for: .normal))!,
                      "StandardID":strStdID!,
                      "ClassID":strClassID!,
                      "SubjectID":strSubID!]
        
        print(params)
        
        self.arrHomeWorkStatus = []
        self.arrHomeWorkStatusChanges = []
        self.btnInsertUpdate.isHidden = true
        
        Functions.callApi(api: API.teacherStudentHomeworkStatusApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrHWStatus = json!["FinalArray"].array
                
                for (i,values) in arrHWStatus!.enumerated() {
                    let homeWorkStatusModal:HomeWorkStatusModel = HomeWorkStatusModel.init(stuId: values["StudentID"].stringValue, stuName: values["StudentName"].stringValue, homeWorkId: values["HomeWorkID"].stringValue, homeWorkDetailId:values["HomeWorkDetailID"].stringValue,  homeWorkStatus: values["HomeWorkStatus"].intValue)
                    
                    if(i == 0){
                        self.btnInsertUpdate.isHidden = false
                        self.btnInsertUpdate.setTitle(values["HomeWorkStatus"].intValue == -1 ? "Submit" : "Update", for: .normal)
                        self.strHomeWorkStatus = values["HomeWorkStatus"].intValue == -1 ? values["HomeWorkStatus"].intValue : self.strHomeWorkStatus
                    }
                    self.arrHomeWorkStatusChanges.append("\(homeWorkStatusModal.HomeWorkDetailID!),\(homeWorkStatusModal.StudentID!),\(homeWorkStatusModal.HomeWorkStatus == -1 ? 1 : homeWorkStatusModal.HomeWorkStatus!)")
                    self.arrHomeWorkStatus.append(homeWorkStatusModal)
                }
            }else if(error != nil){
                Functions.showDialog(finish: {
                    self.callHomeWorkStatusApi()
                })
            }
            self.tblHW.reloadData()
        }
    }
    
    func callInsertUpdateHomeWorkStatusApi()
    {
        let params = ["Date":(btnStartDate.title(for: .normal))!,
                      "StandardID":strStdID!,
                      "ClassID":strClassID!,
                      "SubjectID":strSubID!,
                      "HomeWorkID" : arrHomeWorkStatus[0].HomeWorkID!,
                      "HomeWorkDetailID" : arrHomeWorkStatusChanges.joined(separator: "|")]
        
        print(params)
        
        Functions.callApi(api: API.teacherStudentHomeworkStatusInsertUpdateApi, params: params) { (json,error) in
            
            if(json != nil){
                Functions.showAlert(true, self.strHomeWorkStatus == -1 ? Message.homeworkStatusAddSuccess : Message.homeworkStatusUpdateSuccess)
                self.resetData()
                self.addDropDown()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertUpdateHomeWorkStatusApi()
                })
            }
        }
    }
}

extension HWNotDoneVC
{
    func resetData()
    {
        self.btnStartDate.setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
        for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            let dropDown:UIDropDown = view as! UIDropDown
            if(dropDown.table != nil){
                dropDown.hideTable()
            }
            dropDown.removeFromSuperview()
        }
    }
    
    func addDropDown()
    {
        var i = 10
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 10:
                    self.addTeachersDropDown()
                    
                case 20:
                    self.callGetStdSectionsApi()
                    
                default:
                    break
                }
                i += 10
            }
        }
    }
    
    func addTeachersDropDown()
    {
        self.strEmpID = self.dicTeachers.value(forKey: self.arrTeachers[0]) as! String
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(10)!.frame)
        dropDown.options = self.arrTeachers
        dropDown.tableHeight = self.arrTeachers.count > 5 ? 5 * 35 : CGFloat(self.arrTeachers.count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = self.arrTeachers[0]
        dropDown.tag = 100
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strEmpID = self.dicTeachers.value(forKey: option) as! String
            self.callGetStdSectionsApi()
        }
        self.view.addSubview(dropDown)
    }
    
    func addStdSectionsDropDown()
    {
        if let dropDown = self.view.viewWithTag(200) as? UIDropDown {
            if(dropDown.table != nil){
                dropDown.hideTable()
            }
            dropDown.removeFromSuperview()
        }
        
        self.strStdID = (self.dicStdSections.value(forKey: self.arrStandards[0]) as! String).components(separatedBy: "-").first!
        self.strClassID = (self.dicStdSections.value(forKey: self.arrStandards[0]) as! String).components(separatedBy: "-").last!
        
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(20)!.frame)
        dropDown.options = self.arrStandards
        dropDown.tableHeight = self.arrStandards.count > 5 ? 5 * 35 : CGFloat(self.arrStandards.count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = arrStandards[0]
        dropDown.tag = 200
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strStdID = (self.dicStdSections.value(forKey: option) as! String).components(separatedBy: "-").first!
            self.strClassID = (self.dicStdSections.value(forKey: option) as! String).components(separatedBy: "-").last!
            self.callGetSubjectsApi()
        }
        self.view.addSubview(dropDown)
        self.callGetSubjectsApi()
    }
    
    func addSubDropDown()
    {
        if let dropDown = self.view.viewWithTag(300) as? UIDropDown {
            if(dropDown.table != nil){
                dropDown.hideTable()
            }
            dropDown.removeFromSuperview()
        }
        
        self.strSubID = self.dicSubjects.value(forKey: self.arrSubjects[0]) as! String
        let dropDown:UIDropDown = UIDropDown(frame: view.viewWithTag(30)!.frame)
        dropDown.options = self.arrSubjects
        dropDown.tableHeight = self.arrSubjects.count > 5 ? 5 * 35 : CGFloat(self.arrSubjects.count * 35)
        dropDown.selectedIndex = 0
        dropDown.title.text = arrSubjects[0]
        dropDown.tag = 300
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strSubID = self.dicSubjects.value(forKey: option) as! String
        }
        self.view.addSubview(dropDown)
        self.callHomeWorkStatusApi()
    }
    
    // MARK: - Button Click Actions
    
    @IBAction func btnStudentHomeWorkStatusChangeAction(_ sender:UIButton)
    {
        self.callInsertUpdateHomeWorkStatusApi()
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callHomeWorkStatusApi()
    }
}

extension HWNotDoneVC:UITableViewDelegate,UITableViewDataSource,HomeWorkStatusCellDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:HomeWorkStatusCell = tableView.dequeueReusableCell(withIdentifier: "HomeWorkStatusHeaderCell") as! HomeWorkStatusCell
        
        headerView.delegate = self
        headerView.displayData(arrHomeWorkStatus[0], true, status)
        
        return arrHomeWorkStatus.count > 0 ? headerView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrHomeWorkStatus.count > 0 ? DeviceType.isIpad ? 50 : 45 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrHomeWorkStatus.count > 0 ? arrHomeWorkStatus.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:HomeWorkStatusCell = tableView.dequeueReusableCell(withIdentifier: "HomeWorkStatusCell", for: indexPath) as! HomeWorkStatusCell
        
        cell.delegate = self
        cell.tag = (indexPath.row+1)*100
        cell.displayData(arrHomeWorkStatus[indexPath.row], false, status)
        
        return cell
    }
    
    func studentHomeWorkStatusUpdate(_ idx:NSInteger, _ superViewTag:NSInteger)
    {
        let hwModal:HomeWorkStatusModel = arrHomeWorkStatus[superViewTag]
        hwModal.HomeWorkStatus = idx
        
        self.arrHomeWorkStatus.remove(at: superViewTag)
        self.arrHomeWorkStatus.insert(hwModal, at: superViewTag)
        
        self.arrHomeWorkStatusChanges.remove(at: superViewTag)
        self.arrHomeWorkStatusChanges.insert("\(hwModal.HomeWorkDetailID!),\(hwModal.StudentID!),\(idx)", at: superViewTag)
        
        self.tblHW.reloadRows(at: [IndexPath.init(row: superViewTag, section: 0)], with: .automatic)
    }
    
    func studentHomeWorkStatusUpdate(_ idx: NSInteger)
    {
        self.status = idx + 1
        
        for i in 0..<arrHomeWorkStatus.count
        {
            let hwModal:HomeWorkStatusModel = arrHomeWorkStatus[i]
            hwModal.HomeWorkStatus = idx
            
            self.arrHomeWorkStatus.remove(at: i)
            self.arrHomeWorkStatus.insert(hwModal, at: i)
            
            self.arrHomeWorkStatusChanges.remove(at: i)
            self.arrHomeWorkStatusChanges.insert("\(hwModal.HomeWorkDetailID!),\(hwModal.StudentID!),\(idx)", at: i)
            
            self.tblHW.reloadData()
        }
    }
}
