//
//  ScheduleVC.swift
//  Skool360Teacher
//
//  Created by ADMS on 18/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import UIDropDown

class TimeTableVC: CustomViewController, TimeTablePopupVCDelagate {
    
    @IBOutlet var tblTimeTable:UITableView!
    
    var dicTimeTable:NSMutableDictionary = [:]
    let arrayDays:Array = DateFormatter().weekdaySymbols
    var arrStdClass:[String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        tblTimeTable.tableFooterView = UIView()
        self.callGetTermApi(true) { (success) in
            self.callGetSectionsApi(completion: { (success) in
                self.addDropDown()
                self.callTimeTableApi()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        arrStdClass = []
        
        Functions.callApi(api: API.getStandardSectionCombineApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    self.arrStdClass.append(value["StandardClass"].stringValue)
                    self.dicStdSections.setValue(value["ClassID"].stringValue, forKey: value["StandardClass"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    // MARK: API Calling
    
    func callTimeTableApi()
    {
        let params = ["TermID":strTermID,
                      "ClassID":self.strClassID!]
        
        Functions.callApi(api: API.getTimetableByClassApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrTimeTbl = json!["FinalArray"].array
                for values in arrTimeTbl! {
                    
                    var arrTimeTable = [TimeTableModel]()
                    for arrValue in values["Data"].array! {
                        
                        var arrSubData = [TimeTableModel]()
                        for arrSubValue in arrValue["Data"].array! {
                            arrSubData.append(TimeTableModel.init(subject: arrSubValue["Subject"].stringValue, teacherName: arrSubValue["TeacherName"].stringValue, timeTableId: arrSubValue["TimetableID"].stringValue))
                        }
                        
                        let timetblModal:TimeTableModel = TimeTableModel.init(lecture: arrValue["Lecture"].numberValue, subData: arrSubData)
                        
                        arrTimeTable.append(timetblModal)
                    }
                    self.dicTimeTable.setValue(arrTimeTable, forKey: values["Day"].stringValue)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callTimeTableApi()
                })
            }
            self.tblTimeTable.reloadData()
        }
    }
    
    func callDeleteTimeTableApi(_ strTimeTableID:String)
    {
        let params = ["TimetableID" : strTimeTableID]
        
        print(params)
        
        Functions.callApi(api: API.deleteTimetableApi, params: params) { (json,error) in
            
            if(json != nil){
                
                Functions.showAlert(false, Message.recordDelete)
                self.callTimeTableApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeleteTimeTableApi(strTimeTableID)
                })
            }
        }
    }
    
    private lazy var timeTablePopupVC: TimeTablePopupVC = {
        
        var viewController:TimeTablePopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "TimeTablePopupVC") as! TimeTablePopupVC
        viewController.delegate = self
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension TimeTableVC
{
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 2:
                    self.addStandardSectionDropDown(view)
                default:
                    self.addTermDropDown(view)
                }
                i += 1
            }
        }
    }
    
    func addStandardSectionDropDown(_ subView:UIView)
    {
        let dropDown:UIDropDown = UIDropDown(frame: subView.frame)
        dropDown.tag = subView.tag
        
        //arrSections = self.dicStdSections.sortedDictionary(self.dicStdSections).0
        
        dropDown.options = arrStdClass
        dropDown.tableHeight = arrStdClass.count > 5 ? CGFloat(5 * 35) : CGFloat(arrStdClass.count * 35)
        
        strClass = arrStdClass[0]
        strClassID = self.dicStdSections.value(forKey: strClass) as? String
        dropDown.title.text = strClass
        dropDown.selectedIndex = 0
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            self.strClass = self.arrStdClass[index]
            self.strClassID = self.dicStdSections.value(forKey: self.strClass) as? String
        }
        view.addSubview(dropDown)
    }
}

extension TimeTableVC:UITableViewDelegate,UITableViewDataSource
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:TimeTableCell = tableView.dequeueReusableCell(withIdentifier: "TimeTableHeaderCell") as! TimeTableCell
        
        headerView.contentView.subviews[0].addShadowWithRadius(2.0, 0, 0)
        let keys = self.dicTimeTable.allKeys as! [String]
        headerView.lblDay.text = keys[keys.index(of: arrayDays[section+1])!]
        
        if(section == selectedIndex) {
            strDayName = headerView.lblDay.text!
            headerView.lblDay.textColor = GetColor.green
        }else {
            headerView.lblDay.textColor = GetColor.orange
        }
        
        headerView.lblDay.font = FontHelper.medium(size: DeviceType.isIpad ? 22 : 18)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.dicTimeTable.allKeys.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let keys = self.dicTimeTable.allKeys as! [String]
        return (dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[section+1])!]) as! [TimeTableModel]).count > 0 ? (dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[section+1])!]) as! [TimeTableModel]).count + 1 : 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            let keys = self.dicTimeTable.allKeys as! [String]
            return CGFloat(indexPath.row == 0 ? DeviceType.isIpad ? 50 : 40 : ((dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[indexPath.section+1])!]) as! [TimeTableModel])[indexPath.row-1].arrSubData.count) == 0 ? 50 : ((dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[indexPath.section+1])!]) as! [TimeTableModel])[indexPath.row-1].arrSubData.count * 115))
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        if(indexPath.row == 0) {
            strIdentifier = "TimeTableCellHeader"
        }
        else {
            strIdentifier = "TimeTableCell"
        }
        
        let cell:TimeTableCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! TimeTableCell
        
        if(indexPath.row > 0) {
            let keys = self.dicTimeTable.allKeys as! [String]
            let tblModal:TimeTableModel = (dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[indexPath.section + 1])!]) as! [TimeTableModel])[indexPath.row-1]
            
            cell.displayData(timeTblData: tblModal)
            cell.contentView.tag = indexPath.section + 1
            cell.collection.tag = indexPath.row - 1
            cell.collection.reloadData()
            
            cell.btnAdd.tag = indexPath.row
            cell.btnAdd.accessibilityValue = "1"
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblTimeTable.beginUpdates()
        tblTimeTable.reloadData()
        tblTimeTable.endUpdates()
        
        if(selectedIndex != -1){
            self.tblTimeTable.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .top, animated: true)
        }
    }
}

extension TimeTableVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let keys = self.dicTimeTable.allKeys as! [String]
        return (dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[(collectionView.superview?.tag)!])!]) as! [TimeTableModel])[collectionView.tag].arrSubData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width, height: 115)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let collectionCell:TimeTableCollectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "TimeTableCollectionCell", for: indexPath) as! TimeTableCollectionCell
        
        let keys = self.dicTimeTable.allKeys as! [String]
        let arrTimeTableData = (dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[(collectionView.superview?.tag)!])!]) as! [TimeTableModel])[collectionView.tag].arrSubData
        
        collectionCell.btnEdit.tag = indexPath.row
        collectionCell.btnDelete.tag = indexPath.row
        collectionCell.btnEdit.accessibilityValue = "0"
        
        collectionCell.displayData(arrTimeTableData[indexPath.row])
        return collectionCell
    }
}

extension TimeTableVC
{
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callTimeTableApi()
    }
    
    @IBAction func btnAddUpdate(_ sender:UIButton)
    {
        let superTag:NSInteger = (sender.superview?.superview?.superview?.superview!.superview!.tag)!
        let subTag:NSInteger = (sender.superview?.superview?.superview?.superview!.tag)!
        
        let keys = self.dicTimeTable.allKeys as! [String]
        
        if sender.accessibilityValue == "0" {
            if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[1] == "true") {
                let arrTimeTableData = (dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[superTag])!]) as! [TimeTableModel])[subTag].arrSubData
                strSubject = arrTimeTableData[sender.tag].Subject!
                strTeacher = arrTimeTableData[sender.tag].strTeacherName!
                strTimeTableID = arrTimeTableData[sender.tag].strTimetableID!
                strLectureName = ((dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[superTag])!]) as! [TimeTableModel])[subTag].Lecture?.stringValue)!
            }
            else{
                Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "edit"))
                return
            }
        }else {
            strSubject = ""
            strTeacher = ""
            strTimeTableID = "0"
            strLectureName = ((dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[sender.superview!.tag])!]) as! [TimeTableModel])[(sender.tag)-1].Lecture?.stringValue)!
        }
        strSelectedClassID = strClassID!
        strSelectedTermID = strTermID
        add(asChildViewController: timeTablePopupVC, self)
    }
    
    @IBAction func btnDelete(_ sender:UIButton)
    {
        if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[2] == "true") {
            let keys = self.dicTimeTable.allKeys as! [String]
            
            let superTag:NSInteger = (sender.superview?.superview?.superview?.superview!.superview!.tag)!
            let subTag:NSInteger = (sender.superview?.superview?.superview?.superview!.tag)!
            
            let arrTimeTableData = (dicTimeTable.value(forKey: keys[keys.index(of: arrayDays[superTag])!]) as! [TimeTableModel])[subTag].arrSubData
            
            Functions.showCustomAlert("Delete", Message.deleteConfirmation) { (_) in
                self.callDeleteTimeTableApi(arrTimeTableData[sender.tag].strTimetableID!)
            }
        }
        else{
            Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "delete"))
        }
    }
}
