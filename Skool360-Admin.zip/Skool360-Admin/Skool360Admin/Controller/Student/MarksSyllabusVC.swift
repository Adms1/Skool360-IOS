//
//  MarksSyllabusVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 01/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class MarksSyllabusVC: CustomViewController {
    
    @IBOutlet var collectionExam:UICollectionView!
    @IBOutlet var tblMarksSyllabus:UITableView!
    @IBOutlet var btnAddUpdate:UIButton!
    @IBOutlet var collectionHeight:NSLayoutConstraint!
    
    var arrExamSelectedIds:[String] = []
    var arrExams:[String] = []
    var dictExamData:[String:String] = [:]
    var arrPermissionData = [PermissionModel]()
    var arrTypes:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,selector: #selector(resetData),name: .callApi,object: nil)
        
        var i = 10
        for view in view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag == 2){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox   = view as! VKCheckbox
                checkBox.line             = .normal
                checkBox.bgColorSelected  = GetColor.blue
                checkBox.color            = .white
                checkBox.borderColor      = GetColor.blue
                checkBox.borderWidth      = 1.0
                checkBox.cornerRadius     = 5.0
                checkBox.setOn(false)
                
                checkBox.checkboxValueChangedBlock = { isOn in
                    self.updateCheckBoxValue(checkBox)
                }
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: i > 20 ? #selector(checkBoxSelectUnSelectAction(_:)) : #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.arrStandards = []
        self.callGetTermApi(true) { (success) in
            self.resetData()
        }
    }
    
    @objc func resetData()
    {
        btnAddUpdate.setTitle(ButtonType.add.rawValue, for: .normal)
        self.callGetMarkSyllabusApi()
        self.arrTypes = []
        self.strStatusMode = 0
        self.resetRadioButton(.active)
        self.arrExamSelectedIds = []
        
        for checkBox in view.subviews.filter({($0.isKind(of: VKCheckbox.classForCoder()))}) {
            (checkBox as! VKCheckbox).setOn(false, animated: false)
        }
        
        for dropDown in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
//            if(dropDown.table != nil){
//                dropDown.hideTable()
//            }
            dropDown.removeFromSuperview()
        }
        self.addDropDown()
        self.callGetExamApi()
    }
    
    func updateCheckBoxValue(_ checkBox:VKCheckbox)
    {
        switch(checkBox.tag)
        {
        case 3:
            if(checkBox.isOn()) {
                if(!(self.arrTypes.contains("R"))){
                    self.arrTypes.append("R")
                }
            }else{
                self.arrTypes.remove(at: self.arrTypes.index(of: "R")!)
            }
        default:
            if(checkBox.isOn()) {
                if(!(self.arrTypes.contains("S"))){
                    self.arrTypes.append("S")
                }
            }else{
                self.arrTypes.remove(at: self.arrTypes.index(of: "S")!)
            }
        }
    }
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 100
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 100:
                    self.addTermDropDown(view)
                    
                case 200:
                    self.addStandardDropDown(view)
                    
                default:
                    break
                }
                i += 100
            }
        }
    }
    
    @objc func checkBoxSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        let tag:NSInteger = (gesture.view?.tag)!/10
        if let checkBox = self.view.viewWithTag(tag) as? VKCheckbox {
            checkBox.setOn(!(checkBox.isOn()), animated: true)
            self.updateCheckBoxValue(checkBox)
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 2 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        let radioButton:LTHRadioButton = view.viewWithTag(tag) as! LTHRadioButton
        radioButton.select(animated: true)
        strStatusMode = tag-1
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MarksSyllabusVC
{
    @objc func callGetExamApi()
    {
        arrExams = []
        dictExamData = [:]
        
        let params = ["TermID" : strTermID,
                      "GradeID" : strStdID!]
        
        Functions.callApi(api: API.getTestNameForMarksSyllabusPermissionApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrExamData = json!["FinalArray"].array
                
                for (_,value) in arrExamData!.enumerated() {
                    self.arrExams.append(value["TestName"].stringValue)
                    self.dictExamData[value["TestName"].stringValue] = value["TestID"].stringValue
                }
            }else {
                if(error != nil){
                    Functions.showDialog(finish: {
                        self.callGetExamApi()
                    })
                }
            }
            
            let height:CGFloat = CGFloat(self.arrExams.count == 0 ? 30 : self.arrExams.count > 3 ? 100 : (self.arrExams.count * 30))
            self.collectionHeight.constant = height
            self.collectionExam.reloadData()
        }
    }
    
    func callInsertUpdateMarkSyllabusApi(_ strPermissionID:String)
    {
        let params = ["TermID" :strTermID,
                      "Type" : arrTypes.joined(separator: ","),
                      "GradeID" : strStdID!,
                      "Exams" : arrExamSelectedIds.joined(separator: ","),
                      "Status" : "\(self.strStatusMode)",
            "PermissionID" : strPermissionID]
        
        print(params)
        
        Functions.callApi(api: API.insertMarksSyllabusPermissionApi, params: params) { (json,error) in
            
            if(json != nil){
                let msg:String = self.btnAddUpdate.titleLabel?.text == ButtonType.add.rawValue ? Message.recordInsert : Message.recordUpdate
                Functions.showAlert(false, msg)
                self.resetData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertUpdateMarkSyllabusApi(strPermissionID)
                })
            }
        }
    }
    
    func callGetMarkSyllabusApi()
    {
        arrPermissionData = []
        
        Functions.callApi(api: API.getMarksSyllabusPermissionApi, params: ["TermID" :strTermID]) { (json,error) in
            
            if(json != nil){
                let arrPermissionData = json!["FinalArray"].array
                
                for (_,value) in arrPermissionData!.enumerated() {
                    self.arrPermissionData.append(PermissionModel.init(permissionId: value["PermissionID"].stringValue, type: value["Type"].stringValue, standard: value["Standard"].stringValue, cls: value["ClassName"].stringValue, status: value["Status"].stringValue, testName: value["TestName"].stringValue, term: value["Term"].stringValue))
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMarkSyllabusApi()
                })
            }
            self.tblMarksSyllabus.reloadData()
            self.collectionExam.reloadData()
        }
    }
}

extension MarksSyllabusVC
{
    @IBAction func btnInsertUpdateData(_ sender:UIButton)
    {
        if arrTypes.count == 0 {
            Functions.showAlert(false, Message.noTypeSelect)
            return
        }
        else if arrExamSelectedIds.count == 0 {
            Functions.showAlert(false, Message.noTestSelect)
            return
        }
        self.callInsertUpdateMarkSyllabusApi(sender.title(for: .normal) == ButtonType.update.rawValue ?  self.arrPermissionData[sender.tag].AssignPermissionID : "0")
    }
}

extension MarksSyllabusVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width, height: 30);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrExams.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:SectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "SectionCell", for: indexPath) as! SectionCell
        
        cell.lblSection.text = arrExams[indexPath.row]
        cell.checkBox.setOn(self.arrExamSelectedIds.contains(arrExams[indexPath.row]))
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell:SectionCell = collectionView.cellForItem(at: indexPath) as! SectionCell
        cell.checkBox.setOn(!cell.checkBox.isOn(), animated: true)
        
        if(cell.checkBox.isOn()){
            self.arrExamSelectedIds.append(self.arrExams[indexPath.row])
        }else{
            let idx:NSInteger = self.arrExamSelectedIds.index(of: self.arrExams[indexPath.row])!
            self.arrExamSelectedIds.remove(at: idx)
        }
    }
}

extension MarksSyllabusVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:PermissionCell = tableView.dequeueReusableCell(withIdentifier: "MSPermissionHeaderCell") as! PermissionCell
        
        return arrPermissionData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrPermissionData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPermissionData.count > 0 ? arrPermissionData.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:PermissionCell = tableView.dequeueReusableCell(withIdentifier: "MSPermissionCell", for: indexPath) as! PermissionCell
        
        cell.btnEdit.tag = indexPath.row
        if(arrPermissionData.count > 0) {
            cell.displayMSPermissionData(arrPermissionData[indexPath.row])
        }
        return cell
    }
    
    @IBAction func btnEditAction(_ sender:UIButton)
    {
        if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[1] == "true") {
            btnAddUpdate.setTitle(ButtonType.update.rawValue, for: .normal)
            
            let permissionModalData:PermissionModel = arrPermissionData[sender.tag]
            
            // 1
            self.arrExamSelectedIds = [permissionModalData.strTestName]
            
            // 2,3
            for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
                let dropDown:UIDropDown = view as! UIDropDown
                
                var strValue:String!
                switch(dropDown.tag)
                {
                case 100:
                    strValue = permissionModalData.Term
                    strTermID = self.dicTerms.value(forKey: strValue) as! String
                    dropDown.selectedIndex = (self.arrTerms as! [String]).index(of: strValue)
                    
                case 200:
                    strValue = permissionModalData.Standard
                    strStdID = dicStandards.value(forKey: strValue) as! String
                    dropDown.selectedIndex = self.arrStandards.index(of: strValue)
                    self.callGetExamApi()
                    
                default:
                    break
                }
                dropDown.title.text = strValue
            }
            
            // 4
            self.arrTypes = [permissionModalData.strType == "Result" ? "R" : "S"]
            for checkBox in view.subviews.filter({($0.isKind(of: VKCheckbox.classForCoder()))}) {
                switch(checkBox.tag)
                {
                case 3:
                    (checkBox as! VKCheckbox).setOn(self.arrTypes.contains("R"), animated: true)
                default:
                    (checkBox as! VKCheckbox).setOn(self.arrTypes.contains("S"), animated: true)
                }
            }
            
            // 5
            self.resetRadioButton(permissionModalData.Status.getStatusMode())
        }
        else{
            Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "edit"))
        }
    }
    
    func resetRadioButton(_ mode:StatusMode)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        strStatusMode = mode == .active ? 1 : 0
        let radioButton:LTHRadioButton = view.viewWithTag(strStatusMode+1) as! LTHRadioButton
        radioButton.select(animated: true)
        
        self.collectionExam.reloadData()
    }
}
