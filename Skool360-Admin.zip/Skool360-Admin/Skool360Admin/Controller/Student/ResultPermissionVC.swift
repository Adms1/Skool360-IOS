//
//  ClassTeacherVC.swift
//  Skool360Admin
//
//  Created by ADMS on 23/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class ResultPermissionVC: CustomViewController {
    
    @IBOutlet var collectionGrade:UICollectionView!
    @IBOutlet var tblResultPermission:UITableView!
    @IBOutlet var btnAddUpdate:UIButton!
    @IBOutlet var collectionHeight:NSLayoutConstraint!
    
    var arrStdSelectedIds:[String] = []
    var arrResultDetails = [PermissionModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var i = 10
        for view in view.subviews {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                if(radioButton.tag == 2){
                    radioButton.select(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.isUserInteractionEnabled = true
                view.addGestureRecognizer(tapGesture)
                
                i += 10
            }
        }
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.callGetResultPermissionApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.addDropDown()
            let height:CGFloat = CGFloat((self.arrStandards.count/(DeviceType.isIpad ? 5 : 3)) + (self.arrStandards.count%(DeviceType.isIpad ? 5 : 3) != 0 ? 1 : 0)) * 30
            self.collectionHeight.constant = height
            
            self.resetData()
            self.callGetResultPermissionApi()
        }
    }
    
    func resetData()
    {
        self.strStdID = nil
        btnAddUpdate.setTitle(ButtonType.add.rawValue, for: .normal)
        self.arrStdSelectedIds = []
        self.resetRadioButton(.active)
    }
    
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 100
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 100:
                    self.addTermDropDown(view)
                    
                case 200:
                    self.addSelectTermDropDown()
                    
                default:
                    break
                }
                i += 100
            }
        }
    }
    
    func addSelectTermDropDown()
    {
        let arrTerms = ["Term 1", "Term 2"]
        let strValue:String = arrTerms[Int(strTermDetail)! - 1]
        
        let dropDown:UIDropDown = UIDropDown(frame: (self.view.viewWithTag(200)?.frame)!)
        dropDown.tag = 200
        dropDown.options = arrTerms
        dropDown.tableHeight = CGFloat(arrTerms.count * 35)
        dropDown.selectedIndex = Int(strTermDetail)! - 1
        dropDown.title.text = strValue
        
        dropDown.didSelect { (option, index) in
            dropDown.hideTable()
            strTermDetail = "\(index+1)"
        }
        self.view.addSubview(dropDown)
    }
    
    // MARK: Api Calling
    
    @objc func callGetResultPermissionApi()
    {
        self.arrResultDetails = []
        
        Functions.callApi(api: API.getResultPermissionAdminApi, params: ["TermID" : strTermID]) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for (index,value) in arrData!.enumerated() {
                    let resultPermissionModal:PermissionModel = PermissionModel.init(index: "\(index+1)", term: json!["Year"].stringValue, termDetail: value["TermDetail"].stringValue, standard: value["Standard"].stringValue, status: value["Status"].stringValue)
                    
                    self.arrResultDetails.append(resultPermissionModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetResultPermissionApi()
                })
            }
            self.tblResultPermission.reloadData()
        }
    }
    
    func callInsertUpdateResultPermissionApi()
    {
        let params = ["TermID" : strTermID,
                      "GradeID" : arrStdSelectedIds.joined(separator: ","),
                      "Status" : "\(strStatusMode)",
            "TermDetailsID" : strTermDetail]
        
        print(params)
        
        Functions.callApi(api: API.insertResultPermissionApi, params: params) { (json,error) in
            
            if(json != nil){
                let msg:String = self.btnAddUpdate.titleLabel?.text == ButtonType.add.rawValue ? Message.recordInsert : Message.recordUpdate
                Functions.showAlert(false, msg)
                self.resetData()
                self.callGetResultPermissionApi()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callInsertUpdateResultPermissionApi()
                })
            }
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! > 2 ? (gesture.view?.tag)!/10 : (gesture.view?.tag)!
        let radioButton:LTHRadioButton = view.viewWithTag(tag) as! LTHRadioButton
        radioButton.select(animated: true)
        strStatusMode = tag-1
    }
    
    @IBAction func btnInsertUpdateData(_ sender:UIButton)
    {
        if arrStdSelectedIds.count == 0 {
            Functions.showAlert(false, Message.noGradeSelect)
            return
        }
        self.callInsertUpdateResultPermissionApi()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ResultPermissionVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectionView.frame.size.width/(DeviceType.isIpad ? 5 : 3), height: 30);
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrStandards.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell:SectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "SectionCell", for: indexPath) as! SectionCell
        
        cell.lblSection.text = arrStandards[indexPath.row]
        
        if strStdID != nil && cell.lblSection.text == dicStandards.allKeys(for: strStdID).first as? String
        {
            self.arrStdSelectedIds.append(strStdID)
            cell.checkBox.setOn(true, animated: false)
        }
        else
        {
            cell.checkBox.setOn(false, animated: false)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell:SectionCell = collectionView.cellForItem(at: indexPath) as! SectionCell
        cell.checkBox.setOn(!cell.checkBox.isOn(), animated: true)
        
        strStdID = dicStandards.value(forKey: self.arrStandards[indexPath.row]) as! String
        
        if(cell.checkBox.isOn()){
            self.arrStdSelectedIds.append(strStdID)
        }else{
            let idx:NSInteger = self.arrStdSelectedIds.index(of: strStdID)!
            self.arrStdSelectedIds.remove(at: idx)
        }
    }
}

extension ResultPermissionVC:UITableViewDataSource,UITableViewDelegate,CustomCellDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:PermissionCell = tableView.dequeueReusableCell(withIdentifier: "ResultPermissionHeaderCell") as! PermissionCell
        
        return arrResultDetails.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return arrResultDetails.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrResultDetails.count > 0 ? arrResultDetails.count : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:PermissionCell = tableView.dequeueReusableCell(withIdentifier: "ResultPermissionCell", for: indexPath) as! PermissionCell
        
        cell.btnEdit.tag = indexPath.row
        cell.delegate = self
        
        cell.displayData(arrResultDetails[indexPath.row])
        return cell
    }
    
    func performAction(_ sender:UIButton)
    {
        btnAddUpdate.setTitle(ButtonType.update.rawValue, for: .normal)
        
        let permissionModalData:PermissionModel = arrResultDetails[sender.tag]
        
        // 1
        for view in view.subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            let dropDown:UIDropDown = view as! UIDropDown
            if(dropDown.tag == 100) {
                dropDown.title.text = permissionModalData.Term
                dropDown.selectedIndex = (self.arrTerms as! [String]).index(of: permissionModalData.Term)
            }else{
                dropDown.title.text = permissionModalData.TermDetail
                dropDown.selectedIndex = ["Term 1", "Term 2"].index(of: permissionModalData.TermDetail)
            }
        }
        
        // 2
        self.arrStdSelectedIds = []
        strStdID = dicStandards.value(forKey: permissionModalData.Standard) as! String
        
        // 3
        self.resetRadioButton(permissionModalData.Status.getStatusMode())
    }
    
    func resetRadioButton(_ mode:StatusMode)
    {
        for view in view.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}) {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        strStatusMode = mode == .active ? 1 : 0
        let radioButton:LTHRadioButton = view.viewWithTag(strStatusMode+1) as! LTHRadioButton
        radioButton.select(animated: true)
        
        self.collectionGrade.reloadData()
    }
}
