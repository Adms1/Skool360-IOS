//
//  AddEnquiryVC.swift
//  Skool360Admin
//
//  Created by ADMS on 25/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import SwiftyJSON
import UIDropDown

var dictValue:[String:String] = [:]
class AddEnquiryVC: CustomViewController {
    
    @IBOutlet var txtFName:UITextField!
    @IBOutlet var txtMName:UITextField!
    @IBOutlet var txtLName:UITextField!
    @IBOutlet var txtDate:UITextField!
    @IBOutlet var txtDOB:UITextField!
    @IBOutlet var txtPSA:UITextField!
    @IBOutlet var txtFFName:UITextField!
    @IBOutlet var txtFMName:UITextField!
    @IBOutlet var txtFLName:UITextField!
    @IBOutlet var txtFMobileNo:UITextField!
    
    var strGender:String = "Male"
    var txtFld:UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(openDatePicker(_:)), name: .openDatePicker, object: nil)
        
        self.resetData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (_) in
            self.callGetSectionsApi(completion: { (_) in
                self.addDropDown()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    func callSaveInquiry()
    {
        let params = ["UserID" : adminID!,
                      "StudentFName" : txtFName.text!,
                      "StudentMName" : txtMName.text!,
                      "StudentLName" : txtLName.text!,
                      "GradeID" : strStdID!,
                      "SectionID" : strClassID!,
                      "TermID" : strTermID,
                      "Date" : txtDate.text!,
                      "Gender" : strGender,
                      "StudentDOB" : txtDOB.text!,
                      "PreviousSchool" : txtPSA.text!,
                      "FatherFName" : txtFFName.text!,
                      "FatherMName" : txtFMName.text!,
                      "FatherLName" : txtFLName.text!,
                      "FatherContactMobile" : txtFMobileNo.text!]
        
        print(params)
        
        Functions.callApi(api: API.insertInquiryApi, params: params) { (json, error) in
            
            if(json != nil) {
                Functions.showAlert(true, Message.addEnquirySuccess)
                for controller in self.navigationController!.viewControllers as Array
                {
                    if controller.isKind(of: ViewEnquiryVC.self) {
                        self.navigationController?.pushPopTransition(controller, false)
                    }
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AddEnquiryVC
{
    // MARK: Function for Choose Options for Test
    
    func addDropDown()
    {
        var i = 10
        for view in (txtFName.superview?.subviews)! {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 30:
                    self.addTermDropDown(view)
                    
                case 10:
                    self.addStandardDropDown(view)
                    
                default:
                    self.addSectionDropDown(20)
                }
                i += 10
            }
        }
    }
    
    @objc func radioButtonSelectUnSelectAction(_ gesture:UITapGestureRecognizer)
    {
        for view in (gesture.view?.superview?.subviews.filter({($0.isKind(of: LTHRadioButton.classForCoder()))}))! {
            
            let radioButton:LTHRadioButton = view as! LTHRadioButton
            radioButton.deselect(animated: true)
        }
        
        let tag:NSInteger = (gesture.view?.tag)! < 1000 ? (gesture.view?.tag)!*10 : (gesture.view?.tag)!
        let radioButton:LTHRadioButton = gesture.view?.superview!.viewWithTag(tag) as! LTHRadioButton
        radioButton.select(animated: true)
        strGender = tag == 1000 ? "Male" : "Female"
    }
    
    @objc func openDatePicker(_ notification:NSNotification)
    {
        txtFld = notification.userInfo!["txtfld"] as! UITextField
        let selector = UIStoryboard(name: "WWCalendarTimeSelector", bundle: nil).instantiateInitialViewController() as! WWCalendarTimeSelector
        selector.delegate = self
        selector.optionCurrentDate = (txtFld.text!.toDate(dateFormat: "dd/MM/yyyy"))
        selector.optionCurrentDateRange.setStartDate(txtFld.text!.toDate(dateFormat: "dd/MM/yyyy"))
        selector.optionCurrentDateRange.setEndDate(txtFld.text!.toDate(dateFormat: "dd/MM/yyyy"))
        
        selector.optionStyles.showDateMonth(true)
        selector.optionStyles.showMonth(false)
        selector.optionStyles.showYear(true)
        selector.optionStyles.showTime(false)
        
        present(selector, animated: true, completion: nil)
    }
}

extension AddEnquiryVC
{
    @IBAction func btnSaveAction(_ sender:UIButton)
    {
        if (txtFName.text?.isEmpty)! {
            Functions.showAlert(false, Message.firstName)
            return
        }else if (txtLName.text?.isEmpty)! {
            Functions.showAlert(false, Message.lastName)
            return
        }else if (txtPSA.text?.isEmpty)! {
            Functions.showAlert(false, Message.psa)
            return
        }else if (txtFFName.text?.isEmpty)! {
            Functions.showAlert(false, Message.fFirstName)
            return
        }else if (txtFLName.text?.isEmpty)! {
            Functions.showAlert(false, Message.fLastName)
            return
        }else if (txtFMobileNo.text?.isEmpty)! {
            Functions.showAlert(false, Message.fMobileNo)
            return
        }else if ((txtFMobileNo.text?.count)! < 10) {
            Functions.showAlert(false, Message.incorrectNoError)
            return
        }
        self.callSaveInquiry()
    }
    
    @IBAction func btnCancelAction(_ sender:UIButton)
    {
        self.resetData()
        self.clearData()
    }
    
    func resetData()
    {
        self.view.subviews[1].subviews[0].addShadowWithRadius(3.0, 0, 0.5)
        self.view.subviews[1].subviews[2].addShadowWithRadius(3.0, 0, 0.5)
        
        self.view.subviews[1].subviews[1].backgroundColor = GetColor.darkBlue
        self.view.subviews[1].subviews[3].backgroundColor = GetColor.green
        
        txtFName.text = nil
        txtMName.text = nil
        txtLName.text = nil
        txtDate.text = Date().toString(dateFormat: "dd/MM/yyyy")
        txtDOB.text = txtDate.text
        txtPSA.text = nil
        txtFFName.text = nil
        txtFMName.text = nil
        txtFLName.text = nil
        txtFMobileNo.text = nil
        
        var i = 100
        for view in (txtFName.superview?.subviews)! {
            if(view.isKind(of: LTHRadioButton.classForCoder())) {
                
                let radioButton:LTHRadioButton = view as! LTHRadioButton
                radioButton.selectedColor = GetColor.blue
                radioButton.deselectedColor = .lightGray
                
                if(radioButton.tag == 1000){
                    self.strGender = "Male"
                    radioButton.select(animated: true)
                }else{
                    radioButton.deselect(animated: true)
                }
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                radioButton.addGestureRecognizer(tapGesture)
                
            } else if (view.tag == i){
                
                let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(radioButtonSelectUnSelectAction(_:)))
                view.addGestureRecognizer(tapGesture)
                
                i += 100
            }
        }
    }
    
    func clearData()
    {
        for view in self.view.subviews[1].subviews[0].subviews.filter({($0.isKind(of: UIDropDown.classForCoder()))}) {
            let dropDown:UIDropDown = view as! UIDropDown
            if(dropDown.table != nil){
                dropDown.hideTable()
            }
            dropDown.removeFromSuperview()
        }
        self.addDropDown()
    }
}

extension AddEnquiryVC
{
    // MARK: Calender Delegate
    
    func WWCalendarTimeSelectorShouldSelectDate(_ selector: WWCalendarTimeSelector, date: Date) -> Bool {
        return date < Date()
    }
    
    override func WWCalendarTimeSelectorDone(_ selector: WWCalendarTimeSelector, date: Date) {
        self.txtFld.text = date.toString(dateFormat: "dd/MM/yyyy")
    }
}
