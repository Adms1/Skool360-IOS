//
//  StudentDetailVC.swift
//  Skool360Admin
//
//  Created by ADMS on 25/10/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import SwiftyJSON

class GRRegister_Left_StudentDetailsVC: CustomViewController {
    
    @IBOutlet var tblStudentDetails:UITableView!
    
    var arrStudentHeaderTitle = ["Student Details","Transport Details","Father Details","Mother Details","Communication Details"]
    var arrStudentHeaderColor:[UIColor] = [GetColor.darkBlue,GetColor.green,GetColor.yellow,GetColor.lightBlue,GetColor.greenGray]
    var dicStudentData:Dictionary<String, JSON> = [:]
    var dicStudentDetails:NSMutableDictionary = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblStudentDetails.estimatedRowHeight = 30.0
        getStudentDetailsApi()
    }
    
    func getStudentDetailsApi()
    {
        for (index, value) in self.arrStudentHeaderTitle.enumerated() {
            
            var arrStudentDetailTitle:[String] = []
            
            switch(index) {
            case 0:
                arrStudentDetailTitle = [StudentDetailsModal.Tag, StudentDetailsModal.FirstName, StudentDetailsModal.MiddleName, StudentDetailsModal.LastName, StudentDetailsModal.DOB, StudentDetailsModal.BirthPlace, StudentDetailsModal.Age, StudentDetailsModal.Gender, StudentDetailsModal.Board, StudentDetailsModal.AadharNo, StudentDetailsModal.AcedamicYear,  StudentDetailsModal.Standard, StudentDetailsModal.Class, StudentDetailsModal.LastSchool, StudentDetailsModal.DOA,  StudentDetailsModal.AdmissionTaken, StudentDetailsModal.BloodGrp, StudentDetailsModal.House, StudentDetailsModal.StuUniqueNo, StudentDetailsModal.Religion, StudentDetailsModal.Nationality, StudentDetailsModal.Location, StudentDetailsModal.Status, StudentDetailsModal.GRNO, StudentDetailsModal.OldGRNO
                ]
                
                self.fillData(nil, arrStudentDetailTitle, value)
                
            case 1:
                arrStudentDetailTitle = [StudentDetailsModal.TransportKMs, StudentDetailsModal.Route,StudentDetailsModal.PickupBus, StudentDetailsModal.PickupPoint, StudentDetailsModal.PickupPointTime, StudentDetailsModal.DropBus, StudentDetailsModal.DropPoint, StudentDetailsModal.DropPointTime]
                
                self.fillData(nil, arrStudentDetailTitle, value)
                
            case 2:
                arrStudentDetailTitle = [StudentDetailsModal.FMFName, StudentDetailsModal.FMLName, StudentDetailsModal.FMPhone, StudentDetailsModal.FMMobile, StudentDetailsModal.FMEmail, StudentDetailsModal.FMQualification, StudentDetailsModal.FMOcupation, StudentDetailsModal.FMOrganization, StudentDetailsModal.FMDesignation, StudentDetailsModal.FMOA]
                
                self.fillData("Father", arrStudentDetailTitle, value)
                
            case 3:
                arrStudentDetailTitle = [StudentDetailsModal.FMFName, StudentDetailsModal.FMLName, StudentDetailsModal.FMPhone, StudentDetailsModal.FMMobile, StudentDetailsModal.FMEmail, StudentDetailsModal.FMQualification, StudentDetailsModal.FMOcupation, StudentDetailsModal.FMOrganization, StudentDetailsModal.FMDesignation, StudentDetailsModal.FMOA]
                
                self.fillData("Mother", arrStudentDetailTitle, value)
                
            default:
                arrStudentDetailTitle = [StudentDetailsModal.SMSNo, StudentDetailsModal.City, StudentDetailsModal.ZipCode, StudentDetailsModal.CommEmailID, StudentDetailsModal.Address]
                
                self.fillData(nil, arrStudentDetailTitle, value)
            }
        }
        self.tblStudentDetails.reloadData()
    }
    
    func fillData(_ str:String?, _ arrayTitle:[String], _ key:String)
    {
        var arrStudentDetailValue:[String] = []
        
        for value in arrayTitle {
            let itemKey:String = str == nil ? value : "\(str!) \(value)"
            
            if(itemKey == "Term"){
                arrStudentDetailValue.append(strTerm)
            }else if(itemKey == "Status"){
                arrStudentDetailValue.append((dicStudentData[itemKey]?.stringValue)! == "1" ? "Active" : "InActive")
            }else {
                if let item = dicStudentData[itemKey]?.string {
                    arrStudentDetailValue.append(item)
                }else{
                    arrStudentDetailValue.append("-")
                }
            }
        }
        self.dicStudentDetails.setValue([arrayTitle,arrStudentDetailValue], forKey: key)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension GRRegister_Left_StudentDetailsVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:StudentProfileCell = tableView.dequeueReusableCell(withIdentifier: "StudentProfileHeaderCell") as! StudentProfileCell
        
        headerView.displayHeaderData(arrStudentHeaderTitle[section], arrStudentHeaderColor[section], selectedIndex == section ? true : false)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        return  headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return DeviceType.isIpad ? 60 : 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dicStudentDetails.count > 0 ? arrStudentHeaderTitle.count : 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == selectedIndex {
            return UITableViewAutomaticDimension
        }else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ((dicStudentDetails[arrStudentHeaderTitle[section]] as! NSArray).firstObject as! NSArray).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:StudentProfileCell = tableView.dequeueReusableCell(withIdentifier: "StudentProfileCell", for: indexPath) as! StudentProfileCell
        
        let array:NSArray = (dicStudentDetails[arrStudentHeaderTitle[indexPath.section]] as! NSArray)
        let arrTitle:[String] = array.firstObject as! [String]
        let arrValue:[String] = array.lastObject as! [String]
        
        cell.bottomSpace.constant = indexPath.row ==  arrTitle.count - 1 ? 1.0 : -1.0
        
        cell.displayRegisterLeftStudentData([arrTitle[indexPath.row], arrValue[indexPath.row]], selectedIndex == indexPath.section ? true : false)
        
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblStudentDetails.reloadSections(IndexSet(integersIn: 0...arrStudentHeaderTitle.count-1), with: .automatic)
        self.tblStudentDetails.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
    }
}
