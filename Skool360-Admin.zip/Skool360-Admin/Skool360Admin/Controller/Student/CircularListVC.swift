//
//  CircularListVC.swift
//  Bhadaj (Admin)
//
//  Created by ADMS on 17/10/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class CircularListVC: CustomViewController {
    
    @IBOutlet weak var tblCircularList:UITableView!
    
    var arrCircularData = [AnnoucementModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblCircularList.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetCircularData()
    }
    
    private lazy var viewMarksVC: ViewMarksPopupVC = {
        
        var viewController:ViewMarksPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "ViewMarksPopupVC") as! ViewMarksPopupVC
        add(asChildViewController: viewController, self)
        return viewController
    }()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension CircularListVC
{
    func callGetCircularData()
    {
        arrCircularData = []
        
        Functions.callApi(api: API.getCircularDataApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arrCircular = json!["FinalArray"].array
                
                for (_,value) in arrCircular!.enumerated() {
                    self.arrCircularData.append(AnnoucementModel.init(subject: value["Subject"].stringValue, description: value["Discription"].stringValue, pdf: value["CircularPDF"].stringValue, createDate: value["Date"].stringValue, status: value["Status"].stringValue, announcementId: value["PK_CircularID"].stringValue, std: value["Standard"].stringValue, stdId: value["StandardID"].stringValue, sDate:value["ScheduleDate"].stringValue, sTime:value["ScheduleTime"].stringValue))
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetCircularData()
                })
            }
            self.tblCircularList.reloadData()
        }
    }
    
    func callDeleteCircularApi(_ index:NSInteger)
    {
        let params = ["CircularID":arrCircularData[index].strAnnoucementID!]
        
        Functions.callApi(api: API.deleteCircularApi, params: params) { (json,error) in
            if(json != nil){
                Functions.showAlert(true, Message.circularDeleteSuccess)
                self.arrCircularData.remove(at: index)
                self.tblCircularList.reloadData()
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callDeleteCircularApi(index)
                })
            }
        }
    }
}

extension CircularListVC
{
    @IBAction func btnAddAction(_ sender:UIButton)
    {
        selectedCircularModel = nil
        self.goToCircular()
    }
    
    func goToCircular()
    {
        let vc = Constants.storyBoard.instantiateViewController(withIdentifier: "AddCircular")
        vc.title = self.title!
        self.navigationController?.pushPopTransition(vc,true)
    }
}

extension CircularListVC: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:AnnoucementCell = tableView.dequeueReusableCell(withIdentifier: "CircularHeaderCell") as! AnnoucementCell
        
        headerView.contentView.subviews[0].subviews[1].addShadowWithRadius(2, 0, 0)
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.contentView.tag = section
        headerView.contentView.addGestureRecognizer(tapGesture)
        
        headerView.btnExpand.transform = .identity
        if section == selectedIndex {
            UIView.animate(withDuration: 0.5, animations: {
                headerView.btnExpand.transform = CGAffineTransform(rotationAngle:(CGFloat.pi / 2))
            })
        };
        headerView.displayAnnouncementHeaderDetails(arrCircularData[section])
        return arrCircularData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        tableView.estimatedSectionHeaderHeight = (DeviceType.isIpad ? 60 : 50)
        return arrCircularData.count > 0 ? (section == 0 ? (DeviceType.isIpad ? 100 : 90) : (DeviceType.isIpad ? 60 : 50)) : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrCircularData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == selectedIndex){
            return UITableViewAutomaticDimension
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tblCircularList.rowHeight == 0 ? 0 : 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:AnnoucementCell = tableView.dequeueReusableCell(withIdentifier: arrCircularData[indexPath.section].strPDF == "" ? "CircularCell1" : "CircularCell2", for: indexPath) as! AnnoucementCell
        
        cell.btnEdit.tag = indexPath.section
        cell.btnDelete.tag = indexPath.section
        if(arrCircularData[indexPath.section].strPDF != "") {
            cell.btnViewPdf.tag = indexPath.section
        }
        cell.displayAnnouncementData(arrCircularData[indexPath.section])
        cell.editDeleteViewBlock = { sender in
            if(sender == cell.btnDelete) {
                if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[2] == "true") {
                    Functions.showCustomAlert("Delete", Message.deleteLeave) { (_) in
                        self.callDeleteCircularApi(sender.tag)
                    }
                }
                else{
                    Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "delete"))
                }
            }else if(sender == cell.btnEdit){
                if(((dictPermission.value(forKey: self.accessibilityValue!) as! [String:String])[self.title!]!).components(separatedBy: "-")[1] == "true") {
                    selectedCircularModel = self.arrCircularData[indexPath.section]
                    self.goToCircular()
                }
                else{
                    Functions.showAlert(false, Message.noEditDeletePermission.replacingOccurrences(of: "-", with: "edit"))
                }
            }else{
                webUrl = URL.init(string: API.hostName + self.arrCircularData[indexPath.section].strPDF)
                add(asChildViewController: self.viewMarksVC, self)
            }
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        tblCircularList.reloadSections(IndexSet(integersIn: 0...arrCircularData.count - 1), with: .automatic)
        
        if(selectedIndex != -1){
            self.tblCircularList.scrollToRow(at: NSIndexPath.init(row: 0, section: selectedIndex) as IndexPath, at: .none, animated: false)
        }
    }
}
