//
//  SingleSMSVC.swift
//  Skool360Admin
//
//  Created by ADMS on 29/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit

class SingleSMSVC: CustomViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let txtfld:UITextField = self.view.subviews[1] as! UITextField
        txtfld.inputAccessoryView = addToolbar()
        
        let txtView:UITextView = self.view.subviews[2] as! UITextView
        txtView.inputAccessoryView = addToolbar()
        
        self.initialize()
    }
    
    func initialize()
    {
        (self.view.subviews[1] as! UITextField).text = nil
        (self.view.subviews[2] as! UITextView).text = "Message"
        (self.view.subviews[2] as! UITextView).textColor = UIColor.gray.withAlphaComponent(0.3)
        self.view.endEditing(true)
    }
    
    func callSendMessageApi(_ requestData:RequestData)
    {
        let params = ["SMS" : requestData.TxtMsg!,
                      "MobileNo" : requestData.TxtMobileNo!]
        
        print(params)
        
        Functions.callApi(api: API.insertSingleSMSDataApi, params: params) { (json,error) in
            
            if(json != nil){
                
                self.initialize()
                Functions.showAlert(true, Message.msgSentSuccess)
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callSendMessageApi(requestData)
                })
            }
        }
    }
    
    @IBAction func btnSendClearAction(_ sender:UIButton)
    {
        if sender.tag == 10 {
            self.initialize()
        }else{
            let requestValues = RequestData.init(txtMobile: (self.view.subviews[1] as! UITextField).text!, txtMsg: (self.view.subviews[2] as! UITextView).text)
            
            if(ValidationFunctions.sendValidation(requestData: requestValues))
            {
                self.view.endEditing(true)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.callSendMessageApi(requestValues)
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SingleSMSVC:UITextFieldDelegate
{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.becomeFirstResponder()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if(range.location > 9){
            return false
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.dismissPicker()
        return true
    }
}

extension SingleSMSVC:UITextViewDelegate
{
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        
        if(textView.text == "Message"){
            textView.text = nil
            textView.textColor = .black
        }
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if(textView.text.count == 0 && textView.text == "\n"){
            textView.text = "Message"
            textView.textColor = UIColor.gray.withAlphaComponent(0.3)
            textView.resignFirstResponder()
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text.count == 0){
            textView.text = "Message"
            textView.textColor = UIColor.gray.withAlphaComponent(0.3)
        }
    }
}
