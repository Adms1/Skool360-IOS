//
//  SMS.swift
//  Skool360Admin
//
//  Created by ADMS on 28/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown

class SMSVC: CustomViewController {
    
    @IBOutlet var tblSMS:UITableView!
    @IBOutlet var btnSubmit:UIButton!
    
    var arrAbsentStudentData = [SMSModel]()
    var selectedCheckBoxFlag = 0
    var activateField:UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self,selector: #selector(self.callGetAbsentTodayApi),name: .callApi,object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetTermApi(true) { (success) in
            self.callGetSectionsApi(completion: { (success) in
                self.arrStandards.insert("All", at: 0)
                self.addDropDown()
                (self.view.subviews[4] as! UILabel).text = self.title == "Bulk SMS" ? "Term" : "Date"
                self.callGetAbsentTodayApi()
            })
        }
    }
    
    // MARK: Api Calling
    
    func callGetSectionsApi(completion:@escaping (Bool) -> Void)
    {
        dicStdSections = [:]
        
        Functions.callApi(api: API.getStandardSectionApi, params: [:]) { (json,error) in
            
            if(json != nil){
                
                let arraySections = json!["FinalArray"].array
                
                for value in arraySections! {
                    let dicSections:NSMutableDictionary = [:]
                    for item in value["SectionDetail"].array! {
                        dicSections.setValue(item["SectionID"].stringValue, forKey: item["Section"].stringValue)
                    }
                    self.dicStdSections.setValue(dicSections, forKey: value["Standard"].stringValue)
                }
                completion(true)
            }
        }
    }
    
    @objc func callGetAbsentTodayApi()
    {
        var params = ["grade" : self.strStdID!,
                      "section" : self.strClassID!]
        
        var strWebApi:String!
        if self.title != "Bulk SMS" {
            strWebApi = API.getAbsentTodayApi
            params.updateValue((btnDate.titleLabel?.text)!, forKey: "dt")
        }else {
            strWebApi = API.getBulkSMSDataApi
            params.updateValue(strTermID, forKey: "Term")
        }
        
        print(params)
        
        arrAbsentStudentData = []
        
        Functions.callApi(api: strWebApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayGetData = json!["FinalArray"].array
                
                for (i,value) in arrayGetData!.enumerated() {
                    
                    let smsModal:SMSModel = SMSModel.init(index: "\(i+1)", stuName: value["StudentName"].stringValue, familyName: value["FamilyName"].stringValue, std: value["Standard"].stringValue, smsNo: value["Sms_No"].stringValue, stuId: value["Fk_StudentID"].stringValue, stdId: value["Fk_StandardID"].stringValue, clsId: value["Fk_ClassID"].stringValue)
                    
                    self.arrAbsentStudentData.append(smsModal)
                }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetAbsentTodayApi()
                })
            }
            self.btnSubmit.isHidden = self.arrAbsentStudentData.count > 0 ? false : true
            self.checkBtnStatus()
            self.tblSMS.reloadData()
        }
    }
    
    // MARK: Function for Choose Options
    
    func addDropDown()
    {
        var i = 1
        for view in self.view.subviews {
            if(view.isKind(of: UILabel.classForCoder()) && view.tag == i){
                
                switch(i)
                {
                case 2:
                    self.addStandardDropDown(view)
                    
                default:
                    self.addSectionDropDown(3)
                }
                i += 1
                
            }else if(view.tag == i) {
                if(self.title != "Bulk SMS")
                {
                    (view as! UIButton).isHidden = false
                    (view as! UIButton).titleLabel?.font = FontType.regularFont
                    (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
                    btnDate = (view as! UIButton)
                }
                else
                {
                    (view as! UIButton).isHidden = true
                    self.addTermDropDown(view)
                }
                i += 1
            }
        }
    }
    
    @IBAction func btnSearchSubmitAction(_ sender:UIButton)
    {
        if sender.tag == 10 {
            self.callGetAbsentTodayApi()
        }else{
            add(asChildViewController: smsPopupVC)
        }
    }
    
    private lazy var smsPopupVC: SMSPopupVC = {
        
        var viewController:SMSPopupVC = Constants.storyBoard.instantiateViewController(withIdentifier: "SMSPopupVC") as! SMSPopupVC
        viewController.title = self.title!
        self.add(asChildViewController: viewController)
        return viewController
    }()
    
    private func add(asChildViewController viewController: UIViewController) {
        
        addChildViewController(viewController)
        view.addSubview(viewController.view)
        viewController.view.frame = view.bounds
        viewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        viewController.didMove(toParentViewController: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SMSVC:UITextFieldDelegate
{
    // MARK: -  Textfield Delegates
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        UIView.animate(withDuration: 0.5) {
            //            let diffY:CGFloat = 315 - ((textField.superview?.superview?.superview?.frame.origin.y)!-10)
            //            if(diffY > 240){
            //                self.tblSMS.frame.origin.y = 315
            //                self.tblSMS.frame = self.tblSMS.frame.offsetBy(dx: 0, dy: -((textField.superview?.superview?.superview?.frame.origin.y)!-10))
            //            }else{
            self.tblSMS.frame.origin.y = 230
            self.tblSMS.setContentOffset(CGPoint(x: 0, y:((textField.superview?.superview?.superview?.frame.origin.y)!-40)), animated: true)
            //            }
        }
        activateField = textField
        //textField.becomeFirstResponder()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if(range.location > 9){
            return false
        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if((textField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }else {
            textField.resignFirstResponder()
            self.view.endEditing(true)
            UIView.animate(withDuration: 0.5) {
                self.tblSMS.frame.origin.y = 315
                self.tblSMS.contentOffset = .zero
            }
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        let smsModal:SMSModel = self.arrAbsentStudentData[textField.tag]
        
        if(arrSelectedIds.contains("\(smsModal.StudentID!)|\(smsModal.SMSNo!)")) {
            let index:NSInteger = arrSelectedIds.index(of: "\(smsModal.StudentID!)|\(smsModal.SMSNo!)")!
            arrSelectedIds[index] = "\(smsModal.StudentID!)|\(textField.text!)"
        }
        smsModal.SMSNo = textField.text
        
        self.arrAbsentStudentData[textField.tag] = smsModal
        self.tblSMS.reloadRows(at: [IndexPath.init(row:textField.tag, section: 0)], with: .automatic)
    }
    
    override func dismissPicker() {
        
        activateField.resignFirstResponder()
        self.view.endEditing(true)
        UIView.animate(withDuration: 0.5) {
            self.tblSMS.frame.origin.y = 315
            self.tblSMS.contentOffset = .zero
        }
        
        if((activateField.text?.length)! < 10){
            Functions.showAlert(false, Message.incorrectNoError)
        }
    }
}

extension SMSVC:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSHeaderCell") as! SMSCell
        
        for view in headerView.contentView.subviews[0].subviews {
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    checkBox.setOn(false, animated: true)
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    
                    if(isOn){
                        self.selectedCheckBoxFlag = checkBox.tag
                        
                        for value in self.arrAbsentStudentData {
                            arrSelectedIds.append("\(value.StudentID!)|\(value.SMSNo!)")
                        }
                    }else{
                        self.selectedCheckBoxFlag = 0
                        arrSelectedIds = []
                    }
                    self.checkBtnStatus()
                    checkBox.setOn(isOn, animated: true)
                    tableView.reloadData()
                }
            }else if(view.isKind(of: UILabel.classForCoder())){
                (view as! UILabel).font = FontHelper.medium(size: DeviceType.isIpad ? 15 : 10)
            }
        }
        return self.arrAbsentStudentData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return self.arrAbsentStudentData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrAbsentStudentData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSCell", for: indexPath) as! SMSCell
        
        let smsModal:SMSModel = self.arrAbsentStudentData[indexPath.row]
        cell.displayData(smsModal)
        
        for view in cell.contentView.subviews[0].subviews {
            
            if(view.isKind(of: VKCheckbox.classForCoder())) {
                
                let checkBox:VKCheckbox = view as! VKCheckbox
                checkBox.isUserInteractionEnabled = true
                checkBox.tag = 1
                
                if(selectedCheckBoxFlag == checkBox.tag){
                    checkBox.setOn(true, animated: true)
                }else{
                    if(arrSelectedIds.contains("\(smsModal.StudentID!)|\(smsModal.SMSNo!)")) {
                        checkBox.setOn(true, animated: true)
                    }else {
                        checkBox.setOn(false, animated: true)
                    }
                }
                
                checkBox.checkboxValueChangedBlock = {
                    isOn in
                    checkBox.setOn(isOn, animated: true)
                    if(self.selectedCheckBoxFlag == checkBox.tag) {
                        self.selectedCheckBoxFlag = 0
                        self.tblSMS.reloadSections(IndexSet(integersIn: 0...0), with: .automatic)
                    }
                    
                    if(checkBox.isOn()) {
                        arrSelectedIds.append("\(smsModal.StudentID!)|\(smsModal.SMSNo!)")
                    }
                    else {
                        arrSelectedIds.remove(at: arrSelectedIds.index(of: "\(smsModal.StudentID!)|\(smsModal.SMSNo!)")!)
                    }
                    
                    self.tblSMS.reloadRows(at: [IndexPath.init(row: indexPath.row, section: 0)], with: .automatic)
                    self.checkBtnStatus()
                }
            }else if(view.isKind(of: UITextField.classForCoder())){
                (view as! UITextField).font = FontHelper.regular(size: DeviceType.isIpad ? 15 : 10)
                (view as! UITextField).inputAccessoryView = addToolbar()
                view.tag = indexPath.row
            }else{
                (view as! UILabel).font = FontHelper.regular(size: DeviceType.isIpad ? 15 : 10)
            }
        }
        return cell
    }
    
    func checkBtnStatus()
    {
        btnSubmit.isEnabled = arrSelectedIds.count > 0 ? true : false
        btnSubmit.alpha = btnSubmit.isEnabled ? 1.0 : 0.5
    }
}
