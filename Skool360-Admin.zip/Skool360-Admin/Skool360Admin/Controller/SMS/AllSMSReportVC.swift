//
//  AllSMSReportVC.swift
//  Skool360Admin
//
//  Created by ADMS on 22/11/17.
//  Copyright © 2017 ADMS. All rights reserved.
//

import UIKit
import UIDropDown
import SwiftyJSON

class AllSMSReportVC: CustomViewController {
    
    @IBOutlet var tblAllSMSReport:UITableView!
    
    var arrAllSMSReportData = [SMSModel]()
    var arrAllSMSReportTempData = [SMSModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblAllSMSReport.tableFooterView = UIView()
        
        for view in view.subviews {
            if(view.isKind(of: UIButton.classForCoder()) && view.tag != 0){
                (view as! UIButton).titleLabel?.font = FontType.regularFont
                (view as! UIButton).setTitle(Date().toString(dateFormat: "dd/MM/yyyy"), for: .normal)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetAllSMSReport()
    }
    
    func callGetAllSMSReport()
    {
        arrAllSMSReportData = []
        
        let params = ["StartDate" : ((self.view.subviews[1] as! UIButton).titleLabel?.text)!,
                      "EndDate" : ((self.view.subviews[2] as! UIButton).titleLabel?.text)!]
        
        print(params)
        
        Functions.callApi(api: API.getAllSMSDetailApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrayGetData = json!["FinalArray"].array
                
                self.displayData([json!["Total"].stringValue, json!["Delivered"].stringValue, json!["Other"].stringValue])
                
                for (i,value) in arrayGetData!.enumerated() {
                    
                    let allSMSReportModal:SMSModel = SMSModel.init(index: "\(i+1)", mobileNo: value["MobileNo"].stringValue, msg: value["Message"].stringValue, sendTime: value["Sendtime"].stringValue, receiveTime: value["Rectime"].stringValue, deliverStatus: value["Deliverstatus"].stringValue, status: value["Status"].stringValue)
                    
                    self.arrAllSMSReportData.append(allSMSReportModal)
                }
                self.arrAllSMSReportTempData = self.arrAllSMSReportData.map{ $0 }
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetAllSMSReport()
                })
            }
            self.tblAllSMSReport.reloadData()
        }
    }
    
    func displayData(_ arrData:[String])
    {
        var i = 0
        var color = [.darkGray, GetColor.green, GetColor.red]
        for view in view.subviews[3].subviews {
            if(view.isKind(of: UIButton.classForCoder())){
                let yourAttributes : [NSAttributedStringKey: Any] = [
                    NSAttributedStringKey.foregroundColor : color[i],
                    NSAttributedStringKey.underlineStyle : NSUnderlineStyle.styleSingle.rawValue]
                
                let attributeString = NSMutableAttributedString(string: arrData[i], attributes: yourAttributes)
                (view as! UIButton).setAttributedTitle(attributeString, for: .normal)
                i += 1
            }
        }
    }
    
    @IBAction func btnSearchAction(_ sender:UIButton)
    {
        self.callGetAllSMSReport()
    }
    
    @IBAction func btnFilterSMSReportAction(_ sender:UIButton)
    {
        switch sender.tag {
        case 1:
            self.arrAllSMSReportData = self.arrAllSMSReportTempData.filter{$0.Status.caseInsensitiveCompare("Delivered") == .orderedSame}.map{ $0 }
        case 2:
            self.arrAllSMSReportData = self.arrAllSMSReportTempData.filter{$0.Status.caseInsensitiveCompare("Pending") == .orderedSame}.map{ $0 }
        default:
            self.arrAllSMSReportData = self.arrAllSMSReportTempData.map{ $0 }
        }
        self.tblAllSMSReport.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension AllSMSReportVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSHeaderCell") as! SMSCell
        
        headerView.lblView.superview?.addShadowWithRadius(2.0, 0, 0)
        
        if section == selectedIndex {
            headerView.lblView.textColor = GetColor.green
        }else{
            headerView.lblView.textColor = .red
        }
        
        let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
        headerView.lblView.superview?.tag = section
        headerView.lblView.superview?.addGestureRecognizer(tapGesture)
        
        headerView.displayAllSMSReportHeaderData(arrAllSMSReportData[section])
        
        return arrAllSMSReportData.count > 0 ? headerView.contentView : nil
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrAllSMSReportData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? 100 : 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == selectedIndex ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:SMSCell = tableView.dequeueReusableCell(withIdentifier: "SMSCell", for: indexPath) as! SMSCell
        cell.displayAllSMSReportData(arrAllSMSReportData[indexPath.section])
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        self.tblAllSMSReport.reloadData()
        self.tblAllSMSReport.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
    }
}
