//
//  ViewController.swift
//  Skool360Teacher
//
//  Created by ADMS on 13/09/17.
//  Copyright © 2017 Waterworks Aquatics. All rights reserved.
//

import UIKit
import TransitionButton
import RaisePlaceholder

class ViewController: UIViewController {
    
    @IBOutlet var btnHideShowPwd:UIButton!
    @IBOutlet var loginUserNameField:RaisePlaceholder!
    @IBOutlet var loginPasswordField:RaisePlaceholder!
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loginUserNameField.superview?.addShadowWithRadius(3, 5, 0)
        print(bundleName)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.view.layoutIfNeeded()
        
        btnHideShowPwd.setImage(#imageLiteral(resourceName: "icon_showpass_h").withRenderingMode(.alwaysTemplate), for: .normal)
        loginUserNameField.clearButtonMode = .never
        loginPasswordField.clearButtonMode = .never
        
        if(deviceToken == nil) {
            Constants.appDelegate.registerForPushNotification(true)
        }
        
        let btn:AnimatedButton = AnimatedButton.init(frame: (loginUserNameField.superview?.subviews.last?.frame)!)
        btn.addTarget(self, action: #selector(login(_:)), for: .touchUpInside)
        loginUserNameField.superview?.addSubview(btn)
    }
    
    // MARK: - API Calling
    
    func loginTeacher(_ loginData:LoginData,sender:TransitionButton)
    {
        sender.startAnimation()
        
        let params = ["UserID":loginData.userName!,
                      "Password":loginData.password!]
        
        print(params)
        
        Functions.callApi(api: API.loginApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dic = json!["FinalArray"].array?.first
                
                UserDefaults.standard.set(dic?["StaffID"].stringValue, forKey: "AdminID")
                UserDefaults.standard.set(dic?["Emp_Name"].stringValue, forKey: "AdminName")
                UserDefaults.standard.set(dic?["DesignationName"].stringValue, forKey: "AdminDesignation")
                
                self.addDevice(sender: sender)
            }else {
                if(json == nil && error == nil) {
                    Functions.showAlert(false, Message.userError)
                }
                sender.stopAnimation(animationStyle: .normal, completion: {
                    if(error != nil) {
                        
                    }
                })
            }
        }
    }
    
    func addDevice(sender:TransitionButton)
    {
        let params = ["StaffID" : adminID!,
                      "DeviceID" : UIDevice.current.identifierForVendor!.uuidString,
                      "TokenID" : deviceToken ?? "",
                      "DeviceType" : "I"]
        
        print(params)
        
        Functions.callApi(api: API.addDeviceDetailAdminApi, params: params) { (json,error) in
            if(json != nil){
                sender.stopAnimation(animationStyle: .expand, completion: {
                    Constants.appDelegate.rootViewController()
                })
            }
        }
    }
    
    // MARK: - Button Click Actions
    
    @IBAction func login(_ sender: TransitionButton)
    {
        self.resignTextField()
        
        let loginValues = LoginData.init(userName: self.loginUserNameField.text!, password: self.loginPasswordField.text!)
        
        let result = ValidationFunctions.loginValidation(loginData: loginValues)
        
        if(result.0)
        {
            self.loginTeacher(loginValues, sender: sender)
        }
        else{
            switch result.1! {
            case .userName:
                loginUserNameField.shake()
            case .password:
                loginPasswordField.shake()
            default:
                break
            }
        }
    }
    
    @IBAction func btnHideShowPwd(_ sender: UIButton)
    {
        loginPasswordField.isSecureTextEntry = sender.isSelected
        sender.isSelected = !sender.isSelected
        sender.setImage((sender.isSelected ? #imageLiteral(resourceName: "icon_showpass") : #imageLiteral(resourceName: "icon_showpass_h")).withRenderingMode(.alwaysTemplate), for: .normal)
    }
    
    func resignTextField()
    {
        for txtfld in (self.view.subviews.flatMap{$0 as? UITextField}) {
            txtfld.resignFirstResponder()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
