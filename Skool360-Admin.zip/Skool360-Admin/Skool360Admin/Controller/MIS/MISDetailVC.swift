//
//  MISDetailVC.swift
//  Skool360Admin
//
//  Created by ADMS on 11/12/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class MISDetailVC: CustomViewController {
    
    @IBOutlet var tblMISDetails:UITableView!
    var arrStandardData = [StandardModel]()
    var arrStudentData = [StudentModal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMISDetails.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.callGetMISDetails()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MISDetailVC
{
    func callGetMISDetails()
    {
        self.arrStandardData = []
        self.arrStudentData = []
        
        let params = ["Date" : Date().toString(dateFormat: "dd/MM/yyyy"),
                      "TermID" : strTermID,
                      "RequestType" : self.accessibilityValue!]
        
        print(params)
        
        Functions.callApi(api: API.getMISStudentApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dictData = json!["FinalArray"].array?.first!
                
                let key = self.accessibilityValue == "A.N.T." ? "ANT" : "StudentData"
                if key != "ANT" {
                    for standardData in dictData!["StandardData"].array! {
                        self.arrStandardData.append(StandardModel.init(std: standardData["Standard"].stringValue, totalStudent: standardData["Total Student"].stringValue))
                    }
                }
                
                for studentData in dictData![key].array! {
                    if self.accessibilityValue == "A.N.T." {
                        self.arrStudentData.append(StudentModal.init(grade: studentData["Grade"].stringValue, section: studentData["Section"].stringValue, totalStudent: studentData["TotalStudent"].stringValue, classTeacher: studentData["ClassTeacher"].stringValue))
                    }else {
                        self.arrStudentData.append(StudentModal.init(grade: studentData["Grade"].stringValue, section: studentData["Section"].stringValue, stuName: studentData["StudentName"].stringValue, grno: studentData["GRNO"].stringValue, status: studentData["AttendanceStatus"].stringValue))
                    }
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMISDetails()
                })
            }
            self.tblMISDetails.reloadData()
        }
    }
}

extension MISDetailVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var strIdentifier:String!
        switch section {
        case 0:
            if self.accessibilityValue == "A.N.T." {
                strIdentifier = "MIS\(self.accessibilityValue!)HeaderCell"
            }else{
                strIdentifier = "MISHeaderCell"
            }
        default:
            strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.accessibilityValue!)HeaderCell" : "MISPALHeaderCell"
        }
        
        let headerView:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier) as! MISDetailCell
        if section == 0 && self.accessibilityValue != "A.N.T." {
            headerView.lblHeader.text = self.accessibilityLabel!
            headerView.lblHeader.font = FontHelper.bold(size: DeviceType.isIpad ? 20 : 18)
        }
        return arrStudentData.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch section {
        case 0:
            if self.accessibilityValue == "A.N.T." {
                return arrStudentData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
            }else{
                return arrStandardData.count > 0 ? 50 : 0
            }
        default:
            return arrStudentData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.accessibilityValue == "A.N.T." ? 1 : 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            if self.accessibilityValue == "A.N.T." {
                return arrStudentData.count
            }else{
                return arrStandardData.count
            }
        default:
            return arrStudentData.count
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            if self.accessibilityValue == "A.N.T." {
                return arrStudentData.count > 0 ? UITableViewAutomaticDimension : 0
            }else{
                return arrStandardData.count > 0 ? 40 + (indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1 ? 10 : 0) : 0
            }
        default:
            return arrStudentData.count > 0 ? UITableViewAutomaticDimension : 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        switch indexPath.section {
        case 0:
            if self.accessibilityValue == "A.N.T." {
                strIdentifier = "MIS\(self.accessibilityValue!)Cell"
            }else{
                strIdentifier = "MISCell"
            }
        default:
            strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.accessibilityValue!)Cell" : "MISPALCell"
        }
        
        let cell:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! MISDetailCell
        
        if indexPath.section == 0 && self.accessibilityValue != "A.N.T." {
            //tableView.separatorStyle = .none
            cell.contentView.subviews[0].subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
            cell.contentView.subviews[0].subviews[0].layer.borderWidth  = 0.5
            
            if(indexPath.row == tableView.numberOfRows(inSection: 0)-1) {
                cell.viewBottom.constant = 10.0
            }else {
                cell.viewBottom.constant = -1.0
            }
            cell.displayStandardData(arrStandardData[indexPath.row])
        }else{
            if self.accessibilityValue == "A.N.T." {
                cell.displayANTData(arrStudentData[indexPath.row])
            }else {
                cell.displayStudentData(arrStudentData[indexPath.row])
            }
        }
        return cell
    }
}
