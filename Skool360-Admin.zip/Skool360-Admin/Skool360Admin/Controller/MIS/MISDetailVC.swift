//
//  MISStudentStaffVC.swift
//  Skool360Admin
//
//  Created by ADMS on 11/12/18.
//  Copyright © 2018 ADMS. All rights reserved.
//

import UIKit

class MISStudentStaffVC: CustomViewController {
    
    @IBOutlet var tblMISDetails:UITableView!
    @IBOutlet var lblTitle:UILabel!
    @IBOutlet var lblValue:UILabel!
    
    var arrStandardData = [StandardModel]()
    var arrStudentData = [StudentModal]()
    var arrStaffData = [StaffModal]()
    var str:String!
    var strValue:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMISDetails.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        lblTitle.text = self.accessibilityLabel!
        lblValue.text = strValue
        self.callGetMISDetails()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MISStudentStaffVC
{
    func callGetMISDetails()
    {
        self.arrStandardData = []
        self.arrStudentData = []
        
        let params = ["Date" : Date().toString(dateFormat: "dd/MM/yyyy"),
                      "TermID" : strTermID,
                      "RequestType" : (self.accessibilityValue?.contains("A.N.T"))! || (self.accessibilityLabel?.contains("A.N.T"))! ? "A.N.T." : self.accessibilityValue!]
        
        print(params)
        
        var strApi:String!
        switch (self.title)! {
        case "Student":
            strApi = API.getMISStudentApi
        case "Staff":
            strApi = API.getMISStaffApi
        default:
            break
        }
        
        Functions.callApi(api: strApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let dictData = json!["FinalArray"].array?.first!
                
                let key = (self.accessibilityValue?.contains("A.N.T"))! || (self.accessibilityLabel?.contains("A.N.T"))! ? "ANT" : "\((self.title)!)Data"
                if key != "ANT" && self.title != "Staff" {
                    for standardData in dictData!["StandardData"].array! {
                        self.arrStandardData.append(StandardModel.init(std: standardData["Standard"].stringValue, totalStudent: standardData["Total Student"].stringValue))
                    }
                }
                
                for data in dictData![key].array! {
                    if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                        
                        switch (self.title)! {
                        case "Student":
                            self.arrStudentData.append(StudentModal.init(grade: data["Grade"].stringValue, section: data["Section"].stringValue, totalStudent: data["TotalStudent"].stringValue, classTeacher: data["ClassTeacher"].stringValue))
                            
                        case "Staff":
                            self.arrStaffData.append(StaffModal.init(name: data["ClassTeacher"].stringValue, code: data["TeacherCode"].stringValue, grade: data["Grade"].stringValue, section: data["Section"].stringValue))
                        default:
                            break
                        }
                    }else {
                        switch (self.title)! {
                        case "Student":
                            self.arrStudentData.append(StudentModal.init(grade: data["Grade"].stringValue, section: data["Section"].stringValue, stuName: data["StudentName"].stringValue, grno: data["GRNO"].stringValue, status: data["AttendanceStatus"].stringValue))
                            
                        case "Staff":
                            self.arrStaffData.append(StaffModal.init(name: data["StaffName"].stringValue, code: data["StaffCode"].stringValue, department: data["Department"].stringValue, status: data["AttendanceStatus"].stringValue))
                        default:
                            break
                        }
                    }
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMISDetails()
                })
            }
            self.tblMISDetails.reloadData()
        }
    }
}

extension MISStudentStaffVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var strIdentifier:String!
        switch section {
        case 0:
            switch((self.title)!)
            {
            case "Student":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    strIdentifier = "MIS\(self.title!)\(self.accessibilityValue!)HeaderCell"
                }else{
                    strIdentifier = "MISHeaderCell"
                }
            case "Staff":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    strIdentifier = "MIS\(self.title!)A.N.T.HeaderCell"
                }else{
                    strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.title!)\(self.accessibilityValue!)HeaderCell" : "MIS\(self.title!)PALHeaderCell"
                }
            default:
                break
            }
        default:
            strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.title!)\(self.accessibilityValue!)HeaderCell" : "MIS\(self.title!)PALHeaderCell"
        }
        
        let headerView:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier) as! MISDetailCell
        if section == 0 && !(self.accessibilityValue?.contains("A.N.T."))! && !(self.accessibilityLabel?.contains("A.N.T."))! && self.title == "Student" {
            headerView.lblHeader.text = self.accessibilityLabel!
            headerView.lblHeader.font = FontHelper.bold(size: DeviceType.isIpad ? 20 : 18)
        }
        
        switch (self.title)! {
        case "Student":
            return arrStudentData.count > 0 ? headerView.contentView : nil
        case "Staff":
            return arrStaffData.count > 0 ? headerView.contentView : nil
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch section {
        case 0:
            if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                switch (self.title)! {
                case "Student":
                    return arrStudentData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
                case "Staff":
                    return arrStaffData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
                default:
                    return 0
                }
            }else{
                switch (self.title)! {
                case "Student":
                    return arrStandardData.count > 0 ? 50 : 0
                case "Staff":
                    return arrStaffData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
                default:
                    return 0
                }
            }
        default:
            switch (self.title)! {
            case "Student":
                return arrStudentData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
            case "Staff":
                return arrStaffData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
            default:
                return 0
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        switch (self.title)! {
        case "Student":
            return (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! ? 1 : 2
        case "Staff":
            return 1
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                switch (self.title)! {
                case "Student":
                    return arrStudentData.count
                case "Staff":
                    return arrStaffData.count
                default:
                    return 0
                }
            }else{
                switch (self.title)! {
                case "Student":
                    return arrStandardData.count
                case "Staff":
                    return arrStaffData.count
                default:
                    return 0
                }
            }
        default:
            switch (self.title)! {
            case "Student":
                return arrStudentData.count
            case "Staff":
                return arrStaffData.count
            default:
                return 0
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                switch (self.title)! {
                case "Student":
                    return arrStudentData.count > 0 ? UITableViewAutomaticDimension : 0
                case "Staff":
                    return arrStaffData.count > 0 ? UITableViewAutomaticDimension : 0
                default:
                    return 0
                }
            }else{
                switch (self.title)! {
                case "Student":
                    return arrStandardData.count > 0 ? 40 + (indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1 ? 10 : 0) : 0
                case "Staff":
                    return arrStaffData.count > 0 ? UITableViewAutomaticDimension : 0
                default:
                    return 0
                }
            }
        default:
            switch (self.title)! {
            case "Student":
                return arrStudentData.count > 0 ? UITableViewAutomaticDimension : 0
            case "Staff":
                return arrStaffData.count > 0 ? UITableViewAutomaticDimension : 0
            default:
                return 0
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var strIdentifier:String!
        switch indexPath.section {
        case 0:
            switch (self.title)! {
            case "Student":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    strIdentifier = "MIS\(self.title!)\(self.accessibilityValue!)Cell"
                }else{
                    strIdentifier = "MISCell"
                }
            case "Staff":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    strIdentifier = "MIS\(self.title!)A.N.T.Cell"
                }else{
                    strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.title!)\(self.accessibilityValue!)Cell" : "MIS\(self.title!)PALCell"
                }
            default:
                break
            }
        default:
            strIdentifier = self.accessibilityValue == "Total" ? "MIS\(self.title!)\(self.accessibilityValue!)Cell" : "MIS\(self.title!)PALCell"
        }
        
        let cell:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: strIdentifier, for: indexPath) as! MISDetailCell
        
        if indexPath.section == 0 && !(self.accessibilityValue?.contains("A.N.T."))! && !(self.accessibilityLabel?.contains("A.N.T."))! && self.title == "Student" {
            cell.contentView.subviews[0].subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
            cell.contentView.subviews[0].subviews[0].layer.borderWidth  = 0.5
            
            if(indexPath.row == tableView.numberOfRows(inSection: 0)-1) {
                cell.viewBottom.constant = 10.0
            }else {
                cell.viewBottom.constant = -1.0
            }
            cell.displayStandardData(arrStandardData[indexPath.row])
        }else{
            switch (self.title)! {
            case "Student":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    cell.displayStudentANTData(arrStudentData[indexPath.row])
                }else {
                    cell.displayStudentData(arrStudentData[indexPath.row])
                }
            case "Staff":
                if (self.accessibilityValue?.contains("A.N.T."))! || (self.accessibilityLabel?.contains("A.N.T."))! {
                    cell.displayStaffANTData(arrStaffData[indexPath.row])
                }else {
                    cell.displayStaffData(arrStaffData[indexPath.row])
                }
            default:
                break
            }
        }
        return cell
    }
}

//-------------------------------------------------------------------//

class MISNASMSVC: CustomViewController {
    
    @IBOutlet var tblMISDetails:UITableView!
    @IBOutlet var lblTitle:UILabel!
    @IBOutlet var lblValue:UILabel!
    
    var arrAllSMSReportData = [SMSModel]()
    var arrNewAdmissionData = [NewAddmissionModal]()
    var strValue:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMISDetails.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        lblTitle.text = self.accessibilityLabel!
        lblValue.text = strValue
        self.callGetMISDetails()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MISNASMSVC
{
    func callGetMISDetails()
    {
        self.arrAllSMSReportData = []
        self.arrNewAdmissionData = []
        
        var params:[String:String] = [:]
        var strApi:String!
        
        switch (self.title)! {
        case "New Addmission":
            params = ["TermID" : strTermID,
                      "RequestType" : self.accessibilityValue!]
            strApi = API.getMISNewAddmissionApi
        case "Message":
            params = ["StartDate" : Date().toString(dateFormat: "dd/MM/yyyy"),
                      "EndDate" : Date().toString(dateFormat: "dd/MM/yyyy")]
            strApi = API.getAllSMSDetailApi
        default:
            break
        }
        
        print(params)
        
        Functions.callApi(api: strApi, params: params) { (json,error) in
            
            if(json != nil){
                
                let arrData = json!["FinalArray"].array
                
                for (i,value) in arrData!.enumerated() {
                    
                    switch (self.title)! {
                    case "New Addmission":
                        self.arrNewAdmissionData.append(NewAddmissionModal.init(date: value["InqDate"].stringValue, name: value["Name"].stringValue.capitalized, grade: value["Grade"].stringValue, gender: value["Gender"].stringValue, status: value["Current Status"].stringValue))
                    case "Message":
                        self.arrAllSMSReportData.append(SMSModel.init(index: "\(i+1)", mobileNo: value["MobileNo"].stringValue, msg: value["Message"].stringValue, sendTime: value["Sendtime"].stringValue, receiveTime: value["Rectime"].stringValue, deliverStatus: value["Deliverstatus"].stringValue, status: value["Status"].stringValue))
                        switch (self.accessibilityValue)! {
                        case "SMS Sent":
                            self.arrAllSMSReportData = self.arrAllSMSReportData.map{$0}
                        default:
                            self.arrAllSMSReportData = self.arrAllSMSReportData.filter{$0.Status.caseInsensitiveCompare((self.accessibilityValue)!) == .orderedSame}.map{ $0 }
                        }
                    default:
                        break
                    }
                }
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMISDetails()
                })
            }
            self.tblMISDetails.reloadData()
        }
    }
}

extension MISNASMSVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: "MIS\(self.title!)HeaderCell") as! MISDetailCell
        
        if self.title == "Message" {
            headerView.lblView.superview?.addShadowWithRadius(2.0, 0, 0)
            
            if section == selectedIndex {
                headerView.lblView.textColor = GetColor.green
            }else{
                headerView.lblView.textColor = .red
            }
            
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(expandCollapseSection(_:)))
            headerView.lblView.superview?.tag = section
            headerView.lblView.superview?.addGestureRecognizer(tapGesture)
            headerView.displayAllSMSReportHeaderData(arrAllSMSReportData[section])
        }
        
        switch (self.title)! {
        case "New Addmission":
            return arrNewAdmissionData.count > 0 ? headerView.contentView : nil
        case "Message":
            return arrAllSMSReportData.count > 0 ? headerView.contentView : nil
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch (self.title)! {
        case "New Addmission":
            return arrNewAdmissionData.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
        case "Message":
            return arrAllSMSReportData.count > 0 ? section == 0 ? 100 : 60: 0
        default:
            return 0
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        switch (self.title)! {
        case "New Addmission":
            return 1
        case "Message":
            return arrAllSMSReportData.count
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch (self.title)! {
        case "New Addmission":
            return arrNewAdmissionData.count
        case "Message":
            return arrAllSMSReportData.count > 0 ? 1 : 0
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch (self.title)! {
        case "New Addmission":
            return arrNewAdmissionData.count > 0 ? UITableViewAutomaticDimension : 0
        case "Message":
            return indexPath.section == selectedIndex ? UITableViewAutomaticDimension : 0
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: "MIS\(self.title!)Cell", for: indexPath) as! MISDetailCell
        
        switch (self.title)! {
        case "New Addmission":
            cell.displayNewAddmissionData(arrNewAdmissionData[indexPath.row])
        case "Message":
            cell.displayAllSMSReportData(arrAllSMSReportData[indexPath.section])
        default:
            break
        }
        return cell
    }
    
    @objc func expandCollapseSection(_ gesture:UIGestureRecognizer)
    {
        let Index:Int = (gesture.view?.tag)!
        if(selectedIndex == Index) {
            selectedIndex = -1
        }
        else {
            selectedIndex = Index
        }
        
        self.tblMISDetails.reloadData()
        self.tblMISDetails.scrollToRow(at: NSIndexPath.init(row: 0, section: Index) as IndexPath, at: .none, animated: true)
    }
}

//-------------------------------------------------------------------//

class MISDetailVC: CustomViewController {
    
    @IBOutlet var tblMISDetails:UITableView!
    
    var arrFeesData = [FeesModal]()
    var arrFeesValues:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMISDetails.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //self.callGetMISDetails()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension MISDetailVC
{
    func callGetMISDetails()
    {
        self.arrFeesData = []
        self.arrFeesValues = []
        
        let params = ["Date" : Date().toString(dateFormat: "dd/MM/yyyy"),
                      "TermID" : strTermID,
                      "RequestType" : (self.accessibilityValue?.contains("A.N.T"))! || (self.accessibilityLabel?.contains("A.N.T"))! ? "A.N.T." : self.accessibilityValue!]
        
        print(params)
        
        Functions.callApi(api: "", params: params) { (json,error) in
            
            if(json != nil){
                
                let dictData = json!["FinalArray"].array?.first!
                
            }else if(error != nil) {
                Functions.showDialog(finish: {
                    self.callGetMISDetails()
                })
            }
            self.tblMISDetails.reloadData()
        }
    }
}

extension MISDetailVC:UITableViewDataSource,UITableViewDelegate
{
    // MARK: - Table view data source
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: section == 0 ? "MISHeaderCell" : "MISDetailHeaderCell") as! MISDetailCell
        if section == 0 {
            headerView.lblHeader.font = FontHelper.bold(size: DeviceType.isIpad ? 20 : 18)
        }
        return section == 0 ? arrFeesValues.count > 0 ? headerView.contentView : nil : arrFeesValues.count > 0 ? headerView.contentView : nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? arrFeesValues.count > 0 ? 50 : 0 : arrFeesValues.count > 0 ? DeviceType.isIpad ? 45 : 40 : 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? arrFeesValues.count : arrFeesData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return indexPath.section == 0 && arrFeesValues.count > 0 ? 40 + (indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1 ? 10 : 0) : arrFeesData.count > 0 ? UITableViewAutomaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MISDetailCell = tableView.dequeueReusableCell(withIdentifier: indexPath.section == 0 ? "MISCell" : "MISDetailCell", for: indexPath) as! MISDetailCell
        
        if indexPath.section == 0 {
            cell.contentView.subviews[0].subviews[0].layer.borderColor  = GetColor.blue.withAlphaComponent(0.5).cgColor
            cell.contentView.subviews[0].subviews[0].layer.borderWidth  = 0.5
            
            if(indexPath.row == tableView.numberOfRows(inSection: 0)-1) {
                cell.viewBottom.constant = 10.0
            }else {
                cell.viewBottom.constant = -1.0
            }
            cell.displayFeesData([(dicData["MISAccount"] as! [String])[indexPath.row], arrFeesValues[indexPath.row]])
        }else{
            cell.displayAccountData(arrFeesData[indexPath.row])
        }
        return cell
    }
}

