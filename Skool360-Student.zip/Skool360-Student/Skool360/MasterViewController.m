//
//  MasterViewController.m
//  GTUPapers
//
//  Created by My Mac on 4/11/16.
//  Copyright (c) 2016 Darshan Jolapara. All rights reserved.
//

#import "MasterViewController.h"
#import "AppDelegate.h"
#import "HomeView.h"
#import "CommonClass.h"
#import "ErrorPopupVC.h"
//#import "UIViewController+MFSideMenuAdditions.h"
//#import "MFSideMenu.h"

@interface MasterViewController ()
{
    NSMutableArray *array;
}
@end

@implementation MasterViewController



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return YES;
}

-(void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Header"]];
    
    //[self setupMenuBarButtonItems];
    
    // Init custom right-side menu
    self.menuRight = [[VKSideMenu alloc] initWithSize:IS_IPAD ? 250 : 200 andDirection:VKSideMenuDirectionFromRight];
    self.menuRight.dataSource       = self;
    self.menuRight.delegate         = self;
    self.menuRight.textColor        = [UIColor whiteColor];
    self.menuRight.enableOverlay    = NO;
    self.menuRight.hideOnSelection  = NO;
    self.menuRight.selectionColor   = nil;//[UIColor colorWithWhite:.0 alpha:.3];
    self.menuRight.iconsColor       = nil;
    [self.menuRight addSwipeGestureRecognition:self.view];
    
    array = [[NSMutableArray alloc] initWithObjects:@"Home",@"My Profile",@"Announcement",@"Attendance",@"Home Work",@"Class Work",@"Time Table",@"Exam Syllabus",@"Results",@"Report Card",@"Fees",@"Planner",@"Leave Application",@"Circular",@"Gallery",@"Suggestion",@"Logout", nil];
    
    if ([BunbleName containsString:@"Shilaj"]) {
        [array removeObjectAtIndex:2];
    }
}

-(void)viewWillAppear:(BOOL)animated {
    if (![self isKindOfClass:[HomeView class]] && ![self isKindOfClass:[ErrorPopupVC class]]) {
        [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]firstObject]) setTitle:self.title.uppercaseString forState:0];
        [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:1]) addTarget:self action:@selector(onClickSideMenuBtn:) forControlEvents:UIControlEventTouchUpInside];
        [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:2]) addTarget:self action:@selector(onClickBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    }
}

#pragma mark -
#pragma mark - UIBarButtonItems

- (void)setupMenuBarButtonItems {
    
    [self rightMenuBarButtonItem];
}

-(void)rightMenuBarButtonItem{
    
    //    UIButton *btnMenu = [UIButton buttonWithType:UIButtonTypeCustom];
    //    btnMenu.frame = CGRectMake(0, 0, 40, 40);
    //    [btnMenu setImage:[UIImage imageNamed:@"Menu"] forState:UIControlStateNormal];
    //    [btnMenu addTarget:self action:@selector(clickToggle) forControlEvents:UIControlEventTouchUpInside];
    //    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:btnMenu];
    
}

-(void)backBarButtonItem
{
    UIButton *btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    btnBack.frame=CGRectMake(0, 0, 35, 35);
    [btnBack setImage:[UIImage imageNamed:@"back-arrow"] forState:UIControlStateNormal];
    [btnBack addTarget:self action:@selector(onClickBack) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:btnBack];
}

-(void)clickToggle
{
    [self.menuRight toggleMenu];
}

-(void)onClickBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark - UIBarButtonItem Callbacks

- (void)backButtonPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)leftSideMenuButtonPressed:(id)sender {
    
}

- (void)rightSideMenuButtonPressed:(id)sender {
    
}


#pragma mark - VKSideMenuDataSource

-(NSInteger)numberOfSectionsInSideMenu:(VKSideMenu *)sideMenu
{
    return 1;
}

-(NSInteger)sideMenu:(VKSideMenu *)sideMenu numberOfRowsInSection:(NSInteger)section
{
    return array.count;
}

-(VKSideMenuItem *)sideMenu:(VKSideMenu *)sideMenu itemForRowAtIndexPath:(NSIndexPath *)indexPath
{
    VKSideMenuItem *item = [VKSideMenuItem new];
    item.title = array[indexPath.row];
    return item;
}

#pragma mark - VKSideMenuDelegate

-(void)sideMenu:(VKSideMenu *)sideMenu didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"SideMenu didSelectRow: %@", indexPath);
    
    NSString *title = [array objectAtIndex:indexPath.row];
    if (indexPath.row == 0) {
        [SHARED_APPDELEGATE setDeshBoardViewController];
    }else if (indexPath.row == 1) {
        [SHARED_APPDELEGATE setViewController:[MyProfileView new] :YES :title :YES];//NO
    }else if (indexPath.row == 2) {
        [SHARED_APPDELEGATE setViewController:[AnnouncementViewController new] :YES :title :YES];//NO
    }else if (indexPath.row == 3) {
        [SHARED_APPDELEGATE setViewController:[AttendanceView new] :YES :title :YES];//NO
    }else if (indexPath.row == 4){
        [SHARED_APPDELEGATE setViewController:[HomeWorkViewController new] :YES :title :YES];
    }else if (indexPath.row == 5){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [TimeTableViewControlle new] :[ClassWorkViewController new] :YES :title :YES];
    }else if (indexPath.row == 6){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [UnitTestViewController new] :[TimeTableViewControlle new] :YES :title :YES];//NO
    }else if (indexPath.row == 7){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [ResultViewController new] :[UnitTestViewController new] :YES :title :YES];
    }else if (indexPath.row == 8){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [ReportCardViewController new] :[ResultViewController new] :YES :title :YES];//NO
    }else if (indexPath.row == 9){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [FeesViewController new] :[ReportCardViewController new] :YES :title :YES];
    }else if (indexPath.row == 10){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [ImprestViewController new] :[FeesViewController new] :YES :title :YES];
    }
    /*else if (indexPath.row == 10){
     [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [ImprestViewController new] :[ImprestViewController new] :YES :title :YES];//NO
     }*/
    else if (indexPath.row == 11){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [HolidayViewController new] :[HolidayViewController new] :YES :title :YES];
    }else if (indexPath.row == 12){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [LeaveListViewController new] :[LeaveListViewController new] :YES :title :YES];
    }else if (indexPath.row == 13){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [CircularViewController new] :[CircularViewController new] :YES :title :YES];
    }else if (indexPath.row == 14){
        if ([BunbleName containsString:@"Shilaj"]) {
            [[[UIAlertView alloc]initWithTitle:@"Logout" message:@"Are you sure you want to Logout?" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:@"Cancel", nil] show];
        }else{
            [SHARED_APPDELEGATE setViewController:[GalleryViewController new] :YES :title :YES];
        }
    }else if (indexPath.row == 15){
        [SHARED_APPDELEGATE setViewController:[MainViewController new] :YES :title :YES];
    }else if (indexPath.row == 16){
        [[[UIAlertView alloc]initWithTitle:@"Logout" message:@"Are you sure you want to Logout?" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:@"Cancel", nil] show];
    }
    [self.menuRight hide];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        [self deleteDevice];
    }
}

-(void)deleteDevice
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    [params setObject:[userDefault valueForKey:STUDENTID] forKey:@"StudentID"];
    [params setObject:[userDefault valueForKey:DeviceID] forKey:@"DeviceID"];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:DeleteDeviceDetail_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:ISREGISTER];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:REMEMBERME];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:CLASSID];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:FAMILYID];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:STANDARDID];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:STUDENTID];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"ISLOGIN"];
            [SHARED_APPDELEGATE registerForPushNotification:NO];
            [SHARED_APPDELEGATE setLoginview];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)sideMenuDidShow:(VKSideMenu *)sideMenu
{
    NSLog(@" VKSideMenue did show");
}

-(void)sideMenuDidHide:(VKSideMenu *)sideMenu
{
    NSLog(@" VKSideMenue did Hide");
}

-(NSString *)sideMenu:(VKSideMenu *)sideMenu titleForHeaderInSection:(NSInteger)section
{
    return nil;
}

- (IBAction)onClickBackBtn:(id)sender {
    isFromPush = NO;
    if (photoType != 0) {
        photoType -= 1;
        [[self navigationController] popViewControllerAnimated:YES];
    }
    else {
        photoType = 0;
        [[self navigationController] popToRootViewControllerAnimated:YES];
    }
}

- (IBAction)onClickSideMenuBtn:(id)sender {
    photoType = 0;
    [self clickToggle];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
