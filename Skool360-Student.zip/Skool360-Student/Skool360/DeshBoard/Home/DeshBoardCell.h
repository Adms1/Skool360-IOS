//
//  DeshBoardCell.h
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeshBoardCell : UICollectionViewCell

//UIImageView
@property (nonatomic , strong) IBOutlet UIImageView *imgIcon;

//UILabel
@property (nonatomic , strong) IBOutlet UILabel *lblTitle;

@end
