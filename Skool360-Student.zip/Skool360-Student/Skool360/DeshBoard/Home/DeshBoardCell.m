//
//  DeshBoardCell.m
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "DeshBoardCell.h"

@implementation DeshBoardCell

//UIImageView
@synthesize imgIcon;

//UILabel
@synthesize lblTitle;

- (void)awakeFromNib {
    [super awakeFromNib];
    //[self.lblTitle sizeToFit];
}

@end
