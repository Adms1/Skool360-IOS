//
//  StickyFlowLayout.h
//  Skool360
//
//  Created by ADMS on 29/08/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StickyFlowLayout : UICollectionViewFlowLayout

@end
