//
//  HomeView.h
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DeshBoardCell.h"
#import "MasterViewController.h"
#import "CollectionReusableView.h"
#import "UIImageView+GetLocalImage.h"

@interface HomeView : MasterViewController

{
    IBOutlet UICollectionView *collection;
    
    IBOutlet UIButton *btnSideMenu;
    
    NSMutableArray *arrDeshBoardList;
    
    IBOutlet UIView *viewtitle;
    
    IBOutlet UIImageView *imgLogo;
    
    // HeaderView
}
@end
