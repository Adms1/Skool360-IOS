//
//  HomeView.m
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "HomeView.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "ChangePasswordVC.h"
#import <UserNotifications/UserNotifications.h>

@interface HomeView ()
{
    NSMutableArray *arrProfileData;
}
@end

@implementation HomeView

AppDelegate *appDelegateHome;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //    [SHARED_APPDELEGATE setAppProperty];
    
    //    if (isiPhone6) {
    //        imgLogo.frame = CGRectMake(-62, 0, 140, 45);
    //    }else if (isiPhone6Plus){
    //        imgLogo.frame = CGRectMake(-82, 0, 140, 45);
    //    }
    
    NSString *isRegister = [[NSUserDefaults standardUserDefaults]objectForKey:ISREGISTER];
    
    if ([isRegister isEqualToString:@"0"])
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ChangePasswordVC *cpvc = (ChangePasswordVC *)[storyBoard instantiateViewControllerWithIdentifier:@"ChangePassword"];
        [self addChildViewController:cpvc];
        [self.view addSubview:cpvc.view];
        [cpvc.view setFrame:self.view.bounds];
        [cpvc didMoveToParentViewController:self];
    }
    
    BOOL forRateAvailable = [[[NSUserDefaults standardUserDefaults]objectForKey:ISAPPFOPEN] boolValue];
    
    if(forRateAvailable && ![BunbleName isEqualToString:@"Skool360"]){
        [RFRateMe showRateAlert];
    }
    
    [[NSUserDefaults standardUserDefaults] setBool:true forKey:ISAPPFOPEN];
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.titleView = viewtitle;
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    arrDeshBoardList = [[NSMutableArray alloc] initWithObjects:@"Announcement",@"Attendance",@"Home Work",@"Class Work",@"Time Table",@"Exam Syllabus",@"Results",@"Report Card",@"Fees",@"Planner",@"Leave Application",@"Circular",@"Gallery",@"Suggestion",nil];
    
    if ([BunbleName containsString:@"Shilaj"]) {
        [arrDeshBoardList removeObjectAtIndex:2];
    }
    
    [collection registerNib:[UINib nibWithNibName:@"DeshBoardCell" bundle:nil] forCellWithReuseIdentifier:@"Cell"];
    [collection registerNib:[UINib nibWithNibName:@"CollectionReusableView" bundle:nil]forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
        withReuseIdentifier:@"HeaderView"];
    
    [btnSideMenu setAttributedTitle:nil forState:UIControlStateNormal];
    [[btnSideMenu titleLabel] setNumberOfLines:0];
    [[btnSideMenu titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    
    //    UIBarButtonItem *barBtnFilter = [[UIBarButtonItem alloc] initWithCustomView:btnSideMenu];
    //    self.navigationItem.rightBarButtonItems = @[barBtnFilter];
    
    [self getStudentProfileData];
}

//-(void)viewWillAppear:(BOOL)animated
//{
//    //    [self getStudentProfileData];
//    
//    UILocalNotification *localNotification = [[UILocalNotification alloc] init];
////    localNotification.userInfo = userInfo;
////    localNotification.soundName = UILocalNotificationDefaultSoundName;
//    localNotification.alertBody = @"Tester......!!!!";
//    localNotification.fireDate = [[NSDate alloc]initWithTimeInterval:5 sinceDate:[NSDate date]];
//    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
//    
//    UNMutableNotificationContent *objNotificationContent = [[UNMutableNotificationContent alloc] init];
//    objNotificationContent.title = @"Test111";
//    objNotificationContent.body = @"Tester111";
//    
//    // Deliver the notification in five seconds.
//    //        UNTimeIntervalNotificationTrigger *trigger =  [UNTimeIntervalNotificationTrigger                                             triggerWithTimeInterval:5.0 repeats:NO];
//    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond|NSCalendarUnitTimeZone fromDate:[[NSDate date] dateByAddingTimeInterval:5]];
//    
//    UNCalendarNotificationTrigger *trigger = [UNCalendarNotificationTrigger triggerWithDateMatchingComponents:components repeats:NO];
//    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:@"New"                                                                            content:objNotificationContent trigger:trigger];
//    
//    // 3. schedule localNotification
//    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
//    
//    [center requestAuthorizationWithOptions:(UNAuthorizationOptionAlert + UNAuthorizationOptionSound + UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error) {
//        if (!granted) {
//            //Show alert asking to go to settings and allow permission
//        }
//    }];
//    
//    [center addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
//        if (!error) {
//            NSLog(@"Local Notification succeeded");
//        } else {
//            NSLog(@"Local Notification failed");
//        }
//    }];
//}

-(void)getStudentProfileData
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:profile_Url parameters:@{@"StudentID" : [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID]} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"Responce %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrMyPro = [responseObject safeObjectForKey:@"FinalArray"];
            
            arrProfileData = [NSMutableArray new];
            if ([arrMyPro count] > 0) {
                
                NSDictionary *dict = [arrMyPro firstObject];
                NSLog(@"dict>>> %@",dict);
                
                MyProfile *objProfile = [[MyProfile alloc] init];
                
                objProfile.AddmissionDate = [dict safeObjectForKey:@"AddmissionDate"];
                objProfile.Class = [dict safeObjectForKey:@"Class"];
                objProfile.StudentImage = [dict safeObjectForKey:@"StudentImage"];
                objProfile.StudentName = [dict safeObjectForKey:@"StudentName"];
                objProfile.Transport_DropTime = [dict safeObjectForKey:@"Transport_DropTime"];
                objProfile.Transport_PicupTime = [dict safeObjectForKey:@"Transport_PicupTime"];
                objProfile.Class = [dict safeObjectForKey:@"Class"];
                objProfile.Standard = [dict safeObjectForKey:@"Standard"];
                objProfile.GRNO = [dict safeObjectForKey:@"GRNO"];
                objProfile.ClassTeacher = [dict safeObjectForKey:@"ClassTeacher"];
                objProfile.TodayAttendance = [dict safeObjectForKey:@"TodayAttendance"];
                
                strImageProfile = objProfile.StudentImage;
                strStudentName = [NSString stringWithFormat:@"%@ (%@)", objProfile.StudentName, objProfile.GRNO];
                strGradeSection = [NSString stringWithFormat:@"%@ - %@", objProfile.Standard, objProfile.Class];
                [arrProfileData addObject:objProfile];
            }
        }else{
            [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"data"] delegate:self];
        }
        
        [collection reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark - UICollectionView Datasource/Delegate

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(self.view.frame.size.width, ((self.view.frame.size.width * 210)/320) - (IS_IPAD ? 50 : 0));
}

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout *)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGSize cellSize = CGSizeMake(self.view.frame.size.width/(IS_IPAD ? 4 : 3), self.view.frame.size.width/(IS_IPAD ? 4 : 3));
    return cellSize;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView
           viewForSupplementaryElementOfKind:(NSString *)kind
                                 atIndexPath:(NSIndexPath *)indexPath
{
    if (kind == UICollectionElementKindSectionHeader) {
        
        CollectionReusableView *resuableView = [[CollectionReusableView alloc] init];
        resuableView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView" forIndexPath:indexPath];
        if(arrProfileData.count > 0){
            [resuableView addImages];
            [resuableView headerData:[arrProfileData objectAtIndex:0]];
        }
        return resuableView;
    }
    return nil;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [arrDeshBoardList count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = @"Cell";
    DeshBoardCell *cell = (DeshBoardCell *)[collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    
    
    cell.lblTitle.text = [arrDeshBoardList objectAtIndex:indexPath.row];
    [cell.imgIcon getImagesfromLocal:cell.lblTitle.text];
    
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *title = [arrDeshBoardList objectAtIndex:indexPath.row];
    if (indexPath.row == 0){
        [SHARED_APPDELEGATE setViewController:[AnnouncementViewController new] :YES :title :YES];
    }else if (indexPath.row == 1) {
        [SHARED_APPDELEGATE setViewController:[AttendanceView new] :YES :title :YES];//NO
    }else if (indexPath.row == 2){
        [SHARED_APPDELEGATE setViewController:[HomeWorkViewController new] :YES :title :YES];
    }else if (indexPath.row == 3){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [TimeTableViewControlle new] :[ClassWorkViewController new] :YES :title :YES];
    }else if (indexPath.row == 4){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [UnitTestViewController new] :[TimeTableViewControlle new] :YES :title :YES];//NO
    }else if (indexPath.row == 5){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [ResultViewController new] :[UnitTestViewController new] :YES :title :YES];
    }else if (indexPath.row == 6){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [ReportCardViewController new] :[ResultViewController new] :YES :title :YES];//NO
    }else if (indexPath.row == 7){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [FeesViewController new] :[ReportCardViewController new] :YES :title :YES];
    }else if (indexPath.row == 8){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [ImprestViewController new] :[FeesViewController new] :YES :title :YES];
    }
    /*else if (indexPath.row == 8){
     [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [ImprestViewController new] :[ImprestViewController new] :YES :title :YES];//NO
     }*/
    else if (indexPath.row == 9){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [HolidayViewController new] :[HolidayViewController new] :YES :title :YES];
    }else if (indexPath.row == 10){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [LeaveListViewController new] :[LeaveListViewController new] :YES :title :YES];
    }else if (indexPath.row == 11){
        [SHARED_APPDELEGATE setViewController:[BunbleName containsString:@"Shilaj"] ? [CircularViewController new] :[CircularViewController new] :YES :title :YES];
    }else if (indexPath.row == 12){
        [SHARED_APPDELEGATE setViewController:[GalleryViewController new] :YES :title :YES];
    }else if (indexPath.row == 13){
        [SHARED_APPDELEGATE setViewController:[MainViewController new] :YES :title :YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
