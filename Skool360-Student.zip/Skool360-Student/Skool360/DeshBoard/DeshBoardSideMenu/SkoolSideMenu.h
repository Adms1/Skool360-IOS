//
//  SkoolSideMenu.h
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SkoolCell.h"

@interface SkoolSideMenu : UIViewController

{
    IBOutlet UITableView *tblSideMenu;
    
    NSMutableArray *arrSideMenu;
}

@end
