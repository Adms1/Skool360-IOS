//
//  ImprestCell.h
//  Skool360
//
//  Created by ADMS on 02/01/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImprestCell : UITableViewCell
{
    IBOutlet UILabel *lblOpeningBalance;
    IBOutlet UILabel *lblDeduction;
    IBOutlet UILabel *lblBalance;
    IBOutlet UILabel *lblDetail;
}
-(void)setData:(NSDictionary *)dict;
@end
