//
//  ImprestViewController.m
//  Skool360
//
//  Created by Darshan on 02/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "ImprestViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "ImprestCell.h"

@interface ImprestViewController ()
{
    NSInteger selectedSection;
    NSMutableArray *arrImprestList;
}
@end

@implementation ImprestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (isiPhone6) {
        imgLogo.frame = CGRectMake(-66, 0, 140, 45);
    }else if (isiPhone6Plus){
        imgLogo.frame = CGRectMake(-86, 0, 140, 45);
    }
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.titleView = viewtitle;
    
    [btnSideMenu setAttributedTitle:nil forState:UIControlStateNormal];
    [[btnSideMenu titleLabel] setNumberOfLines:0];
    [[btnSideMenu titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    
    //    UIBarButtonItem *barBtnSide = [[UIBarButtonItem alloc] initWithCustomView:btnSideMenu];
    //    self.navigationItem.rightBarButtonItems = @[barBtnSide];
    //
    //    UIBarButtonItem *barBtnBack = [[UIBarButtonItem alloc] initWithCustomView:btnBack];
    //    self.navigationItem.leftBarButtonItems = @[barBtnBack];
    
    btnAcademicYear.layer.borderWidth = 1.0f;
    btnAcademicYear.layer.borderColor = imprestBackColor.CGColor;
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    imgNoRecord.hidden = YES;
    
    arrAcademic = [[NSMutableArray alloc] init];
    arrTermID = [[NSMutableArray alloc] init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:term_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            NSMutableArray *arrAcademicYear = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dict in arrAcademicYear) {
                NSString *strTerm = [NSString stringWithFormat:@"%@",[dict safeObjectForKey:@"Term"]];
                NSString *strTermID = [NSString stringWithFormat:@"%@",[dict safeObjectForKey:@"TermId"]];
                
                [arrAcademic addObject:strTerm];
                [arrTermID addObject:strTermID];
            }
            
            NSSortDescriptor* sortOrder = [NSSortDescriptor sortDescriptorWithKey: @"self" ascending: YES];
            arrAcademic = [arrAcademic sortedArrayUsingDescriptors: [NSArray arrayWithObject: sortOrder]];
            arrTermID = [arrTermID sortedArrayUsingDescriptors: [NSArray arrayWithObject: sortOrder]];
            
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyy"];
            NSString *yearString = [formatter stringFromDate:[NSDate date]];
            int nextYear = [[yearString substringFromIndex:2]intValue]+1;
            
            NSInteger idx = [arrAcademic indexOfObject:[NSString stringWithFormat:@"%@-%d",yearString,nextYear]];
            
            if (idx > arrAcademic.count -1)
            {
                idx = arrAcademic.count -1;
            }
            
            [btnAcademicYear setTitle:[NSString stringWithFormat:@"%@",[arrAcademic objectAtIndex:idx]] forState:UIControlStateNormal];
            
            strImprestTermID = [NSString stringWithFormat:@"%@",[arrTermID objectAtIndex:idx]];
            
            [self setImprestService];
        }else{
            
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
    
}

#pragma mark -
#pragma mark - BUTTONCLICK Method

- (IBAction)onClickAcademicYearBtn:(id)sender {
    
    NSArray * arr = [[NSArray alloc] initWithArray:arrAcademic];
    //    arr = [NSMutableArray arrayWithObjects:arrAcademic, nil];
    
    if(dropDown == nil) {
        CGFloat f = arrAcademic.count * 30;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender :(NSInteger)index
{
    [self rel];
    
    strImprestTermID = [NSString stringWithFormat:@"%@",[arrTermID objectAtIndex:index]];
    NSLog(@"AcademicTerm %@",strImprestTermID);
    [self setImprestService];
    
    [btnAcademicYear setTitle:btnAcademicYear.titleLabel.text forState:UIControlStateNormal];
}

-(void)setImprestService
{
    selectedSection = -1;
    arrImprestList = [[NSMutableArray alloc]init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    imgNoRecord.hidden = YES;
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strImprestTermID forKey:@"Term"];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:imprest_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            lblOpeningBalance.text = [responseObject safeObjectForKey:@"OpeningBalance"];
            lblMyBalance.text = [responseObject safeObjectForKey:@"MyBalance"];
            
            NSMutableArray *arrAcademicYear = [responseObject safeObjectForKey:@"FinalArray"];
            [arrImprestList addObjectsFromArray:arrAcademicYear];
            
        }else{
            imgNoRecord.hidden = NO;
        }
        [tblImprest reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}
-(void)rel{
    //    [dropDown release];
    dropDown = nil;
}

#pragma mark - Tableview DataSource & Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return arrImprestList.count;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    ImprestCell *headerView = (ImprestCell *)[tableView dequeueReusableCellWithIdentifier:@"ImprestHeaderCell"];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(expandCollapseSection:)];
    headerView.contentView.tag = section;
    [headerView.contentView addGestureRecognizer:tapGesture];
    
    if(section != selectedSection) {
        headerView.contentView.subviews[0].backgroundColor = [UIColor grayColor];
    }else {
        headerView.contentView.subviews[0].backgroundColor = sectionSelectColor;
    }
    
    NSDictionary *dictData =[arrImprestList objectAtIndex:section];
    
    NSString *strDate = [NSString stringWithFormat:@"%@",[dictData safeObjectForKey:@"Date"]];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy HH:mm:ss"];
    NSDate *date = [dateFormatter dateFromString: strDate];
    dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    
    NSString *strConvertDate = [dateFormatter stringFromDate:date];
    
    [((UILabel *)headerView.contentView.subviews[0].subviews[0]) setText:strConvertDate];
    
    return arrImprestList.count > 0 ? headerView.contentView : nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return IS_IPAD ? 120 : 108;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSDictionary *dictData = [arrImprestList objectAtIndex:section];
    NSArray *arrData = [dictData objectForKey:@"Data"];
    return  section == selectedSection ? [arrData count] : 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    ImprestCell *cell = (ImprestCell *)[tableView dequeueReusableCellWithIdentifier:@"ImprestCell"];
    
    NSDictionary *dictData =[arrImprestList objectAtIndex:indexPath.section];
    NSArray *arrsecton = [dictData safeObjectForKey:@"Data"];
    NSDictionary *dict = [arrsecton objectAtIndex:indexPath.row];
    
    [cell setData: dict];
    
    return cell;
}

-(void)expandCollapseSection:(UITapGestureRecognizer *)gesture
{
    NSInteger Index = gesture.view.tag;
    if(selectedSection == Index) {
        selectedSection = -1;
    }
    else {
        selectedSection = Index;
    }
    
    [tblImprest reloadData];
    
    if(selectedSection != -1){
        [tblImprest scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:selectedSection] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
