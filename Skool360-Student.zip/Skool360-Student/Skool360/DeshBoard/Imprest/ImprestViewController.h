//
//  ImprestViewController.h
//  Skool360
//
//  Created by Darshan on 02/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "NIDropDown.h"

@interface ImprestViewController : MasterViewController <NIDropDownDelegate>

{
    IBOutlet UIView *viewtitle;
    IBOutlet UIView *viewImprest;
    IBOutlet UIView *viewBack;
    IBOutlet UIView *viewSubImprest;
    
    IBOutlet UIImageView *imgLogo;
    IBOutlet UITableView *tblImprest;

    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    IBOutlet UIButton *btnAcademicYear;
    
    IBOutlet UILabel *lblNoFound;
    IBOutlet UIImageView *imgNoRecord;

    IBOutlet UILabel *lblOpeningBalance;
    IBOutlet UILabel *lblMyBalance;
    IBOutlet UILabel *lblDate;
    IBOutlet UILabel *lblImprestOpeningBalance;
    IBOutlet UILabel *lblDeduction;
    IBOutlet UILabel *lblBalance;
    IBOutlet UILabel *lblDetail;
    
    NIDropDown *dropDown;
    
    NSMutableArray *arrAcademic;
    NSMutableArray *arrTermID;
    
    NSString *strImprestTermID;
}

@end
