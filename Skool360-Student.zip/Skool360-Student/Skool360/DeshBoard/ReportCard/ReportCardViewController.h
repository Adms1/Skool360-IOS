//
//  ReportCardViewController.h
//  Skool360
//
//  Created by ADMS on 01/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"
#import "NIDropDown.h"

@interface ReportCardViewController : MasterViewController <NIDropDownDelegate>
{
    IBOutlet UIButton *btnResult;
    IBOutlet UIButton *btnAcademicYear;
    IBOutlet UIWebView *webView;
    IBOutlet UIActivityIndicatorView *actView;
    IBOutlet UIImageView *imgNoRecord;
}
@end
