//
//  LeaveCell.h
//  Bhadaj (Student)
//
//  Created by ADMS on 24/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Leave.h"
@interface LeaveCell : UITableViewCell
-(void)displayLeaveData:(Leave *)leaveData :(NSInteger)index;
@end
