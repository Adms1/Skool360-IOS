//
//  AppointmentViewController.m
//  Skool360
//
//  Created by Darshan on 02/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "LeaveApplicationViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface LeaveApplicationViewController ()
{
    UIButton *btnSelected;
    NSString *strFromDate;
    NSString *strToDate;
}
@end

@implementation LeaveApplicationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    btnFromDate.layer.cornerRadius = 4.0f;
    btnFromDate.layer.borderWidth = 0.5f;
    btnFromDate.layer.borderColor = imgCircleColor.CGColor;
    
    btnToDate.layer.cornerRadius = 4.0f;
    btnToDate.layer.borderWidth = 0.5f;
    btnToDate.layer.borderColor = imgCircleColor.CGColor;
    
    viewDescription.layer.borderWidth = 0.5f;
    viewDescription.layer.borderColor = imgCircleColor.CGColor;
    
    txtReason.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"" attributes:@{NSForegroundColorAttributeName: txtFieldColor,NSFontAttributeName:FONT_OpenSans(IS_IPAD ? 15 : 12)}];
    txtReason.backgroundColor = [UIColor whiteColor];
    txtReason.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtReason.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtReason.leftViewMode = UITextFieldViewModeAlways;
    txtReason.rightViewMode = UITextFieldViewModeAlways;
    txtReason.layer.borderWidth = 0.5;
    txtReason.layer.borderColor = imgCircleColor.CGColor;
    
    btnSave.layer.cornerRadius = 4.0f;
    btnCancel.layer.cornerRadius = 4.0f;
    btnDone.layer.cornerRadius = 2.0f;
    btnPickerDateCancel.layer.cornerRadius = 2.0f;
    
    [scrollV setContentOffset:CGPointMake(0, 20) animated:YES];
    
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strCurrentDate = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:[NSDate date]]];
    
    [btnFromDate setTitle:strCurrentDate forState:UIControlStateNormal];
    strFromDate = btnFromDate.titleLabel.text;
    
    [btnToDate setTitle:strCurrentDate forState:UIControlStateNormal];
    strToDate = btnToDate.titleLabel.text;
}

-(void)viewWillAppear:(BOOL)animated
{
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]firstObject]) setTitle:self.title.uppercaseString forState:0];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:1]) addTarget:self action:@selector(onClickSideMenuBtn:) forControlEvents:UIControlEventTouchUpInside];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:2]) addTarget:self action:@selector(onClickBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    UIDatePicker *picker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 30, self.view.frame.size.width - 20, 200)];
    [picker setMinimumDate:[NSDate date]];
    [picker setDatePickerMode:UIDatePickerModeDate];
    [picker addTarget:self action:@selector(onClickPickDate:) forControlEvents:UIControlEventValueChanged];
    picker.tag = 100;
    if ([viewDatePicker viewWithTag:100] == nil) {
        [viewDatePicker addSubview:picker];
    }
}

-(BOOL)LeaveValidate
{
    NSString *strPurpose  = [CommonClass trimString:txtReason.text];
    //NSString *strDescription  = [CommonClass trimString:txvComment.text];
    
    if ([strPurpose length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePurposeReason delegate:self];
        return NO;
    }
    //    if ([strDescription length] == 0) {
    //        [CommonClass showAlertWithTitle:provideAlert andMessage:provideDiscribe delegate:self];
    //        return NO;
    //    }
    return  YES;
}

#pragma mark -
#pragma mark - TEXT FILED DELEGATE

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [viewDatePicker setHidden:YES];
    
    CGPoint point;
    
    if (textField == txtReason) {
        point = CGPointMake(0, 0);
    }
}

#pragma mark -
#pragma mark - TEXT VIEW DELEGATE

-(void)textViewDidBeginEditing:(UITextView *)textView
{
    [viewDatePicker setHidden:YES];
    
    if (!(IS_IPAD)) {
        [scrollV setContentOffset:CGPointMake(0,txvComment.frame.origin.y + 100) animated:YES];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    [scrollV setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        [scrollV setContentOffset:CGPointMake(0,0) animated:YES];
        return NO;
    }
    return YES;
}

#pragma mark -
#pragma mark - BUTTONCLICK Method

- (IBAction)onClickFromToDateBtn:(UIButton *)sender {
    
    btnSelected = sender;
    
    [[self view]endEditing:YES];
    [scrollV setContentOffset:CGPointZero animated:YES];
    
    viewDatePicker.frame = CGRectMake(viewDatePicker.frame.origin.x, (SHARED_APPDELEGATE.window.frame.size.height - 200)/2, SHARED_APPDELEGATE.window.frame.size.width - 20, 230);
    
    viewDatePicker.hidden = NO;
}

- (IBAction)onClickSaveBtn:(id)sender {
    
    [txtReason resignFirstResponder];
    [txvComment resignFirstResponder];
    [scrollV setContentOffset:CGPointZero animated:YES];
    
    if ([self LeaveValidate]) {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
        
        [params setObject:strStudentID forKey:@"studentId"];
        [params setObject:strFromDate forKey:@"FromDate"];
        [params setObject:strToDate forKey:@"ToDate"];
        [params setObject:txtReason.text forKey:@"Reason"];
        [params setObject:txvComment.text forKey:@"Comment"];
        
        NSLog(@"params>>> %@",params);
        
        [manager POST:InsertStudentLeaveRequest_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                [[[UIAlertView alloc]initWithTitle:provideAlert message:provideLeaveSend delegate:self cancelButtonTitle:@"Close" otherButtonTitles:nil, nil] show];
                [self onClickCancelBtn:nil];
            }else {
                [CommonClass showAlertWithTitle:provideAlert andMessage:[[[responseObject safeObjectForKey:@"FinalArray"]firstObject] safeObjectForKey:@"Message"] delegate:self];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [CommonClass errorAlert:error.code :self];
            
            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [[self navigationController]popViewControllerAnimated:YES];
}

- (IBAction)onClickCancelBtn:(id)sender {
    
    txtReason.text = @"";
    txvComment.text = @"";
    [txtReason resignFirstResponder];
    [txvComment resignFirstResponder];
    [scrollV setContentOffset:CGPointZero animated:YES];
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strCurrentDate = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:[NSDate date]]];
    
    [btnSelected == btnFromDate ? btnFromDate : btnToDate setTitle:strCurrentDate forState:UIControlStateNormal];
    
    if(btnSelected == btnFromDate) {
        strFromDate = strCurrentDate;
    }else{
        strToDate = strCurrentDate;
    }
}

- (IBAction)onClickDoneBtn:(id)sender {
    
    viewDatePicker.hidden = YES;
}

- (IBAction)onClickDatePickerCancelBtn:(id)sender {
    
    [btnSelected == btnFromDate ? btnFromDate : btnToDate setTitle:btnSelected == btnFromDate ? strFromDate : strToDate forState:UIControlStateNormal];
    viewDatePicker.hidden = YES;
}

- (IBAction)onClickPickDate:(UIDatePicker *)datePicker {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strDate = [dateFormatter stringFromDate:datePicker.date];
    [datePicker setMinimumDate:[NSDate date]];
    [datePicker setMaximumDate:nil];

    NSLog(@"%@",strDate);
    
    if(btnSelected == btnFromDate) {
        if(strToDate != nil){
            [datePicker setMaximumDate:[dateFormatter dateFromString:strToDate]];
        }
        strFromDate = strDate;
    }else{
        if(strFromDate != nil){
            [datePicker setMinimumDate:[dateFormatter dateFromString:strFromDate]];
        }
        strToDate = strDate;
    }
    [btnSelected == btnFromDate ? btnFromDate : btnToDate setTitle:strDate forState:UIControlStateNormal];
}

- (IBAction)onClickBackBtn:(id)sender {
    [[self navigationController]popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end


