//
//  LeaveListViewController.m
//  Bhadaj (Student)
//
//  Created by ADMS on 24/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "LeaveListViewController.h"
#import "LeaveApplicationViewController.h"
#import "CommonClass.h"
#import "LeaveCell.h"
#import "Leave.h"

@interface LeaveListViewController ()
{
    NSMutableArray *arrLeaveList;
}
@end

@implementation LeaveListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)viewWillAppear:(BOOL)animated
{
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]firstObject]) setTitle:self.title.uppercaseString forState:0];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:1]) addTarget:self action:@selector(onClickSideMenuBtn:) forControlEvents:UIControlEventTouchUpInside];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:2]) addTarget:self action:@selector(onClickBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    btnAdd.layer.cornerRadius = IS_IPAD ? 30 : 25;
    [btnAdd.layer setShadowColor:[UIColor blackColor].CGColor];
    [btnAdd.layer setShadowOpacity:0.1f];
    [btnAdd.layer setShadowRadius:2.0f];
    [btnAdd.layer setShadowOffset:CGSizeMake(0.0f, 2.0f)];
    
    [imgNoRecord setHidden:YES];
    [self callGetLeaveListApi];
}

-(void)callGetLeaveListApi
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    [params setObject:strStudentID forKey:@"StudentId"];
    
    [manager POST:GetStudentLeaveRequest_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        arrLeaveList = [[NSMutableArray alloc]init];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrList = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dic in arrList)
            {
                Leave *l = [[Leave alloc]init];
                
                l.strReason = dic[@"Reason"];
                l.strFromDate = dic[@"FromDate"];
                l.strToDate = dic[@"ToDate"];
                l.strStatus = dic[@"Status"];
                
                [arrLeaveList addObject:l];
            }
        }else{
            [imgNoRecord setHidden:NO];
        }
        
        [tblLeaveList reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    LeaveCell *headerView = (LeaveCell *)[tableView dequeueReusableCellWithIdentifier:@"LeaveHeaderCell"];
    return arrLeaveList.count > 0 ? headerView.contentView : nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return arrLeaveList.count > 0 ? 40 : 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrLeaveList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    LeaveCell *cell = (LeaveCell *)[tableView dequeueReusableCellWithIdentifier:@"LeaveCell" forIndexPath:indexPath];
//    [CommonClass addShadow:cell.contentView.subviews[0] : 1.0];
    [cell displayLeaveData:arrLeaveList[indexPath.row] :indexPath.row+1];
    return cell;
}

-(IBAction)btnAddLeave:(id)sender
{
    ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    LeaveApplicationViewController *lavc = [storyBoard instantiateViewControllerWithIdentifier:@"LeaveApplicationViewController"];
    lavc.transition = animation;
    lavc.title = @"Create Leave Application";
    [self.navigationController pushViewController:lavc animated:YES];
}

@end
