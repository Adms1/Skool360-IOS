//
//  LeaveCell.m
//  Bhadaj (Student)
//
//  Created by ADMS on 24/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "LeaveCell.h"
#import "CommonClass.h"

@implementation LeaveCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)displayLeaveData:(Leave *)leaveData :(NSInteger)index
{
    NSArray *array = @[[NSString stringWithFormat:@"%ld",(long)index], leaveData.strReason, [NSString stringWithFormat:@"%@ - %@",[CommonClass convertToDate:leaveData.strFromDate :@"dd/MM/yyyy" :@"dd MMM"],[CommonClass convertToDate:leaveData.strToDate :@"dd/MM/yyyy" :@"dd MMM"]], leaveData.strStatus];
    
    int i = 0;
    for (UIView *view in self.contentView.subviews[0].subviews) {
        if([view isKindOfClass:[UILabel classForCoder]]){
            UILabel *lbl = (UILabel *)view;
            lbl.text = array[i];
            lbl.font = [UIFont fontWithName:lbl.font.fontName size:lbl.font.pointSize + (IS_IPAD ? 2 : 0)];
            lbl.textColor = [leaveData.strStatus isEqualToString:@"Rejected"] ? absentColor : [UIColor blackColor];
            
            if(i == 3){
                if([leaveData.strStatus isEqualToString:@"Confirmed"] || [leaveData.strStatus isEqualToString:@"Approved"]){
                    lbl.textColor = presentColor;
                }else if([leaveData.strStatus isEqualToString:@"Pending"]){
                    lbl.textColor = pendingColor;
                }else{
                    lbl.textColor = absentColor;
                }
            }
            i += 1;
        }
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
