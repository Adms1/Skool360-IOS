//
//  SentInboxCell.m
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "SentInboxSCell.h"
#import "CommonClass.h"

@implementation SentInboxSCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    //    for (UIView *view in self.contentView.subviews[0].subviews) {
    //        if ([view isKindOfClass:[UILabel classForCoder]]) {
    //            UILabel *lbl = (UILabel *)view;
    //            lbl.font = FONT_OpenSans(IS_IPAD ? 16 : 13);
    //        }
    //    }
}

-(void)displayHeaderData:(InboxSentS *)data :(BOOL)isInbox
{
    _lblSubject.text = data.Subject;
    _lblSubject.font = FONT_Semibold(IS_IPAD ? 18 : 15);
    
    NSString *str = data.Sdate;
    if (isInbox) {
        str = data.Rdate;
    }
    
    _width.constant = [str isEqualToString:@""] ? 0 : 90;
    
    _lblRDate.text = [CommonClass convertToDate:str :@"yyyy-MM-dd'T'HH:mm:ss.SSSS" :@"dd MMM yyyy"];
    _lblRDate.font = FONT_OpenSans(IS_IPAD ? 16 : 13);
    
    _lblTime.text = [str isEqualToString:@""] ? @"" : [CommonClass timeAgoStringFromDate:str];
    _lblTime.font = FONT_Semibold(IS_IPAD ? 13 : 12);
}

-(void)displaySentData:(InboxSentS *)data
{
    _lblSuggestion.text = data.Suggestion;
    _lblSuggestion.font = FONT_OpenSans(IS_IPAD ? 16 : 13);
    
    _lblSDate.text = [CommonClass convertToDate:data.Sdate :@"yyyy-MM-dd'T'HH:mm:ss.SSSS" :@"dd MMM yyyy h:mm a"];
    _lblSDate.font = FONT_OpenSans(IS_IPAD ? 16 : 13);
}

-(void)displayInboxData:(InboxSentS *)data
{
    _lblSuggestion.text = data.Suggestion;
    _lblSuggestion.font = FONT_OpenSans(IS_IPAD ? 16 : 13);
    
    _lblReply.text = data.Reply;
    _lblReply.font = FONT_Semibold(IS_IPAD ? 18 : 15);
    
    _lblSDate.text = [CommonClass convertToDate:data.Sdate :@"yyyy-MM-dd'T'HH:mm:ss.SSSS" :@"dd MMM yyyy h:mm a"];
    _lblSDate.font = FONT_OpenSans(IS_IPAD ? 16 : 13);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
@end
