//
//  InboxSent.h
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InboxSentS : NSObject

@property (nonatomic , strong) NSString *Name;
@property (nonatomic , strong) NSString *Subject;
@property (nonatomic , strong) NSString *Rdate;
@property (nonatomic , strong) NSString *Suggestion;
@property (nonatomic , strong) NSString *Reply;
@property (nonatomic , strong) NSString *Sdate;
@end
