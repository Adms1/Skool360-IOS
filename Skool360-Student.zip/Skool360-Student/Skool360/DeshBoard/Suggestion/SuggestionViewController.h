//
//  SuggestionViewController.h
//  Bhadaj (Student)
//
//  Created by ADMS on 25/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface SuggestionViewController : MasterViewController
{
    IBOutlet UIView *viewDescription;
    IBOutlet UIButton *btnSave;
    IBOutlet UIButton *btnCancel;
    IBOutlet UITextField *txtSubject;
    IBOutlet UITextView *txvSuggestion;
    IBOutlet UIButton *btnSelectTo;
}
@end
