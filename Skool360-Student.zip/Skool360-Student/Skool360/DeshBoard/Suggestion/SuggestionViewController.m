//
//  SuggestionViewController.m
//  Bhadaj (Student)
//
//  Created by ADMS on 25/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "SuggestionViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "FCAlertView.h"
#import "NIDropDown.h"

@interface SuggestionViewController ()<NIDropDownDelegate>
{
    NIDropDown *dropDown;
    NSString *strSelectTo;
}
@end

@implementation SuggestionViewController

typedef void(^myCompletion)(BOOL);

- (void)viewDidLoad {
    [super viewDidLoad];
    
    viewDescription.layer.borderWidth = 0.5f;
    viewDescription.layer.borderColor = imgCircleColor.CGColor;
    
    txtSubject.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"" attributes:@{NSForegroundColorAttributeName: txtFieldColor,NSFontAttributeName:FONT_OpenSans(IS_IPAD ? 15 : 12)}];
    txtSubject.backgroundColor = [UIColor whiteColor];
    txtSubject.leftView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtSubject.rightView = [SHARED_APPDELEGATE getTextFieldLeftAndRightView];
    txtSubject.leftViewMode = UITextFieldViewModeAlways;
    txtSubject.rightViewMode = UITextFieldViewModeAlways;
    txtSubject.layer.borderWidth = 0.5;
    txtSubject.layer.borderColor = imgCircleColor.CGColor;
    
    btnSave.layer.cornerRadius = 4.0f;
    btnCancel.layer.cornerRadius = 4.0f;
    
    btnSelectTo.layer.borderWidth = 0.5f;
    btnSelectTo.layer.borderColor = imgCircleColor.CGColor;
    
    strSelectTo = @"";
}

-(BOOL)SuggestionValidate
{
    NSString *strSubject  = [CommonClass trimString:txtSubject.text];
    NSString *strComment  = [CommonClass trimString:txvSuggestion.text];
    
    if([strSelectTo isEqualToString:@""])
    {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideSelectType delegate:self];
        return NO;
    }
    else if ([strSubject length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideSuggestionSubject delegate:self];
        return NO;
    }
    else if ([strComment length] == 0) {
        [CommonClass showAlertWithTitle:provideAlert andMessage:provideSuggestion delegate:self];
        return NO;
    }
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

- (IBAction)onClickSaveBtn:(id)sender {
    
    [txtSubject resignFirstResponder];
    [txvSuggestion resignFirstResponder];
    
    if ([self SuggestionValidate]) {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
        
        [params setObject:strStudentID forKey:@"StudentId"];
        [params setObject:strSelectTo forKey:@"Type"];
        [params setObject:txtSubject.text forKey:@"Subject"];
        [params setObject:txvSuggestion.text forKey:@"Comment"];
        
        NSLog(@"params>>> %@",params);
        
        [manager POST:CreateParentsSuggestion_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            [SHARED_APPDELEGATE hideLoadingView];
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                FCAlertView *alert = [[FCAlertView alloc] init];
                alert.colorScheme = presentColor;
                [alert showAlertInView:self
                             withTitle:@"Suggestion"
                          withSubtitle:[[[responseObject safeObjectForKey:@"FinalArray"]firstObject] safeObjectForKey:@"Message"]
                       withCustomImage:[UIImage imageNamed:@"checkmark-round.png"]
                   withDoneButtonTitle:nil
                            andButtons:@[]];
            }else{
                [CommonClass showAlertWithTitle:provideAlert andMessage:[[[responseObject safeObjectForKey:@"FinalArray"]firstObject] safeObjectForKey:@"Message"] delegate:self];
            }
            [self onClickCancelBtn:nil];
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [CommonClass errorAlert:error.code :self];

            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
}

-(IBAction)btnSelectTo:(UIButton *)sender
{
    NSArray *array = @[@"Academic", @"Admin", @"Other"];
    if(dropDown == nil) {
        CGFloat f = array.count * 30;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :array :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender :(NSInteger)index{
    strSelectTo = @[@"Academic", @"Admin", @"Other"][index];
    [self rel];
}

-(void)rel{
    dropDown = nil;
}

- (IBAction)onClickCancelBtn:(id)sender {
    
    [btnSelectTo setTitle:@"Please select" forState:0];
    strSelectTo = @"";
    txtSubject.text = @"";
    txvSuggestion.text = @"";
    [txtSubject resignFirstResponder];
    [txvSuggestion resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
