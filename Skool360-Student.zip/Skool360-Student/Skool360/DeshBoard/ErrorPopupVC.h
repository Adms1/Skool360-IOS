//
//  ErrorPopupVC.h
//  Skool360
//
//  Created by ADMS on 21/08/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface ErrorPopupVC : MasterViewController

@end
