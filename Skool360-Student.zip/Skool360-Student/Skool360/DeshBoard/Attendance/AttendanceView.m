//
//  AttendanceView.m
//  Skool360
//
//  Created by Darshan on 24/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "AttendanceView.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "AttendanceCell.h"
#import "Holiday.h"

@interface AttendanceView ()
{
    NSArray *array;
    CGFloat tblHeight;
    NSMutableArray *arrHolidayData;
}
@end

@implementation AttendanceView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (isiPhone6) {
        imgLogo.frame = CGRectMake(-66, 0, 140, 45);
    }else if (isiPhone6Plus){
        imgLogo.frame = CGRectMake(-86, 0, 140, 45);
    }
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.titleView = viewtitle;
    
    [btnSideMenu setAttributedTitle:nil forState:UIControlStateNormal];
    [[btnSideMenu titleLabel] setNumberOfLines:0];
    [[btnSideMenu titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    //    UIBarButtonItem *barBtnSide = [[UIBarButtonItem alloc] initWithCustomView:btnSideMenu];
    //    self.navigationItem.rightBarButtonItems = @[barBtnSide];
    //
    //    UIBarButtonItem *barBtnBack = [[UIBarButtonItem alloc] initWithCustomView:btnBack];
    //    self.navigationItem.leftBarButtonItems = @[barBtnBack];
    
    tblFooterView.layer.cornerRadius = 2.0f;
    tblFooterView.layer.borderWidth = 0.5f;
    tblFooterView.layer.borderColor = imgCircleColor.CGColor;
    
    btnMonth.layer.cornerRadius = 4.0f;
    btnMonth.layer.borderWidth = 0.5f;
    btnMonth.layer.borderColor = imgCircleColor.CGColor;
    
    btnYear.layer.cornerRadius = 4.0f;
    btnYear.layer.borderWidth = 0.5f;
    btnYear.layer.borderColor = imgCircleColor.CGColor;
    
    btnFilter.layer.cornerRadius = 4.0f;
    btnPresent.layer.cornerRadius = 4.0f;
    btnAbsent.layer.cornerRadius = 4.0f;
    
    eventPresent = [[NSMutableDictionary alloc] init];
    eventAbsernt = [[NSMutableDictionary alloc] init];
    eventleave = [[NSMutableDictionary alloc] init];
    eventComment = [[NSMutableDictionary alloc] init];
    
    eventPresent = [NSMutableDictionary new];
    eventAbsernt = [NSMutableDictionary new];
    eventleave = [NSMutableDictionary new];
    
    arrAttendance = [[NSMutableArray alloc] init];
    
    NSDateFormatter *dfy = [[NSDateFormatter alloc] init];
    NSDateFormatter *dfm = [[NSDateFormatter alloc] init];
    NSDateFormatter *dfM = [[NSDateFormatter alloc] init];
    
    [dfy setDateFormat:@"yyyy"];
    [dfm setDateFormat:@"MM"];
    [dfM setDateFormat:@"MMM"];
    
    NSDate *date = [NSDate date];
    if (isFromPush) {
        date = [CommonClass getDateFromString:pushData[@"Date"] :@"dd/MM/yyyy"];
    }
    
    strYear = [dfy stringFromDate:date];
    strMonth = [dfm stringFromDate:date];
    NSString *strMonths = [dfM stringFromDate:date];
    
    [btnMonth setTitle:strMonths forState:UIControlStateNormal];
    [btnYear setTitle:strYear forState:UIControlStateNormal];
    
    calendarManager = [JTCalendarManager new];
    calendarManager.delegate = self;
    
    //    [self createRandomEvents];
    [self createMinAndMaxDate];
    
    calendarMenuView.contentRatio = .70;
    [calendarManager setMenuView:calendarMenuView];
    [calendarManager setContentView:calendarContentView];
    [calendarManager setDate:date];
    
    strFilterYear = strYear;
    strFilterMonth = strMonth;
    
    [self setAttendanceValueIntoCalander:strMonth andYear:strYear];
}

-(void)viewDidAppear:(BOOL)animated
{
    [self.view layoutIfNeeded];
    tblHeight = tblFooterView.frame.origin.y - 10;
}

-(void)moveTbl:(UIPanGestureRecognizer *)gesture
{
    if (gesture.state == UIGestureRecognizerStateBegan || gesture.state == UIGestureRecognizerStateChanged)
    {
        CGPoint translatedPoint = [gesture translationInView:self.view];
        if(tblTopConstrain.constant <= tblHeight)
        {
            if(tblTopConstrain.constant > 0) {
                tblTopConstrain.constant += translatedPoint.y;
            }
            else  {
                tblTopConstrain.constant = 0.1;
            }
        }
        [gesture setTranslation:CGPointZero inView:self.view];
    }
    else if(gesture.state == UIGestureRecognizerStateEnded)
    {
        if(tblTopConstrain.constant <= tblHeight/2)
        {
            tblTopConstrain.constant = 0.1;
        }
        else
        {
            tblTopConstrain.constant = tblHeight;
        }
        gesture.view.subviews[0].subviews[1].transform = CGAffineTransformIdentity;
        gesture.view.subviews[0].subviews[1].transform = tblTopConstrain.constant == 0.1 ? CGAffineTransformMakeRotation(M_PI) : CGAffineTransformIdentity;
    }
    
    tblHoliday.scrollEnabled = tblTopConstrain.constant == 0.1;
    [UIView animateWithDuration:0.1 animations:^{
        CGFloat opacity = (tblHeight - tblTopConstrain.constant)/600;
        [bgView setBackgroundColor:[[UIColor clearColor]colorWithAlphaComponent:opacity]];
        [[self view]layoutIfNeeded];
    }];
}

-(void)tapTbl:(UITapGestureRecognizer *)gesture
{
    tblTopConstrain.constant = tblTopConstrain.constant == 0.1 ? tblHeight : 0.1;
    tblHoliday.scrollEnabled = tblTopConstrain.constant == 0.1;
    [UIView animateWithDuration:0.5 animations:^{
        CGFloat opacity = (tblHeight - tblTopConstrain.constant)/800;
        gesture.view.subviews[0].subviews[1].transform = CGAffineTransformIdentity;
        gesture.view.subviews[0].subviews[1].transform = tblTopConstrain.constant == 0.1 ? CGAffineTransformMakeRotation(M_PI) : CGAffineTransformIdentity;
        [bgView setBackgroundColor:[[UIColor clearColor]colorWithAlphaComponent:opacity]];
        [[self view]layoutIfNeeded];
    }];
}

- (IBAction)onClickMonthBtn:(id)sender {
    
    yearMonth = NO;
    
    NSArray * arr = [[NSArray alloc] init];
    arr = [NSMutableArray arrayWithObjects:@"Jan", @"Feb", @"Mar", @"Apr", @"May", @"Jun", @"Jul", @"Aug", @"Sep", @"Oct",@"Nov",@"Dec",nil];
    if(dropDown == nil) {
        CGFloat f = 240;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (IBAction)onClickYearBtn:(id)sender {
    
    yearMonth = YES;
    
    NSDate *today = [NSDate date]; // get the current date
    NSCalendar* cal = [NSCalendar currentCalendar]; // get current calender
    NSDateComponents* dateOnlyToday = [cal components:( NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit ) fromDate:today];
    [dateOnlyToday setYear:([dateOnlyToday year] + 1)];
    NSDate *nextDate = [cal dateFromComponents:dateOnlyToday];
    
    [dateOnlyToday setYear:([dateOnlyToday year] - 2)];
    NSDate *preDate = [cal dateFromComponents:dateOnlyToday];
    
    NSDateFormatter *dfy = [[NSDateFormatter alloc] init];
    [dfy setDateFormat:@"yyyy"];
    
    NSString *nextYear = [dfy stringFromDate:nextDate];
    NSString *preYear = [dfy stringFromDate:preDate];
    
    NSArray * arr = [[NSArray alloc] init];
    arr = [NSMutableArray arrayWithObjects:preYear, strYear, nextYear,nil];
    if(dropDown == nil) {
        CGFloat f = 90;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender :(NSInteger)index{
    [self rel];
    
    if (yearMonth == YES) {
        NSLog(@"Year %@", btnYear.titleLabel.text);
        strFilterYear = btnYear.titleLabel.text;
    }else{
        NSLog(@"Month %@", btnMonth.titleLabel.text);
        
        NSString * dateString = [NSString stringWithFormat: @"%@", btnMonth.titleLabel.text];
        
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MMMM"];
        NSDate* myDate = [dateFormatter dateFromString:dateString];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"MM"];
        NSString *stringFromDate = [formatter stringFromDate:myDate];
        
        NSLog(@"%@", stringFromDate);
        
        strFilterMonth = stringFromDate;
    }
}

-(void)rel{
    //    [dropDown release];
    dropDown = nil;
}

- (IBAction)onClickFilterBtn:(id)sender {
    
    NSString *dateString = [NSString stringWithFormat:@"%@-%@",strFilterMonth,strFilterYear];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM-yyyy"];
    NSDate *dateFromString = [[NSDate alloc] init];
    dateFromString = [dateFormatter dateFromString:dateString];
    
    [calendarManager setDate:dateFromString];
    [self setAttendanceValueIntoCalander:strFilterMonth andYear:strFilterYear];
}

-(void)setAttendanceValueIntoCalander:(NSString*)strMonths andYear:(NSString*)strYears
{
    totalPresent = 0;
    totalAbsent = 0;
    totalLeave = 0;
    
    eventPresent = [[NSMutableDictionary alloc] init];
    eventAbsernt = [[NSMutableDictionary alloc] init];
    eventleave = [[NSMutableDictionary alloc] init];
    eventComment = [[NSMutableDictionary alloc] init];
    arrHolidayData = [[NSMutableArray alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strMonths forKey:@"Month"];
    [params setObject:strYears forKey:@"Year"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:attendence_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Responce %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrAttend = [responseObject safeObjectForKey:@"FinalArray"];
            
            NSMutableArray *arrHoliday = [responseObject safeObjectForKey:@"HolidayArray"];
            
            for (NSDictionary *dict in arrHoliday)
            {
                Holiday *objHoliday = [[Holiday alloc] init];
                
                objHoliday.strHoliday = [dict safeObjectForKey:@"HolidayName"];
                objHoliday.strDay = [[dict safeObjectForKey:@"Count"]integerValue] < 10 ? [NSString stringWithFormat:@"0%@",[dict safeObjectForKey:@"Count"]] : [dict safeObjectForKey:@"Count"];
                
                NSArray *array = [[dict safeObjectForKey:@"Date"] componentsSeparatedByString:@"-"];
                if([array[0] isEqualToString:array[1]]){
                    objHoliday.strHolidayDate = array[0];
                }else{
                    objHoliday.strHolidayDate = [NSString stringWithFormat:@"%@ - %@", array[0], array[1]];
                }
                [arrHolidayData addObject:objHoliday];
            }
            [tblHoliday reloadData];
            
            lblNoFound.hidden = YES;
            calendarMenuView.hidden = NO;
            calendarContentView.hidden = NO;
            imgLine.hidden = NO;
            tblFooterView.hidden = NO;
            
            if ([arrAttend count] > 0) {
                
                for (NSDictionary *dict in arrAttend) {
                    
                    Attendance *objAttendance = [[Attendance alloc] init];
                    
                    objAttendance.AttendanceDate = [dict safeObjectForKey:@"AttendanceDate"];
                    objAttendance.AttendenceStatus = [dict safeObjectForKey:@"AttendenceStatus"];
                    objAttendance.Comment = [dict safeObjectForKey:@"Comment"];
                    
                    NSString *strDate = [NSString stringWithFormat:@"%@",[dict safeObjectForKey:@"AttendanceDate"]];
                    
                    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
                    [dateFormat setDateFormat:@"dd/MM/yyyy"];
                    NSDate *filldate = [dateFormat dateFromString:strDate];
                    
                    [eventComment setValue:objAttendance.Comment forKey:[[objAttendance.AttendanceDate componentsSeparatedByString:@"/"]firstObject]];
                    
                    if ([objAttendance.AttendenceStatus isEqualToString:@"Present"]) {
                        totalPresent++;
                        NSString *key = [[self dateFormatter] stringFromDate:filldate];
                        if(!eventPresent[key]){
                            eventPresent[key] = [NSMutableArray new];
                        }
                        [eventPresent[key] addObject:filldate];
                    }
                    else if ([objAttendance.AttendenceStatus isEqualToString:@"Absent"]) {
                        totalAbsent++;
                        NSString *key = [[self dateFormatter] stringFromDate:filldate];
                        if(!eventAbsernt[key]){
                            eventAbsernt[key] = [NSMutableArray new];
                        }
                        [eventAbsernt[key] addObject:filldate];
                    }
                    else if ([objAttendance.AttendenceStatus isEqualToString:@"Holiday"]) {
                        totalLeave++;
                        NSString *key = [[self dateFormatter] stringFromDate:filldate];
                        if(!eventleave[key]){
                            eventleave[key] = [NSMutableArray new];
                        }
                        [eventleave[key] addObject:filldate];
                    }
                    [calendarManager reload];
                    [arrAttendance addObject:objAttendance];
                }
            }
            
            array = @[[responseObject safeObjectForKey:@"TotalPresent"], [responseObject safeObjectForKey:@"TotalAbsent"], [responseObject safeObjectForKey:@"TotalHolidayCount"]];
            
            [tblFooterView reloadData];
            
            [btnAbsent setTitle:[responseObject safeObjectForKey:@"TotalAbsent"] forState:UIControlStateNormal];
            [btnPresent setTitle:[responseObject safeObjectForKey:@"TotalPresent"] forState:UIControlStateNormal];
        }else{
            //            lblNoFound.hidden = NO;
            //            calendarMenuView.hidden = YES;
            //            calendarContentView.hidden = YES;
            //            imgLine.hidden = YES;
            tblFooterView.hidden = YES;
            [btnAbsent setTitle:@"0" forState:UIControlStateNormal];
            [btnPresent setTitle:@"0" forState:UIControlStateNormal];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (IBAction)onClickPreviousBtn:(UIButton *)sender {
    
    //    [calendarContentView loadPreviousPageWithAnimation];
    //    btnNext.userInteractionEnabled = NO;
    //    btnPrevious.userInteractionEnabled = NO;
    
    int monthNo = strMonth.intValue;
    int yearNo = strYear.intValue;
    
    if(strMonth.intValue > 1) {
        monthNo -= 1;
    }else{
        monthNo = 12;
        yearNo -= 1;
    }
    
    strMonth = [NSString stringWithFormat:@"%@%d",monthNo < 10 ? @"0" : @"",monthNo];
    strYear = [NSString stringWithFormat:@"%d",yearNo];
    
    strFilterYear = strYear;
    strFilterMonth = strMonth;
    
    [self onClickFilterBtn:nil];
}

- (IBAction)onClickNextBtn:(UIButton *)sender {
    
    int monthNo = strMonth.intValue;
    int yearNo = strYear.intValue;
    
    if(strMonth.intValue < 12) {
        monthNo += 1;
    }else{
        monthNo = 1;
        yearNo += 1;
    }
    
    strMonth = [NSString stringWithFormat:@"%@%d",monthNo < 10 ? @"0" : @"",monthNo];
    strYear = [NSString stringWithFormat:@"%d",yearNo];
    
    strFilterYear = strYear;
    strFilterMonth = strMonth;
    
    [self onClickFilterBtn:nil];
    //    [calendarContentView loadNextPageWithAnimation];
    //    btnNext.userInteractionEnabled = NO;
    //    btnPrevious.userInteractionEnabled = NO;
}

#pragma mark - CalendarManager delegate

- (void)calendar:(JTCalendarManager *)calendar prepareDayView:(JTCalendarDayView *)dayView
{
    dayView.hidden = NO;
    
    // Other month
    if([dayView isFromAnotherMonth]){
        dayView.hidden = YES;
    }
    // Today
    else if([calendarManager.dateHelper date:[NSDate date] isTheSameDayThan:dayView.date]){
        dayView.circleView.hidden = NO;
        dayView.circleView.layer.borderWidth =1.0f;
        dayView.circleView.layer.borderColor = absentColor.CGColor;
        dayView.textLabel.textColor = [UIColor blackColor];
    }
    else{
        dayView.circleView.hidden = YES;
        //        dayView.dotView.backgroundColor = [UIColor redColor];
        dayView.textLabel.textColor = [UIColor blackColor];
    }
    
    NSDate *date = dayView.date;
    NSString *key = [[self dateFormatter] stringFromDate:date];
    
    NSMutableArray  *eventLeave = [eventleave objectForKey:key];
    
    if(eventLeave != nil){
        NSDate *dt =[eventLeave objectAtIndex:0];
        //        NSLog(@"DATE %@  CUR DATE %@", dt , dayView.date);
        
        if([self isSameDay:dt otherDay:dayView.date]){
            
            //            NSLog(@"DATE IS SAME " );
            dayView.circleView.hidden = NO;
            dayView.circleView.backgroundColor = sectionSelectColor;
            dayView.dotView.backgroundColor = [UIColor whiteColor];
            dayView.textLabel.textColor = [UIColor blackColor];
        }
    }
    
    NSMutableArray  *eventAbs = [eventAbsernt objectForKey:key];
    
    if(eventAbs != nil){
        NSDate *dt =[eventAbs objectAtIndex:0];
        //        NSLog(@"DATE %@  CUR DATE %@", dt , dayView.date);
        
        if([self isSameDay:dt otherDay:dayView.date]){
            
            //            NSLog(@"DATE IS SAME " );
            dayView.circleView.hidden = NO;
            dayView.circleView.backgroundColor = absentColor;
            dayView.dotView.backgroundColor = [UIColor whiteColor];
            dayView.textLabel.textColor = [UIColor blackColor];
        }
    }
    
    NSMutableArray  *eventPre = [eventPresent objectForKey:key];
    
    if(eventPre != nil){
        NSDate *dt =[eventPre objectAtIndex:0];
        //        NSLog(@"DATE %@  CUR DATE %@", dt , dayView.date);
        
        if([self isSameDay:dt otherDay:dayView.date]){
            
            //            NSLog(@"DATE IS SAME " );
            dayView.circleView.hidden = NO;
            dayView.circleView.backgroundColor = presentColor;
            dayView.dotView.backgroundColor = [UIColor whiteColor];
            dayView.textLabel.textColor = [UIColor blackColor];
        }
    }
    
    
    //    NSDateFormatter* theDateFormatter = [[NSDateFormatter alloc] init];
    //    [theDateFormatter setFormatterBehavior:NSDateFormatterBehavior10_4];
    //    [theDateFormatter setDateFormat:@"EEEE"];
    //    NSString *weekDay =  [theDateFormatter stringFromDate:dayView.date];
    
    //    if ([weekDay isEqualToString:@"Sunday"]) {
    //
    //        dayView.circleView.hidden = NO;
    //        dayView.circleView.backgroundColor = [UIColor clearColor];
    //        dayView.dotView.backgroundColor = [UIColor clearColor];
    //        dayView.textLabel.textColor = [UIColor blackColor];
    //    }
}

- (BOOL)isSameDay:(NSDate*)date1 otherDay:(NSDate*)date2 {
    
    NSCalendar* calendar = [NSCalendar currentCalendar];
    
    unsigned unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit;
    NSDateComponents* comp1 = [calendar components:unitFlags fromDate:date1];
    NSDateComponents* comp2 = [calendar components:unitFlags fromDate:date2];
    
    return [comp1 day]   == [comp2 day] &&
    [comp1 month] == [comp2 month] &&
    [comp1 year]  == [comp2 year];
    
}

- (void)calendar:(JTCalendarManager *)calendar didTouchDayView:(JTCalendarDayView *)dayView
{
    dateSelected = dayView.date;
    
    if (!dayView.circleView.isHidden) {
        [[[UIAlertView alloc]initWithTitle:@"Comment" message:eventComment[dayView.textLabel.text] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
    }
    
    // Animation for the circleView
    //    dayView.circleView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.1, 0.1);
    //    [UIView transitionWithView:dayView
    //                      duration:.3
    //                       options:0
    //                    animations:^{
    //                        dayView.circleView.transform = CGAffineTransformIdentity;
    //                        [calendarManager reload];
    //                    } completion:nil];
    
    
    // Load the previous or next page if touch a day from another month
    
    if(![calendarManager.dateHelper date:calendarContentView.date isTheSameMonthThan:dayView.date]){
        if([calendarContentView.date compare:dayView.date] == NSOrderedAscending){
            [calendarContentView loadNextPageWithAnimation];
        }
        else{
            [calendarContentView loadPreviousPageWithAnimation];
        }
    }
}

#pragma mark - CalendarManager delegate - Page mangement
- (BOOL)calendar:(JTCalendarManager *)calendar canDisplayPageWithDate:(NSDate *)date
{
    return [calendarManager.dateHelper date:date isEqualOrAfter:minDate andEqualOrBefore:maxDate];
}

- (void)createMinAndMaxDate
{
    todayDate = [NSDate date];
    // Min date will be 2 month before today
    minDate = [calendarManager.dateHelper addToDate:todayDate months:0];
    // Max date will be 2 month after today
    maxDate = [calendarManager.dateHelper addToDate:todayDate months:0];
}
- (NSDateFormatter *)dateFormatter
{
    static NSDateFormatter *dateFormatter;
    if(!dateFormatter){
        dateFormatter = [NSDateFormatter new];
        dateFormatter.dateFormat = @"dd-MM-yyyy";
    }
    
    return dateFormatter;
}

- (BOOL)haveEventForDay:(NSDate *)date
{
    NSString *key = [[self dateFormatter] stringFromDate:date];
    
    if(eventsByDate[key] && [eventsByDate[key] count] > 0){
        return YES;
    }
    return NO;
}

#pragma mark - TableView DataSource & Delegate

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return tableView == tblHoliday && arrHolidayData.count > 0 ? 60 : 0;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    AttendanceCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EventHeaderCell"];
    
    [cell.contentView setBackgroundColor:[UIColor whiteColor]];
    [cell.contentView.subviews[0].layer setShadowColor:[[UIColor clearColor]colorWithAlphaComponent:0.8].CGColor];
    [cell.contentView.subviews[0].layer setShadowOpacity:0.8f];
    [cell.contentView.subviews[0].layer setShadowRadius:5.0f];
    [cell.contentView.subviews[0].layer setShadowOffset:CGSizeMake(0.0f, 3.0f)];
    [((UIButton *)cell.contentView.subviews[0].subviews[1]) setImage:[[UIImage imageNamed:@"Down"]imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:0];
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(moveTbl:)];
    [cell.contentView addGestureRecognizer:panGesture];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapTbl:)];
    [cell.contentView addGestureRecognizer:tapGesture];
    
    //((UILabel *)cell.contentView.subviews[0].subviews[0]).text = [NSString stringWithFormat:@"%lu Holiday Found",(unsigned long)arrHolidayData.count];
    return tableView == tblHoliday && arrHolidayData.count > 0 ? cell.contentView : nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == tblHoliday){
        return UITableViewAutomaticDimension;
    }else{
        return 30;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView == tblHoliday){
        return arrHolidayData.count;
    }else{
        return array.count > 0 ? 2 : 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strIdentifier;
    if(indexPath.row == 0) {
        strIdentifier = tableView == tblHoliday ? @"EventCell" : @"AttendanceHeaderCell";
    }else{
        strIdentifier = tableView == tblHoliday ? @"EventCell" : @"AttendanceCell";
    }
    
    AttendanceCell *cell = [tableView dequeueReusableCellWithIdentifier:strIdentifier forIndexPath:indexPath];
    if(indexPath.row == 1 && tableView != tblHoliday){
        int i = 0;
        for (UIView *view in cell.contentView.subviews) {
            if([view isKindOfClass:[UILabel classForCoder]]){
                if(view.tag != -1) {
                    UILabel *lbl = (UILabel *)view;
                    lbl.text = array[i];
                    
                    i += 1;
                }
            }
        }
    }else if(tableView == tblHoliday){
        [cell.contentView.subviews[0].layer setShadowColor:[[UIColor clearColor]colorWithAlphaComponent:0.2].CGColor];
        [cell.contentView.subviews[0].layer setShadowOpacity:0.2f];
        [cell.contentView.subviews[0].layer setShadowRadius:2.0f];
        [cell.contentView.subviews[0].layer setShadowOffset:CGSizeMake(0.0f, 2.0f)];
        [cell.contentView.subviews[0].layer setBorderColor:[sectionSelectColor CGColor]];
        [cell.contentView.subviews[0].layer setBorderWidth:0.5];
        
        Holiday *holiday = (Holiday *)arrHolidayData[indexPath.row];
        int i = 0;
        NSArray *array = @[holiday.strHoliday, holiday.strHolidayDate, holiday.strDay, @"Days"];
        for (UIView *view in cell.contentView.subviews[0].subviews) {
            if([view isKindOfClass:[UILabel classForCoder]]){
                UILabel *lbl = (UILabel *)view;
                lbl.text = array[i];
                
                i += 1;
            }
        }
    }
    return cell;
}

#pragma mark - Views customization

- (UIView *)calendarBuildMenuItemView:(JTCalendarManager *)calendar
{
    UILabel *label = [UILabel new];
    
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:IS_IPAD ? 20 : 18];
    label.textColor = buttonBoardColor;
    return label;
}

- (void)calendar:(JTCalendarManager *)calendar prepareMenuItemView:(UILabel *)menuItemView date:(NSDate *)date
{
    static NSDateFormatter *dateFormatter;
    if(!dateFormatter){
        dateFormatter = [NSDateFormatter new];
        dateFormatter.dateFormat = @"MMMM yyyy";
        
        dateFormatter.locale = calendarManager.dateHelper.calendar.locale;
        dateFormatter.timeZone = calendarManager.dateHelper.calendar.timeZone;
    }
    
    menuItemView.text = [dateFormatter stringFromDate:date];
    //    NSLog(@"menuItemView %@",menuItemView.text);
}

- (UIView<JTCalendarWeekDay> *)calendarBuildWeekDayView:(JTCalendarManager *)calendar
{
    JTCalendarWeekDayView *view = [JTCalendarWeekDayView new];
    
    for(UILabel *label in view.dayViews){
        label.textColor = buttonBoardColor;//[UIColor redColor];
        label.font = [UIFont fontWithName:@"Avenir-Light" size:IS_IPAD ? 16 : 14];
    }
    
    return view;
}

- (UIView<JTCalendarDay> *)calendarBuildDayView:(JTCalendarManager *)calendar
{
    JTCalendarDayView *view = [JTCalendarDayView new];
    
    view.textLabel.font = [UIFont fontWithName:@"Avenir-Light" size:IS_IPAD ? 16 : 13];
    view.textLabel.textColor = [UIColor yellowColor];
    view.circleRatio = .8;
    view.dotRatio = 1. / .9;
    
    return view;
}

- (void)createRandomEvents
{
    //Attendance *objAttendance = [[Attendance alloc] init];
    //NSLog(@"objAttendance.attended>>> %@",[arrAttendance valueForKey:objAttendance.attended]);
    
    eventsByDate = [NSMutableDictionary new];
    
    for(int i = 0; i < 5; ++i){
        // Generate 30 random dates between now and 60 days later
        NSDate *randomDate = [NSDate dateWithTimeInterval:(rand() % (3600 * 24 * 60)) sinceDate:[NSDate date]];
        
        // Use the date as key for eventsByDate
        NSString *key = [[self dateFormatter] stringFromDate:randomDate];
        
        if(!eventsByDate[key]){
            eventsByDate[key] = [NSMutableArray new];
        }
        
        [eventsByDate[key] addObject:randomDate];
        
        //        NSString *dateString = _eventsByDate[key];
        //        NSArray *components = [dateString componentsSeparatedByString:@" "];
        
        //   NSLog(@"dateString>>> %@",dateString);
        //    NSLog(@"key>>>> %@",key);
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
