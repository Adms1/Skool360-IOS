//
//  AttendanceView.h
//  Skool360
//
//  Created by Darshan on 24/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "AFNetworking.h"
#import "Attendance.h"
#import "NIDropDown.h"
#import "JTCalendar.h"

@interface AttendanceView : MasterViewController  <JTCalendarDelegate,NIDropDownDelegate>

{
    IBOutlet UITableView *tblFooterView;
    IBOutlet UITableView *tblHoliday;

    IBOutlet UIButton *btnMonth;
    IBOutlet UIButton *btnYear;
    IBOutlet UIButton *btnFilter;
    IBOutlet UIButton *btnPresent;
    IBOutlet UIButton *btnAbsent;
    IBOutlet UIButton *btnNext;
    IBOutlet UIButton *btnPrevious;
    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    
    IBOutlet UILabel *lblNoFound;
    
    IBOutlet UIView *viewtitle;
    
    IBOutlet UIImageView *imgLogo;
    IBOutlet UIImageView *imgLine;
    
    IBOutlet JTCalendarMenuView *calendarMenuView;
    IBOutlet JTHorizontalCalendarView *calendarContentView;
    JTCalendarManager *calendarManager;
    
    NSMutableDictionary *eventsByDate;
    NSMutableDictionary *eventPresent;
    NSMutableDictionary *eventAbsernt;
    NSMutableDictionary *eventleave;
    NSMutableDictionary *eventComment;

    NSDate *todayDate;
    NSDate *minDate;
    NSDate *maxDate;
    NSDate *dateSelected;
    
    NSInteger totalPresent;
    NSInteger totalAbsent;
    NSInteger totalLeave;
    
    NSMutableArray *arrAttendance;
    
    NIDropDown *dropDown;
    BOOL yearMonth;
    BOOL month;
    
    NSString *strYear;
    NSString *strMonth;
    NSString *strFilterMonth;
    NSString *strFilterYear;
    
    IBOutlet NSLayoutConstraint *tblTopConstrain;
    IBOutlet UIView *bgView;
}

@end
