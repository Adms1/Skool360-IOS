//
//  ErrorPopupVC.m
//  Skool360
//
//  Created by ADMS on 21/08/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "ErrorPopupVC.h"

@interface ErrorPopupVC ()

@end

@implementation ErrorPopupVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [((UILabel *)self.view.subviews[2].subviews[1])setText:serverError];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
