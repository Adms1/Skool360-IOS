//
//  ClassWorkViewController.m
//  Skool360
//
//  Created by Darshan on 01/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "ClassWorkViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface ClassWorkViewController ()
{
    NSMutableArray *arrTag;
    NSMutableDictionary *dicTag;
}
@end

@implementation ClassWorkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (isiPhone6) {
        imgLogo.frame = CGRectMake(-66, 0, 140, 45);
    }else if (isiPhone6Plus){
        imgLogo.frame = CGRectMake(-86, 0, 140, 45);
    }
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.titleView = viewtitle;
    
    [btnSideMenu setAttributedTitle:nil forState:UIControlStateNormal];
    [[btnSideMenu titleLabel] setNumberOfLines:0];
    [[btnSideMenu titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    
    //    UIBarButtonItem *barBtnSide = [[UIBarButtonItem alloc] initWithCustomView:btnSideMenu];
    //    self.navigationItem.rightBarButtonItems = @[barBtnSide];
    //
    //    UIBarButtonItem *barBtnBack = [[UIBarButtonItem alloc] initWithCustomView:btnBack];
    //    self.navigationItem.leftBarButtonItems = @[barBtnBack];
    
    btnFromDate.layer.cornerRadius = 4.0f;
    btnFromDate.layer.borderWidth = 0.5f;
    btnFromDate.layer.borderColor = imgCircleColor.CGColor;
    
    btnToDate.layer.cornerRadius = 4.0f;
    btnToDate.layer.borderWidth = 0.5f;
    btnToDate.layer.borderColor = imgCircleColor.CGColor;
    
    btnFilter.layer.cornerRadius = 4.0f;
    
    arrClassWorkList = [[NSMutableArray alloc] init];
    
    btnSelected = YES;
    
    /*CAShapeLayer * maskLayer = [CAShapeLayer layer];
     maskLayer.path = [UIBezierPath bezierPathWithRoundedRect: viewToolBar.frame byRoundingCorners: UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii: (CGSize){4.0, 4.0}].CGPath;
     viewToolBar.layer.mask = maskLayer;*/
    
    viewDatePicker.layer.borderWidth = 1.0f;
    viewDatePicker.layer.borderColor = datePickerBoardColor.CGColor;
    viewDatePicker.layer.cornerRadius = 4.0f;
    
    selectedSection = -1;
    
    btnDone.layer.cornerRadius = 2.0f;
    btnCancel.layer.cornerRadius = 2.0f;
    
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strCurrentDate = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:[NSDate date]]];
    
    if(isFromPush) {
        strCurrentDate = pushData[@"Date"];
    }
    
    [btnToDate setTitle:strCurrentDate forState:UIControlStateNormal];
    [btnFromDate setTitle:strCurrentDate forState:UIControlStateNormal];
    
    strClassToDate = strCurrentDate;
    strClassFromDate = strCurrentDate;
    
    [self getClassWorkToDate:strCurrentDate andFromDate:strCurrentDate];
    
    //tblClassWork.estimatedRowHeight = 50.0;
    //tblClassWork.rowHeight = UITableViewAutomaticDimension;
    tblClassWork.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
}

#pragma mark -
#pragma mark - CLASSWORK SERVICE CALL METHOD

-(void)getClassWorkToDate:(NSString *)strDateTo andFromDate:(NSString *)strDateFrom
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    imgNoRecord.hidden = YES;
    
    arrClassWorkList = [[NSMutableArray alloc] init];
    selectedSection = -1;
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strDateTo forKey:@"ClassWorkFromDate"];
    [params setObject:strDateFrom forKey:@"ClassWorkToDate"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:classwork_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            tblClassWork.hidden = NO;
            NSMutableArray *arrListClassWork = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dictValue in arrListClassWork) {
                
                HCWork *objHC = [[HCWork alloc] init];
                objHC.ClassWorkDate = [dictValue safeObjectForKey:@"ClassWorkDate"];
                
                NSMutableArray *arrCWData = [[NSMutableArray alloc]init];
                for(NSDictionary *dict in [dictValue safeObjectForKey:@"Data"])
                {
                    HCWork *objHCD = [[HCWork alloc] init];
                    objHCD.Subject = [dict safeObjectForKey:@"Subject"];
                    objHCD.ClassWork = [CommonClass getHtmlString:[dict safeObjectForKey:@"Classwork"]];
                    [arrCWData addObject:objHCD];
                }
                [arrClassWorkList addObject:@[objHC.ClassWorkDate,arrCWData]];
                [tblClassWork reloadData];
            }
        }else{
            tblClassWork.hidden = YES;
            imgNoRecord.hidden = NO;
        }
        [SHARED_APPDELEGATE hideLoadingView];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -
#pragma mark - TableView Delegate Method

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == selectedSection){
        return UITableViewAutomaticDimension;
    }else{
        return 0;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGRect rect = CGRectMake(0, 0, SHARED_APPDELEGATE.window.frame.size.width,50);
    SectionView *viewFit = [[SectionView alloc] initWithFrame:rect :@"SectionView"];
    viewFit.dateDelegate = self;
    viewFit.index = (int)section;
    
    if(section == selectedSection){
        [viewFit setSelectedColor:imgCircleColor];
    }else{
        [viewFit setNormalColor];
    }
    
    [viewFit setSectionData:[[arrClassWorkList objectAtIndex:section] objectAtIndex:0]];
    
    return viewFit;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [arrClassWorkList count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSArray *arrData = [[arrClassWorkList objectAtIndex:section] objectAtIndex:1];
    return  section == selectedSection ? [arrData count] : 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeWorkCell *cell = (HomeWorkCell *)[tblClassWork dequeueReusableCellWithIdentifier:@"classWork" forIndexPath:indexPath];
    //    if (cell == nil)
    //    {
    //        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeWorkCell" owner:self options:nil];
    //        cell = [nib objectAtIndex:0];
    //    }
    
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    NSArray *arrsecton = [[arrClassWorkList objectAtIndex:indexPath.section] objectAtIndex:1];
    HCWork *hcData = [arrsecton objectAtIndex:indexPath.row];
    [cell setClassWorkData:hcData];
    
    return  cell;
}

-(void)setDateAtindex:(int)index
{
    NSLog(@"Section Select: %d",index);
    
    if(index == selectedSection){
        selectedSection = -1;
    }else{
        selectedSection = index;
    }
    
    [tblClassWork reloadData];
    
    if (selectedSection != -1 && [tblClassWork numberOfRowsInSection:selectedSection] > 0) {
        [tblClassWork scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:[tblClassWork numberOfRowsInSection:selectedSection]-1 inSection:selectedSection] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}

#pragma mark -
#pragma mark - BUTTONCLICK Method


- (IBAction)onClickToDateBtn:(id)sender {
    
    btnSelected = YES;
    
    //    btnToDate.layer.borderColor = datePickerBoardColor.CGColor;
    //    btnFromDate.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    pickerClassWorkDate = [[UIDatePicker alloc] init];
    [pickerClassWorkDate setDatePickerMode:UIDatePickerModeDate];
    [pickerClassWorkDate addTarget:self action:@selector(onClickPickDate:) forControlEvents:UIControlEventValueChanged];
    
    viewDatePicker.frame = CGRectMake(viewDatePicker.frame.origin.x, (SHARED_APPDELEGATE.window.frame.size.height - 200)/2, SHARED_APPDELEGATE.window.frame.size.width - 20, 230);
    viewDatePicker.hidden = NO;
}

- (IBAction)onClickFromDateBtn:(id)sender {
    
    btnSelected = NO;
    
    //    btnFromDate.layer.borderColor = datePickerBoardColor.CGColor;
    //    btnToDate.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    pickerClassWorkDate = [[UIDatePicker alloc] init];
    [pickerClassWorkDate setDatePickerMode:UIDatePickerModeDate];
    [pickerClassWorkDate addTarget:self action:@selector(onClickPickDate:) forControlEvents:UIControlEventValueChanged];
    
    viewDatePicker.frame = CGRectMake(viewDatePicker.frame.origin.x, (SHARED_APPDELEGATE.window.frame.size.height - 200)/2, SHARED_APPDELEGATE.window.frame.size.width - 20, 230);
    viewDatePicker.hidden = NO;
}

- (IBAction)onClickDoneBtn:(id)sender {
    
    viewDatePicker.hidden = YES;
}

- (IBAction)onClickCancelBtn:(id)sender {
    
    if (btnSelected == YES) {
        [btnToDate setTitle:strClassToDate forState:UIControlStateNormal];
    }else{
        [btnFromDate setTitle:strClassFromDate forState:UIControlStateNormal];
    }
    
    viewDatePicker.hidden = YES;
}

- (IBAction)onClickFilterBtn:(id)sender {
    
    //    btnToDate.layer.borderColor = [UIColor lightGrayColor].CGColor;
    //    btnFromDate.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    [self getClassWorkToDate:strClassToDate andFromDate:strClassFromDate];
}

#pragma mark -
#pragma mark - DATEPICKER Method

- (IBAction)onClickPickDate:(UIDatePicker *)datePicker {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strDate = [dateFormatter stringFromDate:datePicker.date];
    [datePicker setMaximumDate:[NSDate date]];
    
    NSLog(@"%@",strDate);
    
    if (btnSelected == YES) {
        if(strClassFromDate != nil){
            [datePicker setMaximumDate:[dateFormatter dateFromString:strClassFromDate]];
        }
        strClassToDate = strDate;
        [btnToDate setTitle:strDate forState:UIControlStateNormal];
    }else{
        if(strClassToDate != nil){
            [datePicker setMinimumDate:[dateFormatter dateFromString:strClassToDate]];
        }
        strClassFromDate = strDate;
        [btnFromDate setTitle:strDate forState:UIControlStateNormal];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
