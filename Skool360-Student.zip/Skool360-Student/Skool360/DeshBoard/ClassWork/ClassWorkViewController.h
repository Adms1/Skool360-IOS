//
//  ClassWorkViewController.h
//  Skool360
//
//  Created by Darshan on 01/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "HomeWorkCell.h"
#import "SectionView.h"
#import "HCWork.h"

@interface ClassWorkViewController : MasterViewController <HomeWorkDateDelegate,UITableViewDelegate,UITableViewDataSource>

{
    IBOutlet UITableView *tblClassWork;
    
    IBOutlet UIView *viewtitle;
    IBOutlet UIView *viewDatePicker;
    IBOutlet UIView *viewToolBar;
    
    IBOutlet UIImageView *imgLogo;
    
    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    IBOutlet UIButton *btnFromDate;
    IBOutlet UIButton *btnToDate;
    IBOutlet UIButton *btnFilter;
    IBOutlet UIButton *btnDone;
    IBOutlet UIButton *btnCancel;
    
    IBOutlet UILabel *lblNoFound;
    IBOutlet UIImageView *imgNoRecord;

    IBOutlet UIDatePicker *pickerClassWorkDate;
    
    BOOL btnSelected;
    
    NSMutableArray *arrClassWorkList;
    
    int selectedSection;
    
    NSString *strClassToDate;
    NSString *strClassFromDate;
}

@end
