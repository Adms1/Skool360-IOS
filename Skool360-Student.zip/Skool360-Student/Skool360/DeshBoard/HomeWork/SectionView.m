//
//  SectionView.m
//  Skool360
//
//  Created by Darshan on 31/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "SectionView.h"
#import "AppDelegate.h"

@implementation SectionView

//UIView
@synthesize viewBack;

//UILabel
@synthesize lblDate;

//Integer
@synthesize index;

//Delegate
@synthesize dateDelegate;

AppDelegate *appDelegateDate;

-(id) initWithFrame:(CGRect)frame :(NSString *)nibName
{
    if(self == [super initWithFrame:frame])
    {
        appDelegateDate = (AppDelegate *)[UIApplication sharedApplication].delegate;
        self = (SectionView *)[SectionView loadInstanceFromNib:self :nibName];
        
        UITapGestureRecognizer *singleFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dateSingleTap:)];
        [viewBack addGestureRecognizer:singleFingerTap];
    }
    return self;
}

-(void)setSelectedColor:(UIColor *)color
{
    imgTop.backgroundColor = sectionSelectColor;
    imgBottom.backgroundColor = sectionSelectColor;
}

-(void)setNormalColor
{
    imgTop.backgroundColor = [UIColor grayColor];
    imgBottom.backgroundColor = [UIColor grayColor];
}

-(void)setSectionData:(NSString *)title
{
    lblDate.text = title;
}

-(void)setSectionPaymentData:(NSDictionary *)dic
{
    lblDate.text = dic[@"PayDate"];
    _lblFees.text = [NSString stringWithFormat:@"₹ %@",dic[@"Paid"]];
}

- (void)dateSingleTap:(UITapGestureRecognizer *)recognizer {
    
    if (dateDelegate && [dateDelegate respondsToSelector:@selector(setDateAtindex:)]) {
        [dateDelegate setDateAtindex:index];
    }
}

@end
