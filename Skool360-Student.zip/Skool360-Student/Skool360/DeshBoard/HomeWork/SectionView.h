//
//  SectionView.h
//  Skool360
//
//  Created by Darshan on 31/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+NibLoading.h"
#import "HCWork.h"

@protocol HomeWorkDateDelegate <NSObject>

-(void)setDateAtindex:(int)index;

@end

@interface SectionView : UIView

{
    IBOutlet UIImageView *imgTop;
    IBOutlet UIImageView *imgBottom;
}

//Delegate
@property (strong , nonatomic) id<HomeWorkDateDelegate> dateDelegate;

@property (nonatomic , strong) IBOutlet UIView *viewBack;
@property (nonatomic , strong) IBOutlet UILabel *lblDate;
@property (nonatomic , strong) IBOutlet UILabel *lblFees;
@property (nonatomic , strong) IBOutlet UIButton *btnDetails;
@property (nonatomic , strong) IBOutlet UILabel *lblTitle;
@property (nonatomic , strong) IBOutlet NSLayoutConstraint *topConstant;

-(void)setSectionData:(NSString *)title;
-(void)setSectionPaymentData:(NSDictionary *)dic;
-(void)setSelectedColor:(UIColor *)color;
-(void)setNormalColor;
-(id) initWithFrame:(CGRect)frame :(NSString *)nibName;

//Integer
@property (nonatomic)int index;

@end
