//
//  HomeWorkViewController.m
//  Skool360
//
//  Created by Darshan on 31/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "HomeWorkViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "HCWork.h"

@interface HomeWorkViewController ()
{
    NSMutableArray *arrTag;
    NSMutableDictionary *dicTag;
}
@end

@implementation HomeWorkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (isiPhone6) {
        imgLogo.frame = CGRectMake(-66, 0, 140, 45);
    }else if (isiPhone6Plus){
        imgLogo.frame = CGRectMake(-86, 0, 140, 45);
    }
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.titleView = viewtitle;
    
    [btnSideMenu setAttributedTitle:nil forState:UIControlStateNormal];
    [[btnSideMenu titleLabel] setNumberOfLines:0];
    [[btnSideMenu titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    
    //    UIBarButtonItem *barBtnSide = [[UIBarButtonItem alloc] initWithCustomView:btnSideMenu];
    //    self.navigationItem.rightBarButtonItems = @[barBtnSide];
    //
    //    UIBarButtonItem *barBtnBack = [[UIBarButtonItem alloc] initWithCustomView:btnBack];
    //    self.navigationItem.leftBarButtonItems = @[barBtnBack];
    
    btnFromDate.layer.cornerRadius = 4.0f;
    btnFromDate.layer.borderWidth = 0.5f;
    btnFromDate.layer.borderColor = imgCircleColor.CGColor;
    
    btnToDate.layer.cornerRadius = 4.0f;
    btnToDate.layer.borderWidth = 0.5f;
    btnToDate.layer.borderColor = imgCircleColor.CGColor;
    
    btnFilter.layer.cornerRadius = 4.0f;
    
    arrHomeWorkList = [[NSMutableArray alloc] init];
    
    btnSelected = YES;
    
    viewDatePicker.layer.borderWidth = 1.0f;
    viewDatePicker.layer.borderColor = datePickerBoardColor.CGColor;
    viewDatePicker.layer.cornerRadius = 4.0f;
    
    selectedSection = -1;
    
    btnDone.layer.cornerRadius = 2.0f;
    btnCancel.layer.cornerRadius = 2.0f;
    
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strCurrentDate = [NSString stringWithFormat:@"%@",[dateFormatter stringFromDate:[NSDate date]]];
    
    if(isFromPush) {
        strCurrentDate = pushData[@"Date"];
    }
    
    [btnToDate setTitle:strCurrentDate forState:UIControlStateNormal];
    [btnFromDate setTitle:strCurrentDate forState:UIControlStateNormal];
    
    strCancelToDate = strCurrentDate;
    strCancelFromDate = strCurrentDate;
    
    [self getHomeWorkToDate:strCurrentDate andFromDate:strCurrentDate];
    tblHomeWork.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    
    tblHomeWork.estimatedRowHeight = [BunbleName containsString:@"Shilaj"] ? 50.0 : 70.0;
    tblHomeWork.rowHeight = UITableViewAutomaticDimension;
    tblHomeWork.allowsSelection = YES;
}

-(void)getHomeWorkToDate:(NSString *)strDateTo andFromDate:(NSString *)strDateFrom
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    imgNoRecord.hidden = YES;
    
    arrHomeWorkList = [[NSMutableArray alloc] init];
    dicTag = [[NSMutableDictionary alloc] init];
    selectedSection = -1;
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strDateTo forKey:@"HomeWorkFromDate"];
    [params setObject:strDateFrom forKey:@"HomeWorkToDate"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:homework_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            tblHomeWork.hidden = NO;
            NSMutableArray *arrListHomeWork = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dictValue in arrListHomeWork) {
                
                HCWork *objHC = [[HCWork alloc] init];
                objHC.HomeWorkDate = [dictValue safeObjectForKey:@"HomeWorkDate"];
                
                NSMutableArray *arrHWData = [[NSMutableArray alloc]init];
                for(NSDictionary *dict in [dictValue safeObjectForKey:@"Data"])
                {
                    HCWork *objHCD = [[HCWork alloc] init];
                    objHCD.Subject = [dict safeObjectForKey:@"Subject"];
                    objHCD.Status = [dict safeObjectForKey:@"HomeWorkStatus"];
                    objHCD.HomeWork = [CommonClass getHtmlString:[dict safeObjectForKey:@"HomeWork"]];
                    objHCD.ChapterName = [CommonClass getHtmlString:[dict safeObjectForKey:@"ChapterName"]];
                    objHCD.Objective = [CommonClass getHtmlString:[dict safeObjectForKey:@"Objective"]];
                    objHCD.AssessmentQue = [CommonClass getHtmlString:[dict safeObjectForKey:@"AssessmentQue"]];
                    [arrHWData addObject:objHCD];
                }
                [arrHomeWorkList addObject:@[objHC.HomeWorkDate,arrHWData]];
            }
            [tblHomeWork reloadData];
        }else{
            tblHomeWork.hidden = YES;
            imgNoRecord.hidden = NO;
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -
#pragma mark - TableView Delegate Method

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == selectedSection){
        return UITableViewAutomaticDimension;
    }
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGRect rect = CGRectMake(0, 0, SHARED_APPDELEGATE.window.frame.size.width,50);
    SectionView *viewFit = [[SectionView alloc] initWithFrame:rect :@"SectionView"];
    viewFit.dateDelegate = self;
    viewFit.index = (int)section;
    
    if(section == selectedSection){
        [viewFit setSelectedColor:imgCircleColor];
    }else{
        [viewFit setNormalColor];
    }
    
    [viewFit setSectionData:[[arrHomeWorkList objectAtIndex:section] objectAtIndex:0]];
    
    return viewFit;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [arrHomeWorkList count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSArray *arrData = [[arrHomeWorkList objectAtIndex:section] objectAtIndex:1];
    if (section != selectedSection) {
        if (dicTag != nil) {
            [dicTag removeObjectForKey:[NSString stringWithFormat:@"%ld",(long)section]];
        }
    }
    return  section == selectedSection ? [arrData count] : 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeWorkCell *cell = (HomeWorkCell *)[tblHomeWork dequeueReusableCellWithIdentifier: [BunbleName containsString:@"Shilaj"] ? @"SHomeWork" : @"BHomeWork" forIndexPath:indexPath];
    //    if (cell == nil)
    //    {
    //        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"HomeWorkCell" owner:self options:nil];
    //        cell = [nib objectAtIndex:0];
    //    }
    
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    NSArray *arrsecton = [[arrHomeWorkList objectAtIndex:indexPath.section] objectAtIndex:1];
    HCWork *hcData = [arrsecton objectAtIndex:indexPath.row];
    [cell setHomeWorkData:hcData];
    
    if ([BunbleName containsString:@"Shilaj"])
    {
        [cell.btnViewMore setTransform:CGAffineTransformIdentity];
        if (dicTag != nil)
        {
            if([[dicTag allKeys]containsObject:[NSString stringWithFormat:@"%ld",(long)indexPath.section]])
            {
                NSString *dicValue = [dicTag valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
                NSInteger section  = [[[dicValue componentsSeparatedByString:@"-"]firstObject] integerValue];
                NSInteger row  = [[[dicValue componentsSeparatedByString:@"-"]lastObject] integerValue];
                
                if (indexPath.section == section && indexPath.row == row)
                {
                    [cell setHomeWorkOtherData:hcData];
                    [UIView animateWithDuration:0.3f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                        [cell.btnViewMore setTransform:CGAffineTransformRotate(cell.btnViewMore.transform, M_PI/2)];
                    } completion:nil];
                }
            }
        }
    }
    return  cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomeWorkCell *cell = [tblHomeWork cellForRowAtIndexPath:indexPath];
    NSArray *arrsecton = [[arrHomeWorkList objectAtIndex:indexPath.section] objectAtIndex:1];
    HCWork *hcData = [arrsecton objectAtIndex:indexPath.row];
    
    [cell setHomeWorkOtherData:hcData];
    [dicTag setObject:[NSString stringWithFormat:@"%d-%ld",indexPath.section,(long)indexPath.row] forKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
    
    [tblHomeWork reloadData];
    [tblHomeWork selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionNone];
    //[tblHomeWork scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionNone animated:YES];
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomeWorkCell *cell = [tblHomeWork cellForRowAtIndexPath:indexPath];
    NSArray *arrsecton = [[arrHomeWorkList objectAtIndex:indexPath.section] objectAtIndex:1];
    HCWork *hcData = [arrsecton objectAtIndex:indexPath.row];
    
    [cell setHomeWorkData:hcData];
    [dicTag removeObjectForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.section]];
    
    [tblHomeWork reloadData];
    
    //    if (selectedSection != -1 && [tblHomeWork numberOfRowsInSection:selectedSection] > 0) {
    //        [tblHomeWork scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionNone animated:YES];
    //    }
}

-(void)setDateAtindex:(int)index
{
    NSLog(@"Section Select: %d",index);
    
    if(index == selectedSection){
        selectedSection = -1;
    }else{
        selectedSection = index;
    }
    
    [tblHomeWork reloadData];
    
    if (selectedSection != -1 && [tblHomeWork numberOfRowsInSection:selectedSection] > 0) {
        [tblHomeWork scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:[tblHomeWork numberOfRowsInSection:selectedSection]-1 inSection:selectedSection] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}

- (IBAction)onClickPickDate:(UIDatePicker *)datePicker {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString *strDate = [dateFormatter stringFromDate:datePicker.date];
    [datePicker setMaximumDate:[NSDate date]];
    
    NSLog(@"%@",strDate);
    
    if (btnSelected == YES) {
        if(strFromDate != nil){
            [datePicker setMaximumDate:[dateFormatter dateFromString:strFromDate]];
        }
        strToDate = strDate;
        strCancelToDate = strDate;
        [btnToDate setTitle:strDate forState:UIControlStateNormal];
    }else{
        if(strToDate != nil){
            [datePicker setMinimumDate:[dateFormatter dateFromString:strToDate]];
        }
        strFromDate = strDate;
        strCancelFromDate = strDate;
        [btnFromDate setTitle:strDate forState:UIControlStateNormal];
    }
}

- (IBAction)onClickToDateBtn:(id)sender {
    
    btnSelected = YES;
    
    //    btnFromDate.layer.borderColor = [UIColor lightGrayColor].CGColor;
    //    btnToDate.layer.borderColor = datePickerBoardColor.CGColor;
    
    pickerHomeWorkDate = [[UIDatePicker alloc] init];
    [pickerHomeWorkDate setDatePickerMode:UIDatePickerModeDate];
    [pickerHomeWorkDate addTarget:self action:@selector(onClickPickDate:) forControlEvents:UIControlEventValueChanged];
    
    viewDatePicker.frame = CGRectMake(viewDatePicker.frame.origin.x, (SHARED_APPDELEGATE.window.frame.size.height - 200)/2, SHARED_APPDELEGATE.window.frame.size.width - 20, 230);
    viewDatePicker.hidden = NO;
}

- (IBAction)onClickFromDateBtn:(id)sender {
    
    btnSelected = NO;
    
    //    btnFromDate.layer.borderColor = datePickerBoardColor.CGColor;
    //    btnToDate.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    pickerHomeWorkDate = [[UIDatePicker alloc] init];
    [pickerHomeWorkDate setDatePickerMode:UIDatePickerModeDate];
    [pickerHomeWorkDate addTarget:self action:@selector(onClickPickDate:) forControlEvents:UIControlEventValueChanged];
    
    viewDatePicker.frame = CGRectMake(viewDatePicker.frame.origin.x, (SHARED_APPDELEGATE.window.frame.size.height - 200)/2, SHARED_APPDELEGATE.window.frame.size.width - 20, 230);
    viewDatePicker.hidden = NO;
}

- (IBAction)onClickDoneBtn:(id)sender {
    
    viewDatePicker.hidden = YES;
}

- (IBAction)onClickCancelBtn:(id)sender {
    
    if (btnSelected == YES) {
        [btnToDate setTitle:strCancelToDate forState:UIControlStateNormal];
    }else{
        [btnFromDate setTitle:strCancelFromDate forState:UIControlStateNormal];
    }
    
    viewDatePicker.hidden = YES;
}

- (IBAction)onClickFilterBtn:(id)sender {
    
    //    btnFromDate.layer.borderColor = [UIColor lightGrayColor].CGColor;
    //    btnToDate.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    [self getHomeWorkToDate:strCancelToDate andFromDate:strCancelFromDate];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
