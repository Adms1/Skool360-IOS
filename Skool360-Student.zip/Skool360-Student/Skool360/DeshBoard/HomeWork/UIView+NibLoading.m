//
//  UIView+NibLoading.m
//  BookListing
//
//  Created by Chintan on 09/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UIView+NibLoading.h"
#import "AppDelegate.h"

@implementation UIView (NibLoading)

+(UIView*) loadInstanceFromNib:(id)fileOwner {
    
    UIView *result = nil;
    NSArray* elements = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:fileOwner options: nil];
    for (id anObject in elements) {
        if ([anObject isKindOfClass:[self class]]) {
            result = anObject;
            break;
        }
    }
    return result;
}

+(UIView*) loadInstanceFromNib:(id)fileOwner :(NSString *)nibName {
    
    UIView *result = nil;
    NSArray* elements = [[NSBundle mainBundle] loadNibNamed:nibName owner:fileOwner options: nil];
    for (id anObject in elements) {
        if ([anObject isKindOfClass:[self class]]) {
            result = anObject;
            break;
        }
    }
    return result;
}

@end
