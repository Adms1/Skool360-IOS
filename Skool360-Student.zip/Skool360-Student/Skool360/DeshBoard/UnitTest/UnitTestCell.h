//
//  UnitTestCell.h
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MarkSheetListCell.h"

@interface UnitTestCell : UITableViewCell

{
    IBOutlet UIView *viewBack;
    IBOutlet UIView *viewCellBack;
    IBOutlet UIView *viewHeader;
    IBOutlet UIView *viewFooter;
    
    IBOutlet UITableView *tblMarkSheet;
    
    IBOutlet UILabel *lblTotalMark;
    IBOutlet UILabel *lblTotalMarkGained;
    IBOutlet UILabel *lblPercentage;
    
    NSMutableArray *arrMarkList;
    
    CGFloat cellHeight;
}
@property(nonatomic,retain)IBOutlet UIImageView *imgDrop;
@property(nonatomic,retain)IBOutlet UIView *viewSyllabus;
@property(nonatomic,retain)IBOutlet UILabel *lblSubject;
@property(nonatomic,retain)IBOutlet UIButton *btnViewSyllabus1;
@property(nonatomic,retain)IBOutlet UIButton *btnViewSyllabus2;

-(void)setMarkSheetData:(NSArray *)arrData;
-(CGFloat )getUnitTestCellHeight;
-(void)setUnitTestData:(NSArray *)arrData;
@end
