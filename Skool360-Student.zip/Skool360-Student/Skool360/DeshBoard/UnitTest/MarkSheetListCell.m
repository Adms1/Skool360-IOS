//
//  MarkSheetListCell.m
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MarkSheetListCell.h"

@implementation MarkSheetListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setMarkSheetDataList:(UnitTest*)objUnitTest
{    
    lblDate.text = objUnitTest.Date;
    lblSubject.text = objUnitTest.SubjectName;
    lblMark.text = objUnitTest.MarkGained;
    lblTotal.text = objUnitTest.TestMark;
}

-(CGFloat )getCellHeight
{
    cellHeight = 36.0f;
    return cellHeight;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
