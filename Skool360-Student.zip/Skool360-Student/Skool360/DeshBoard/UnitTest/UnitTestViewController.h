//
//  UnitTestViewController.h
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "UnitTestCell.h"
#import "UnitTestSectionView.h"

@interface UnitTestViewController : MasterViewController <UnitTestDelegate>

{
    IBOutlet UITableView *tblUnitTest;
    IBOutlet UIButton *btnUnitTest;

    IBOutlet UILabel *lblNoFound;
    IBOutlet UIImageView *imgNoRecord;
    IBOutlet UIImageView *imgArrow;

    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    
    NSMutableArray *arrUnitTest;
    
    int selectedSection;
}

@end
