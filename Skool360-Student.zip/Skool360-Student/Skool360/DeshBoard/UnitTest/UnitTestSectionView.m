//
//  UnitTestSectionView.m
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "UnitTestSectionView.h"
#import "AppDelegate.h"

@implementation UnitTestSectionView

//UIView
@synthesize viewBack;

//UILabel
@synthesize lblDate;

//Integer
@synthesize index;

//Delegate
@synthesize testDelegate;

AppDelegate *appDelegateUnitTest;

-(id) initWithFrame:(CGRect)frame
{
    if(self == [super initWithFrame:frame])
    {
        appDelegateUnitTest = (AppDelegate *)[UIApplication sharedApplication].delegate;
        self = (UnitTestSectionView *)[UnitTestSectionView loadInstanceFromNib:self];
        
        UITapGestureRecognizer *singleFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dateSingleTap:)];
        [viewBack addGestureRecognizer:singleFingerTap];
    }
    return self;
}

-(void)setSelectedColor:(UIColor *)color
{
    imgTop.backgroundColor = sectionSelectColor;
    imgBottom.backgroundColor = sectionSelectColor;
}

-(void)setNormalColor
{
    imgTop.backgroundColor = [UIColor grayColor];
    imgBottom.backgroundColor = [UIColor grayColor];
}

-(void)setSectionData:(NSString *)title
{
    lblDate.text =title;
}

- (void)dateSingleTap:(UITapGestureRecognizer *)recognizer {
    
    if (testDelegate && [testDelegate respondsToSelector:@selector(setUnitTestDateAtindex:)]) {
        [testDelegate setUnitTestDateAtindex:index];
    }
}

@end
