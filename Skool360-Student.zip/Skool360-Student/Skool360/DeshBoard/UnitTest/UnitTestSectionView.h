//
//  UnitTestSectionView.h
//  Skool360
//
//  Created by Darshan on 08/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+NibLoading.h"

@protocol UnitTestDelegate <NSObject>

-(void)setUnitTestDateAtindex:(int)index;

@end

@interface UnitTestSectionView : UIView

{
    IBOutlet UIImageView *imgTop;
    IBOutlet UIImageView *imgBottom;
}

//Delegate
@property (strong , nonatomic) id<UnitTestDelegate> testDelegate;

@property (nonatomic , strong) IBOutlet UIView *viewBack;
@property (nonatomic , strong) IBOutlet UILabel *lblDate;

-(void)setSectionData:(NSString *)title;

-(void)setSelectedColor:(UIColor *)color;
-(void)setNormalColor;

//Integer
@property (nonatomic)int index;

@end
