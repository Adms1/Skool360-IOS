//
//  ProfileCell.h
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyProfile.h"

@interface ProfileCell : UITableViewCell

{
    IBOutlet UILabel *lblName;
    IBOutlet UILabel *lblDateOFBirth;
    IBOutlet UILabel *lblAge;
    IBOutlet UILabel *lblGender;
    IBOutlet UILabel *lblBloodGroup;
    IBOutlet UILabel *lblBirthPlace;
    
    IBOutlet UILabel *lblFatherName;
    IBOutlet UILabel *lblFatherPhoneNo;
    IBOutlet UILabel *lblFatherEmail;
    IBOutlet UILabel *lblMotherName;
    IBOutlet UILabel *lblMotherPhoneNo;
    IBOutlet UILabel *lblMotherEmail;
    IBOutlet UILabel *lblSMSNo;

    IBOutlet UILabel *lblAddress;
    IBOutlet UILabel *lblCity;
    IBOutlet UILabel *lblKM;
    IBOutlet UILabel *lblPickUpTime;
    IBOutlet UILabel *lblDropTime;
    IBOutlet UILabel *lblTitleCity;
    IBOutlet UILabel *lblTitleKM;
    IBOutlet UILabel *lblTitlePickUpTime;
    IBOutlet UILabel *lblTitleDropTime;
    IBOutlet UILabel *lblTitleBusNo;
    IBOutlet UILabel *lblTitleDropPointName;
    IBOutlet UILabel *lblTitleRouteName;
    IBOutlet UILabel *lblTitlePickupPointName;
    
    CGFloat cellHeight;
}
@property(nonatomic,retain)IBOutlet UIImageView *imgProfilePic;
@property(nonatomic,retain)IBOutlet UIButton *btnEditDetail;
@property(nonatomic,retain)IBOutlet UIButton *btnPersonalDetail;
@property(nonatomic,retain)IBOutlet UIButton *btnEducationalDetail;
@property(nonatomic,retain)IBOutlet UILabel *lblTitleUserName;

-(void)setMyProfileData:(MyProfile *)objMyProfile;
-(void)setCellNewHeight:(float)extraheight;
-(CGFloat )getCellHeight;

@end
