//
//  MyProfileView.m
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MyProfileView.h"
#import "CommonClass.h"
#import "MyProfile.h"
#import "AppDelegate.h"
#import "UIImageView+WebCache.h"

@interface MyProfileView ()
{
    NSInteger btnNo;
}
@end

@implementation MyProfileView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:@"Personal" forKey:PROFILESELECTTYPE];
    
    [self setMyProfileDetail];
}

-(void)viewWillAppear:(BOOL)animated
{
    [[self view]layoutIfNeeded];
    
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]firstObject]) setTitle:self.title.uppercaseString forState:0];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:1]) addTarget:self action:@selector(onClickSideMenuBtn:) forControlEvents:UIControlEventTouchUpInside];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:2]) addTarget:self action:@selector(onClickBackBtn:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)setMyProfileDetail
{
    
    //    asyProfileImg.layer.cornerRadius = 30.0f;
    btnUpdatePassword.layer.cornerRadius = 4.0f;
    btnUpdatePassword.hidden = YES;
    
    arrProfileList = [[NSMutableArray alloc] init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    strProfileType = [[NSUserDefaults standardUserDefaults]objectForKey:PROFILESELECTTYPE];
    
    [params setObject:strStudentID forKey:@"StudentID"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:profile_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrMyPro = [responseObject safeObjectForKey:@"FinalArray"];
            
            if ([arrMyPro count] > 0) {
                
                NSDictionary *dict = [arrMyPro firstObject];
                NSLog(@"dict>>> %@",dict);
                
                MyProfile *objProfile = [[MyProfile alloc] init];
                
                objProfile.AddmissionDate = [dict safeObjectForKey:@"AddmissionDate"];
                objProfile.Address = [dict safeObjectForKey:@"Address"];
                objProfile.BirthPlace = [dict safeObjectForKey:@"BirthPlace"];
                objProfile.BloodGroup = [dict safeObjectForKey:@"BloodGroup"];
                objProfile.Caste = [dict safeObjectForKey:@"Caste"];
                objProfile.City = [dict safeObjectForKey:@"City"];
                objProfile.Class = [dict safeObjectForKey:@"Class"];
                objProfile.FatherEmail = [dict safeObjectForKey:@"FatherEmail"];
                objProfile.FatherName = [dict safeObjectForKey:@"FatherName"];
                objProfile.FatherPhone = [dict safeObjectForKey:@"FatherPhone"];
                objProfile.GRNO = [dict safeObjectForKey:@"GRNO"];
                objProfile.House = [dict safeObjectForKey:@"House"];
                objProfile.MotherEmail = [dict safeObjectForKey:@"MotherEmail"];
                objProfile.MotherMobile = [dict safeObjectForKey:@"MotherMobile"];
                objProfile.MotherName = [dict safeObjectForKey:@"MotherName"];
                objProfile.SMSNo = [dict safeObjectForKey:@"SMSNumber"];
                objProfile.Password = [dict safeObjectForKey:@"Password"];
                objProfile.SMSNumber = [dict safeObjectForKey:@"SMSNumber"];
                objProfile.Standard = [dict safeObjectForKey:@"Standard"];
                objProfile.StudentAge = [dict safeObjectForKey:@"StudentAge"];
                objProfile.StudentDOB = [dict safeObjectForKey:@"StudentDOB"];
                objProfile.StudentGender = [dict safeObjectForKey:@"StudentGender"];
                objProfile.StudentImage = [dict safeObjectForKey:@"StudentImage"];
                objProfile.StudentName = [dict safeObjectForKey:@"StudentName"];
                objProfile.Transport_DropTime = [dict safeObjectForKey:@"Transport_DropTime"];
                objProfile.Transport_KM = [dict safeObjectForKey:@"Transport_KM"];
                objProfile.Transport_PicupTime = [dict safeObjectForKey:@"Transport_PicupTime"];
                objProfile.Transport_PickupPointName = [dict safeObjectForKey:@"PickupPoint Name"];
                objProfile.Transport_DropPointName = [dict safeObjectForKey:@"DropPoint Name"];
                objProfile.Transport_RouteName = [dict safeObjectForKey:@"Route Name"];
                objProfile.BusNo = [dict safeObjectForKey:@"Bus No"];
                objProfile.UserName = [dict safeObjectForKey:@"UserName"];
                
                [userDefault setObject:[dict safeObjectForKey:@"Password"] forKey:PASSWORD];
                
                [arrProfileList addObject:objProfile];
                
                [tblProfileList reloadData];
            }
        }else{
            [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"data"] delegate:self];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return IS_IPAD ? 250 : isiPhone5 ? 200 : 220;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    ProfileCell *cell = (ProfileCell *)[tableView dequeueReusableCellWithIdentifier:@"ProfileHeaderCell"];
    
    [cell.btnPersonalDetail addTarget:self action:@selector(onClickPersonalDetailBtn:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnEditDetail addTarget:self action:@selector(onClickEditProfileBtn:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnEducationalDetail addTarget:self action:@selector(onClickEducationDetailBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    MyProfile *objProfile = [arrProfileList objectAtIndex:0];
    
    cell.lblTitleUserName.text = objProfile.StudentName;
    
    cell.imgProfilePic.layer.cornerRadius = cell.imgProfilePic.frame.size.width/2;
    cell.imgProfilePic.clipsToBounds = YES;
    cell.imgProfilePic.layer.borderColor = imgCircleColor.CGColor;
    cell.imgProfilePic.layer.borderWidth = 2.0f;
    
    if ([objProfile.StudentImage isEqualToString:@""]) {
        cell.imgProfilePic.image = [UIImage imageNamed:@"SimpleProfile"];
    }else{
        [cell.imgProfilePic sd_setImageWithURL:[NSURL URLWithString:[objProfile.StudentImage stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"StudentProfile"]];
    }
    
    cell.btnPersonalDetail.titleLabel.font = FONT_Semibold(IS_IPAD ? 13 : 11);
    cell.btnEducationalDetail.titleLabel.font = FONT_Semibold(IS_IPAD ? 13 : 11);
    cell.btnEditDetail.titleLabel.font = FONT_Semibold(IS_IPAD ? 13 : 11);
    
    if(btnNo == 2){
        cell.btnEducationalDetail.backgroundColor = btnSelectBackgroundColor;
        cell.btnEducationalDetail.layer.shadowOpacity = 0.0f;
        
        cell.btnPersonalDetail.backgroundColor = btnUnSlectBackgroundColor;
        cell.btnPersonalDetail.layer.shadowColor = [[UIColor grayColor] CGColor];
        cell.btnPersonalDetail.layer.shadowOffset = CGSizeMake(0.0f,3.0f);
        cell.btnPersonalDetail.layer.shadowOpacity = 1.0f;
        cell.btnPersonalDetail.layer.shadowRadius = 2.0f;
        
        cell.btnEditDetail.backgroundColor = btnUnSlectBackgroundColor;
        cell.btnEditDetail.layer.shadowColor = [[UIColor grayColor] CGColor];
        cell.btnEditDetail.layer.shadowOffset = CGSizeMake(0.0f,3.0f);
        cell.btnEditDetail.layer.shadowOpacity = 1.0f;
        cell.btnEditDetail.layer.shadowRadius = 2.0f;
    }
    else if(btnNo == 3){
        cell.btnEditDetail.backgroundColor = btnSelectBackgroundColor;
        cell.btnEditDetail.layer.shadowOpacity = 0.0f;
        
        cell.btnPersonalDetail.backgroundColor = btnUnSlectBackgroundColor;
        cell.btnPersonalDetail.layer.shadowColor = [[UIColor grayColor] CGColor];
        cell.btnPersonalDetail.layer.shadowOffset = CGSizeMake(0.0f,3.0f);
        cell.btnPersonalDetail.layer.shadowOpacity = 1.0f;
        cell.btnPersonalDetail.layer.shadowRadius = 2.0f;
        
        cell.btnEducationalDetail.backgroundColor = btnUnSlectBackgroundColor;
        cell.btnEducationalDetail.layer.shadowColor = [[UIColor grayColor] CGColor];
        cell.btnEducationalDetail.layer.shadowOffset = CGSizeMake(0.0f,3.0f);
        cell.btnEducationalDetail.layer.shadowOpacity = 1.0f;
        cell.btnEducationalDetail.layer.shadowRadius = 2.0f;
    }else {
        cell.btnPersonalDetail.backgroundColor = btnSelectBackgroundColor;
        cell.btnPersonalDetail.layer.shadowOpacity = 0.0f;
        
        cell.btnEducationalDetail.backgroundColor = btnUnSlectBackgroundColor;
        cell.btnEducationalDetail.layer.shadowColor = [[UIColor grayColor] CGColor];
        cell.btnEducationalDetail.layer.shadowOffset = CGSizeMake(0.0f,3.0f);
        cell.btnEducationalDetail.layer.shadowOpacity = 1.0f;
        cell.btnEducationalDetail.layer.shadowRadius = 2.0f;
        
        cell.btnEditDetail.backgroundColor = btnUnSlectBackgroundColor;
        cell.btnEditDetail.layer.shadowColor = [[UIColor grayColor] CGColor];
        cell.btnEditDetail.layer.shadowOffset = CGSizeMake(0.0f,3.0f);
        cell.btnEditDetail.layer.shadowOpacity = 1.0f;
        cell.btnEditDetail.layer.shadowRadius = 2.0f;
    }
    return cell.contentView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if ([strProfileType isEqualToString:@"Change Password"]){
        return  IS_IPAD ? 70 : viewFooter.frame.size.height;
    }
    return 0;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if ([strProfileType isEqualToString:@"Change Password"]){
        return  viewFooter;
    }
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([strProfileType isEqualToString:@"Education"]) {
        tableView.estimatedRowHeight = 76;
    }else if ([strProfileType isEqualToString:@"Personal"]){
        tableView.estimatedRowHeight = IS_IPAD ? 730 : 580;
    }else if ([strProfileType isEqualToString:@"Change Password"]){
        tableView.estimatedRowHeight = 138;
    }
    return UITableViewAutomaticDimension;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return arrProfileList.count > 0 ? 1 : 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdenti = @"ChatImageCell";
    
    if ([strProfileType isEqualToString:@"Education"]) {
        
        EducationalCell *cell = (EducationalCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"EducationalCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle  = UITableViewCellSelectionStyleNone;
        
        if ([arrProfileList count] > 0) {
            MyProfile *objProfile = [arrProfileList objectAtIndex:indexPath.row];
            [cell setMyProfileEducationData:objProfile];
        }
        
        return cell;
    }else if ([strProfileType isEqualToString:@"Personal"]){
        ProfileCell *cell = (ProfileCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ProfileCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle  = UITableViewCellSelectionStyleNone;
        
        if ([arrProfileList count] > 0) {
            MyProfile *objProfile = [arrProfileList objectAtIndex:indexPath.row];
            [cell setMyProfileData:objProfile];
        }
        
        return cell;
    }else if ([strProfileType isEqualToString:@"Change Password"]){
        EditProfileCell *cell = (EditProfileCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"EditProfileCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle  = UITableViewCellSelectionStyleNone;
        cell.tblDelegate = self;
        cell.index = (int)indexPath.row;
        
        if ([arrProfileList count] > 0) {
            MyProfile *objProfile = [arrProfileList objectAtIndex:indexPath.row];
            [cell setMyProfileEditData:objProfile];
        }
        
        return cell;
    }
    return nil;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (IBAction)onClickPersonalDetailBtn:(UIButton *)sender {
    
    btnNo = 1;
    
    [userDefault removeObjectForKey:PROFILESELECTTYPE];
    [userDefault setObject:@"Personal" forKey:PROFILESELECTTYPE];
    
    strProfileType = [[NSUserDefaults standardUserDefaults]objectForKey:PROFILESELECTTYPE];
    
    [self setMyProfileDetail];
    //[tblProfileList reloadData];
}

- (IBAction)onClickEducationDetailBtn:(UIButton *)sender {
    
    btnNo = 2;
    
    [userDefault removeObjectForKey:PROFILESELECTTYPE];
    [userDefault setObject:@"Education" forKey:PROFILESELECTTYPE];
    
    strProfileType = [[NSUserDefaults standardUserDefaults]objectForKey:PROFILESELECTTYPE];
    
    [self setMyProfileDetail];
    //    [tblProfileList reloadData];
}

- (IBAction)onClickEditProfileBtn:(UIButton *)sender {
    
    btnNo = 3;
    
    [userDefault removeObjectForKey:PROFILESELECTTYPE];
    [userDefault setObject:@"Change Password" forKey:PROFILESELECTTYPE];
    
    strProfileType = [[NSUserDefaults standardUserDefaults]objectForKey:PROFILESELECTTYPE];
    
    [self setMyProfileDetail];
    //    [tblProfileList reloadData];
}


#pragma mark -
#pragma mark - TABLEVIEW_SCROLLING_DELEGATE METHOD

-(void)setTableScrollWithIndex:(int)index
{
    int scrollY =  40 + (54 * index);
    [tblProfileList setContentOffset:CGPointMake(0.0f, scrollY) animated:YES];
}

-(void)resingKeyBoard
{
    [tblProfileList setContentInset:UIEdgeInsetsZero];
    [tblProfileList setContentOffset:CGPointZero animated:YES];
}

-(void)setUpdatePassword:(NSString*)strChange
{
    [self resingKeyBoard];
    if ([strChange isEqualToString:@"Change"]) {
        btnUpdatePassword.hidden = NO;
    }else{
        btnUpdatePassword.hidden = YES;
    }
}

- (IBAction)onClickUpdatePasswordBtn:(id)sender {
    
    NSString *strNewPassword = nil;
    
    NSIndexPath *newIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    
    EditProfileCell *cell = [tblProfileList cellForRowAtIndexPath:newIndexPath];
    
    if(cell != nil){
        strNewPassword = cell.txtPassword.text;
    }
    
    if([CommonClass trimString:strNewPassword].length == 0){
        [CommonClass showAlertWithTitle:provideAlert andMessage:providePassword delegate:self];
        return;
    }
    else if ([strNewPassword length] < 4 || [strNewPassword length] > 12) {
        [[[UIAlertView alloc]initWithTitle:provideAlert message:provideValidNewPassword delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
        return;
    }
    [self resingKeyBoard];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    NSString *strOldPassword = [[NSUserDefaults standardUserDefaults]objectForKey:PASSWORD];
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strOldPassword forKey:@"OldPassword"];
    [params setObject:strNewPassword forKey:@"NewPassword"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:changePassword_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            [self setMyProfileDetail];
            [CommonClass showAlertWithTitle:provideAlert andMessage:provideSuccess delegate:self];
        }else{
            [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"data"] delegate:self];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
