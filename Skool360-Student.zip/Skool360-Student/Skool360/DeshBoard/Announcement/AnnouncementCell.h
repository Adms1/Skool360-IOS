//
//  CircularCell.h
//  Skool360
//
//  Created by ADMS on 01/11/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Announcement.h"

@interface AnnouncementCell : UITableViewCell

-(void)setAnnouncementHeaderData:(Announcement *)announcementData;
-(void)setAnnouncementData:(Announcement *)announcementData;
-(CGFloat)getHeight;
@end
