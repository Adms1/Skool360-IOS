//
//  HeaderView.h
//  Skool360
//
//  Created by ADMS on 28/12/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeaderView : UIView

@end
