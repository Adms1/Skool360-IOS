//
//  TimeTableViewControlle.m
//  Skool360
//
//  Created by Darshan on 01/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "TimeTableViewControlle.h"
#import "CommonClass.h"
#import "AppDelegate.h"

@interface TimeTableViewControlle ()

@end

@implementation TimeTableViewControlle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (isiPhone6) {
        imgLogo.frame = CGRectMake(-66, 0, 140, 45);
    }else if (isiPhone6Plus){
        imgLogo.frame = CGRectMake(-86, 0, 140, 45);
    }
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.titleView = viewtitle;
    
    [btnSideMenu setAttributedTitle:nil forState:UIControlStateNormal];
    [[btnSideMenu titleLabel] setNumberOfLines:0];
    [[btnSideMenu titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    
//    UIBarButtonItem *barBtnSide = [[UIBarButtonItem alloc] initWithCustomView:btnSideMenu];
//    self.navigationItem.rightBarButtonItems = @[barBtnSide];
//    
//    UIBarButtonItem *barBtnBack = [[UIBarButtonItem alloc] initWithCustomView:btnBack];
//    self.navigationItem.leftBarButtonItems = @[barBtnBack];
    
    arrTimeTableList = [[NSMutableArray alloc] init];
    
    selectedSection = -1;
    
    [self getTimeTableData];
    tblTimeTable.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
}

-(void)getTimeTableData
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    imgNoRecord.hidden = YES;
    
    [params setObject:strStudentID forKey:@"StudentID"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:timeTable_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrListHomeWork = [responseObject safeObjectForKey:@"FinalArray"];
            [arrTimeTableList addObjectsFromArray:arrListHomeWork];
            [tblTimeTable reloadData];
        }else{
            tblTimeTable.hidden = YES;
            imgNoRecord.hidden = NO;
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

#pragma mark -
#pragma mark - TableView Delegate Method

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == selectedSection){
        return 52.0f;
    }else{
        return 0;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGRect rect = CGRectMake(0, 0, SHARED_APPDELEGATE.window.frame.size.width,50);
    TimeTableSectionView *viewFit = [[TimeTableSectionView alloc] initWithFrame:rect];
    
    viewFit.timeTableDelegate = self;
    viewFit.index = (int)section;
    
    if(section == selectedSection){
        [viewFit setSelectedColor:imgCircleColor];
    }else{
        [viewFit setNormalColor];
    }
    
    NSDictionary *dictData =[arrTimeTableList objectAtIndex:section];
    
    [viewFit setSectionData:[dictData objectForKey:@"Day"]];
    //NSArray *arrData =[dictData objectForKey:@"Data"];
    //[viewFit setFitType:[arrFitGuide objectAtIndex:section]];
    return viewFit;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [arrTimeTableList count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSDictionary *dictData =[arrTimeTableList objectAtIndex:section];
    NSArray *arrData =[dictData objectForKey:@"Data"];
    return [arrData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    if(indexPath.section != selectedSection){
        
        static NSString *simpleTableIdenti = @"TimeTable1";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdenti];
        }
        
        return  cell;
    }else{
        
        static NSString *simpleTableIdenti = @"TimeTable";
        
        TimeTableCell *cell = (TimeTableCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"TimeTableCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle  = UITableViewCellSelectionStyleNone;
        
        NSDictionary *dictData =[arrTimeTableList objectAtIndex:indexPath.section];
        
        NSArray *arrsecton = [dictData safeObjectForKey:@"Data"];
        NSDictionary *dict = [arrsecton objectAtIndex:indexPath.row];
        
        [cell setTimeTableData:dict];
        
        return  cell;
    }
    
    return nil;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

-(void)setTimeTableDateAtindex:(int)index
{
    NSLog(@"Section Select: %d",index);
    
    if(index == selectedSection){
        selectedSection = -1;
    }else{
        selectedSection = index;
    }
    
    [tblTimeTable reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
