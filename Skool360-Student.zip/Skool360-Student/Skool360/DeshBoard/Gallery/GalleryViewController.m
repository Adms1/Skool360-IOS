//
//  GalleryViewController.m
//  Bhadaj (Student)
//
//  Created by ADMS on 23/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "GalleryViewController.h"
#import "UIImageView+WebCache.h"
#import "GalleryCell.h"
#import "AppDelegate.h"
#import "CommonClass.h"

NSInteger photoType = 0;
NSMutableArray<Events *> *arrGalleryData;
NSInteger selectedEventIndex;
NSInteger selectedPhotoIndex;

@interface GalleryViewController ()

@end

@implementation GalleryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)viewWillAppear:(BOOL)animated
{
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]firstObject]) setTitle:self.title.uppercaseString forState:0];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:1]) addTarget:self action:@selector(onClickSideMenuBtn:) forControlEvents:UIControlEventTouchUpInside];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:2]) addTarget:self action:@selector(onClickBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    UICollectionViewFlowLayout *layout = (UICollectionViewFlowLayout *)[collectionView collectionViewLayout];
    if(photoType == 2) {
        collectionView.pagingEnabled = true;
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        [collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:selectedPhotoIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
    }
    else {
        [photoView setHidden:YES];
        if(photoType == 0){
            [self getGalleryData];
        }
        collectionView.pagingEnabled = false;
        layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    }
    [collectionView reloadData];
}

-(void)getGalleryData
{
    arrGalleryData = [[NSMutableArray alloc] init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:GetGallery_Url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [imgNoRecord setHidden:YES];
            
            NSMutableArray *arrListPhotos = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dict in arrListPhotos) {
                
                Events *objEvents = [[Events alloc] init];
                objEvents.strEventName = [dict safeObjectForKey:@"EventName"];
                
                NSMutableArray<Photos *> *arrPhotos = [[NSMutableArray alloc]init];
                for (NSDictionary *photoDict in [dict safeObjectForKey:@"Photos"]) {
                    
                    Photos *objPhotos = [[Photos alloc] init];
                    
                    objPhotos.strPhotoTitle = [photoDict safeObjectForKey:@"Title"];
                    objPhotos.strPhotoLink = [photoDict safeObjectForKey:@"ImagePath"];
                    
                    [arrPhotos addObject:objPhotos];
                }
                
                objEvents.strEventPic = arrPhotos[0].strPhotoLink;
                objEvents.photos = arrPhotos;
                
                [arrGalleryData addObject:objEvents];
            }
        }else{
            [imgNoRecord setHidden:NO];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        [collectionView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(collectionView.frame.size.width/(photoType == 2 ? 1 : IS_IPAD ? 3 : 2), collectionView.frame.size.width/(photoType == 2 ? 1 : IS_IPAD ? 3 : 2));
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    switch (photoType) {
        case 0:
            return arrGalleryData.count;
        default:
            return arrGalleryData[selectedEventIndex].photos.count;
    }
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    GalleryCell *cell = (GalleryCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"GalleryCell" forIndexPath:indexPath];
    
    cell.imgPic.layer.borderWidth = 1.0;
    cell.imgPic.layer.borderColor = imgCircleColor.CGColor;
    [cell.lblName setFont:FONT_Semibold(IS_IPAD ? 30 : 22)];
    
    if(photoType == 0) {
        cell.imgPic.contentMode = UIViewContentModeScaleToFill;
        
        [cell.imgPic sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",HostName ,arrGalleryData[indexPath.row].strEventPic]] placeholderImage:[UIImage imageNamed:@"placeholder"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            
            cell.lblName.text = arrGalleryData[indexPath.row].strEventName;
            [cell.lblName setHidden:NO];
        }];
    }else{
        [cell.imgPic sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",HostName ,arrGalleryData[selectedEventIndex].photos[indexPath.row].strPhotoLink]] placeholderImage:[UIImage imageNamed:@"placeholder"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            
            if(photoType == 2) {
                cell.imgPic.contentMode = UIViewContentModeScaleAspectFit;
                [cell.lblName setHidden:YES];
            }else {
                cell.imgPic.contentMode = UIViewContentModeScaleToFill;
                cell.lblName.text = arrGalleryData[selectedEventIndex].photos[indexPath.row].strPhotoTitle;
                [cell.lblName setHidden:YES];
            }
        }];
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    GalleryCell *cell = (GalleryCell *)[collectionView cellForItemAtIndexPath:indexPath];
    
    if(photoType < 1) {
        cell.imgPic.layer.borderColor = [[UIColor lightGrayColor]CGColor];
        photoType += 1;
        
        NSString *strTitle;
        switch (photoType) {
            case 1:
                selectedEventIndex = indexPath.row;
                strTitle = arrGalleryData[selectedEventIndex].strEventName;
                break;
            case 2:
                selectedPhotoIndex = indexPath.row;
                strTitle = arrGalleryData[selectedEventIndex].photos[selectedPhotoIndex].strPhotoTitle;
                break;
            default:
                break;
        }
        
        ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        GalleryViewController *gvc = [storyBoard instantiateViewControllerWithIdentifier:@"GalleryViewController"];
        gvc.transition = animation;
        gvc.title = strTitle;
        [self.navigationController pushViewController:gvc animated:YES];
    }
    else
    {
        photoType += 1;
        selectedPhotoIndex = indexPath.row;
        [self addImages];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if(photoType == 2) {
//        for (UICollectionViewCell *cell in [collectionView visibleCells]) {
//            NSIndexPath *indexPath = [collectionView indexPathForCell:cell];
//            [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]firstObject]) setTitle:arrGalleryData[selectedEventIndex].photos[indexPath.row].strPhotoTitle.uppercaseString forState:0];
//        }
        selectedPhotoIndex = (scrollView.contentOffset.x/scrollView.frame.size.width);
    }
}

-(void)addImages
{
    [photoView setHidden:NO];
    if(arrGalleryData[selectedEventIndex].photos.count == 1){
        [btnNext setHidden:YES];
        [btnPrevious setHidden:YES];
    }else{
        [btnNext setHidden:NO];
        [btnPrevious setHidden:NO];
    }
    
    UIScrollView *scroll = (UIScrollView *)photoView.subviews[0];
    int x = 0;
    for (int i = 0; i < arrGalleryData[selectedEventIndex].photos.count; i++)
    {
        UIImageView *imgPhoto = [[UIImageView alloc]initWithFrame:CGRectMake(x, 0, scroll.frame.size.width, scroll.frame.size.height)];
        imgPhoto.contentMode = UIViewContentModeScaleAspectFit;
        [imgPhoto sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",HostName ,arrGalleryData[selectedEventIndex].photos[i].strPhotoLink]] placeholderImage:[UIImage imageNamed:@"placeholder"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        }];
        [scroll addSubview:imgPhoto];
        [scroll setContentSize:CGSizeMake(scroll.frame.size.width * arrGalleryData[selectedEventIndex].photos.count, scroll.frame.size.height)];
        
        x += scroll.frame.size.width;
    }
    [scroll setContentOffset:CGPointMake(selectedPhotoIndex * scroll.frame.size.width, 0) animated:NO];
}

-(IBAction)btnNextPrevious:(UIButton *)sender
{
    UIScrollView *scroll = (UIScrollView *)photoView.subviews[0];
    if(sender.tag == 1) {
        if(selectedPhotoIndex < arrGalleryData[selectedEventIndex].photos.count - 1) {
            selectedPhotoIndex += 1;
        }else{
            selectedPhotoIndex = 0;
        }
    }else{
        if(selectedPhotoIndex > 0) {
            selectedPhotoIndex -= 1;
        }else{
            selectedPhotoIndex = arrGalleryData[selectedEventIndex].photos.count - 1;
        }
    }
    [scroll setContentOffset:CGPointMake(selectedPhotoIndex * scroll.frame.size.width, 0) animated:YES];
}

-(IBAction)btnClose:(id)sender
{
    photoType -= 1;
    [photoView setHidden:YES];
    [photoView.subviews[0].subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
}

@end
