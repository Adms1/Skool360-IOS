
//
//  GalleryCell.m
//  Bhadaj (Student)
//
//  Created by ADMS on 23/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "GalleryCell.h"

@implementation GalleryCell

@end
