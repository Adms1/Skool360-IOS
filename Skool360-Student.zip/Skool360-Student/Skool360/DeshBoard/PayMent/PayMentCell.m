//
//  PayMentCell.m
//  Skool360
//
//  Created by Darshan on 13/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "PayMentCell.h"

BOOL isTerm1Pay,isTerm2Pay;

@implementation PayMentCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    viewback.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    viewback.layer.borderWidth = 0.5f;
}

-(void)setPaymentDeta:(NSString *)term1 :(NSString *)term2 :(NSString *)strdetail
{
    lblTite.text = strdetail;
    lblTerm1.text = [NSString stringWithFormat:@"₹ %@",term1];
    lblTerm2.text = [NSString stringWithFormat:@"₹ %@",term2];
    
    for (UIView *view in self.contentView.subviews[0].subviews) {
        if ([view isKindOfClass:[UILabel class]]) {
            UILabel *lbl = (UILabel *)view;
            if ([strdetail containsString:@"Dues"])
            {
                [lbl setFont:FONT_Bold(IS_IPAD ? 16 : 13)];
            }
            else
            {
                [lbl setFont:FONT_OpenSans(IS_IPAD ? 16 : 13)];
            }
        }
    }
}

-(void)setPaymentReceiptData:(NSDictionary *)dict :(NSInteger)Index
{
    self.contentView.subviews[0].layer.borderColor = [[UIColor lightGrayColor]CGColor];
    self.contentView.subviews[0].layer.borderWidth = 0.5;
    
    NSArray *array = @[[NSString stringWithFormat:@"%ld",(long)Index], [dict safeObjectForKey:@"Payment Type"], [dict safeObjectForKey:@"Date"], [dict safeObjectForKey:@"Term"], [NSString stringWithFormat:@"₹ %@",[dict safeObjectForKey:@"Amount"]]];
    
    int i = 0;
    for (UIView *view in self.contentView.subviews[0].subviews) {
        if ([view isKindOfClass:[UILabel class]]) {
            UILabel *lbl = (UILabel *)view;
            lbl.text = array[i];
            
            i++;
        }
    }
}

-(void)setPaymentOnlineData:(NSDictionary *)dict
{
    self.contentView.subviews[0].layer.borderColor = [[UIColor lightGrayColor]CGColor];
    self.contentView.subviews[0].layer.borderWidth = 0.5;
    
    NSArray *array = @[[dict safeObjectForKey:@"PaymentID"], [dict safeObjectForKey:@"Date"], [NSString stringWithFormat:@"₹ %@",[dict safeObjectForKey:@"Amount"]], [dict safeObjectForKey:@"TransactionStatus"], [dict safeObjectForKey:@"SchoolStatus"]];
    
    int i = 0;
    for (UIView *view in self.contentView.subviews[0].subviews) {
        if ([view isKindOfClass:[UILabel class]]) {
            UILabel *lbl = (UILabel *)view;
            lbl.text = array[i];
            lbl.textColor = [UIColor blackColor];
            
            if(i == 3){
                if([[array[i] lowercaseString] isEqualToString:@"success"]){
                    lbl.textColor = presentColor;
                }else{
                    lbl.textColor = absentColor;
                }
            }
            i++;
        }
    }
}

//-(void)setPaymentDeta:(NSDictionary *)dictTerms1 term2Data:(NSDictionary *)dictTerms2 andDetail:(NSString *)strdetail
//{
//    NSString *title = [strdetail stringByReplacingOccurrencesOfString:@"Money" withString:@"Fees"];
//    NSString *key = [BunbleName containsString:@"Shilaj"] ? title : strdetail;
//    lblTite.text = title;
//    lblTerm1.text = [NSString stringWithFormat:@"₹ %@",[dictTerms1 objectForKey:[key stringByReplacingOccurrencesOfString:@" " withString:@""]]];
//    lblTerm2.text = [NSString stringWithFormat:@"₹ %@",[dictTerms2 objectForKey:[key stringByReplacingOccurrencesOfString:@" " withString:@""]]];
//
//    for (UIView *view in self.contentView.subviews[0].subviews) {
//        if ([view isKindOfClass:[UILabel class]]) {
//            UILabel *lbl = (UILabel *)view;
//            if ([strdetail isEqualToString:@"Balance"])
//            {
//                [lbl setFont:FONT_Bold(IS_IPAD ? 16 : 13)];
//            }
//            else
//            {
//                [lbl setFont:FONT_OpenSans(IS_IPAD ? 16 : 13)];
//            }
//        }
//    }
//
//    //    if ([strdetail isEqualToString:@"PaidFees"] && isTerm1Pay)
//    //    {
//    //        [lblTerm1 setTextColor:[UIColor whiteColor]];
//    //        [lblTerm1 setBackgroundColor:TextBgColor];
//    //
//    //        if (isTerm2Pay) {
//    //
//    //            [lblTerm2 setTextColor:[UIColor whiteColor]];
//    //            [lblTerm2 setBackgroundColor:TextBgColor];
//    //        }
//    //    }
//    //
//    //    if ([strdetail isEqualToString:@"TotalPayableFees"])
//    //    {
//    //        if ([lblTerm1.text isEqualToString:@"0.00"]) {
//    //            isTerm1Pay = YES;
//    //
//    //            if ([lblTerm2.text isEqualToString:@"0.00"]) {
//    //                isTerm2Pay = YES;
//    //            }
//    //            else
//    //            {
//    //                [lblTerm2 setTextColor:[UIColor whiteColor]];
//    //                [lblTerm2 setBackgroundColor:[UIColor redColor]];
//    //            }
//    //        }
//    //        else
//    //        {
//    //            [lblTerm1 setTextColor:[UIColor whiteColor]];
//    //            [lblTerm1 setBackgroundColor:[UIColor redColor]];
//    //        }
//    //    }
//}

-(void)setPaymentSummaryData:(NSDictionary *)dict
{
    [viewback.subviews makeObjectsPerformSelector:@selector(setHidden:) withObject:NO];
    lblReceiptNo.text = dict[@"ReceiptNo"];
    lblPaymentMode.text = dict[@"PayMode"];
    lblTutionFee.text = [NSString stringWithFormat:@"₹ %@",dict[@"TuitionFee"]];
    lblCautionFee.text = [NSString stringWithFormat:@"₹ %@",dict[@"CautionFee"]];
    lblAdmissionFee.text = [NSString stringWithFormat:@"₹ %@",dict[@"AdmissionFee"]];
    lblTotal.text = [NSString stringWithFormat:@"₹ %@",dict[@"PayPaidFees"]];
    lblTransport.text = [NSString stringWithFormat:@"₹ %@",dict[@"Transport"]];
    lblLateFee.text = [NSString stringWithFormat:@"₹ %@",dict[@"LatesFee"]];
    lblPreviousFee.text = [NSString stringWithFormat:@"₹ %@",dict[@"PreviousFees"]];
    lblOff.text = [NSString stringWithFormat:@"₹ %@",dict[@"DiscountFee"]];
    lblImpest.text = [NSString stringWithFormat:@"₹ %@",dict[@"ImprestFee"]];
    lblCurrentFee.text = [NSString stringWithFormat:@"₹ %@",dict[@"CurrentOutstandingFees"]];
    
    lblTerm.text = dict[@"TermDetail"];
    lblBankName.text = dict[@"Bank Name"];
    lblChequeNo.text = dict[@"Cheque Number"];
}

-(void)HideData
{
    [viewback.subviews makeObjectsPerformSelector:@selector(setHidden:)];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
