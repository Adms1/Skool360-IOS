//
//  PaymentDetailsVC.m
//  Skool360
//
//  Created by ADMS on 24/08/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "PaymentDetailsVC.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "PayMentCell.h"
#import "PaymentOnlineVC.h"
#import "PayMentViewController.h"

@interface PaymentDetailsVC ()
{
    NSMutableArray *arrPayMentSummaryList;
}
@end

@implementation PaymentDetailsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[self tableView]setTableFooterView:[UIView new]];
    arrPayMentSummaryList  = [[NSMutableArray alloc]init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    NSString *strTermID = [[NSUserDefaults standardUserDefaults]objectForKey:TERMID];
    NSString *strStandardID = [[NSUserDefaults standardUserDefaults]objectForKey:STANDARDID];
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strTermID forKey:@"Term"];
    [params setObject:strStandardID forKey:@"StandardID"];
    
    [manager POST:PaymentLedger_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrSummary = [responseObject safeObjectForKey:[self.title isEqualToString:@"Payment Summary"] ? @"FinalArray" : @"OnlineTransaction"];
            [arrPayMentSummaryList addObjectsFromArray:arrSummary];
        }
        [self.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - TableView Datasource Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
//    return arrPayMentSummaryList.count > 0 ? [self.title isEqualToString:@"Payment Summary"] ? 40 : 50 : 0;
    return arrPayMentSummaryList.count > 0 ? 40 : 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    PayMentCell *cell = (PayMentCell *)[tableView dequeueReusableCellWithIdentifier: [self.title isEqualToString:@"Payment Summary"] ? @"PayMentHeaderCell1" : @"PayMentHeaderCell2"];
    cell.contentView.subviews[0].layer.borderColor = [[UIColor lightGrayColor]CGColor];
    cell.contentView.subviews[0].layer.borderWidth = 0.5;
    
    return arrPayMentSummaryList.count > 0 ? cell.contentView : nil;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrPayMentSummaryList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    PayMentCell *cell = (PayMentCell *)[tableView dequeueReusableCellWithIdentifier:[self.title isEqualToString:@"Payment Summary"] ? @"PayMentCell1" : @"PayMentCell2" forIndexPath:indexPath];
    NSDictionary *dict = [arrPayMentSummaryList objectAtIndex:indexPath.row];
    
    if([self.title isEqualToString:@"Payment Summary"])
    {
        [cell setPaymentReceiptData:dict :indexPath.row+1];
        [[[cell contentView]subviews]lastObject].tag = indexPath.row;
    }
    else
    {
        [cell setPaymentOnlineData:dict];
    }
    return cell;
}

-(IBAction)btnViewAction:(UIButton *)sender
{
    NSDictionary *dict = [arrPayMentSummaryList objectAtIndex:sender.tag];
    
    ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PaymentOnlineVC *povc = [storyBoard instantiateViewControllerWithIdentifier:@"PaymentOnlineVC"];
    povc.paymentUrl = [dict safeObjectForKey:@"URL"];
    povc.title = @"Fee Receipt";
    povc.transition = animation;
    [self.navigationController pushViewController:povc animated:YES];
}

@end
