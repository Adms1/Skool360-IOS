//
//  PaymentDetailsVC.h
//  Skool360
//
//  Created by ADMS on 24/08/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentDetailsVC : UITableViewController

@end
