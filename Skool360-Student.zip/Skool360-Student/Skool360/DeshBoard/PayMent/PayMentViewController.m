//
//  PayMentViewController.m
//  Skool360
//
//  Created by Darshan on 13/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "PayMentViewController.h"
#import "CommonClass.h"
#import "AppDelegate.h"
#import "SectionView.h"
#import "HomeView.h"
#import "PaymentOnlineVC.h"

@interface PayMentViewController () <HomeWorkDateDelegate>
{
    int selectedSection;
    BOOL isRowExtend;
}
@end

@implementation PayMentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    arrPayMentList  = [[NSMutableArray alloc]init];
    arrTerm1  = [[NSMutableArray alloc]init];
    arrTerm2  = [[NSMutableArray alloc]init];
    arrPayMentSummaryList  = [[NSMutableArray alloc]init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    NSString *strTermID = [[NSUserDefaults standardUserDefaults]objectForKey:TERMID];
    NSString *strStandardID = [[NSUserDefaults standardUserDefaults]objectForKey:STANDARDID];
    
    [params setObject:strStudentID forKey:@"StudentID"];
    [params setObject:strTermID forKey:@"Term"];
    [params setObject:strStandardID forKey:@"StandardID"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:payMent_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            btnPay1Show = [[responseObject safeObjectForKey:@"Term1Btn"]boolValue];
            btnPay2Show = [[responseObject safeObjectForKey:@"Term2Btn"]boolValue];
            
            isRowExtend = btnPay1Show || btnPay2Show;
            
            strPayNow1 = [responseObject safeObjectForKey:@"Term1URL"];
            strPayNow2 = [responseObject safeObjectForKey:@"Term2URL"];
            
            NSMutableArray *arrMyPro = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dict in arrMyPro)
            {
                [arrPayMentList addObject:[dict safeObjectForKey:@"LedgerName"]];
                [arrTerm1 addObject:[dict safeObjectForKey:@"Term1Amt"]];
                [arrTerm2 addObject:[dict safeObjectForKey:@"Term2Amt"]];
            }
            
            //            NSMutableDictionary *dictTerm1;
            //            NSMutableDictionary *dictTerm2;
            //            if ([arrMyPro count] > 0) {
            //                //   NSLog(@"FIST TERM %@",[arrMyPro firstObject]);
            //                dictTerm1 = [arrMyPro firstObject];
            //            }
            //            if([arrMyPro count] > 1){
            //                //  NSLog(@"second TERM %@",[arrMyPro lastObject]);
            //                dictTerm2 = [arrMyPro lastObject];
            //            }
            //
            //            if(dictTerm1 != nil){
            //                term1 = [[dictTerm1 objectForKey:@"Data"] firstObject];
            //                [btnPay1 setHidden:![[term1 valueForKey:@"ButtonVisiblity"] boolValue]];
            //            }
            //            if(dictTerm2 != nil){
            //                term2 = [[dictTerm2 objectForKey:@"Data"] firstObject];
            //                [btnPay2 setHidden:![[term2 valueForKey:@"ButtonVisiblity"] boolValue]];
            //            }
            //
            //            [self addArrayValue];
            
            [manager POST:PaymentLedger_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
                
                NSLog(@"ResponceLogin %@",responseObject);
                
                if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                    
                    NSMutableArray *arrSummary = [responseObject safeObjectForKey:@"FinalArray"];
                    [arrPayMentSummaryList addObjectsFromArray:arrSummary];
                }
                
                [tblPayMent reloadData];
                [SHARED_APPDELEGATE hideLoadingView];
                
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                
                [SHARED_APPDELEGATE hideLoadingView];
                NSLog(@"Error: %@", error);
            }];
            
        }else{
            [CommonClass showAlertWithTitle:provideAlert andMessage:[responseObject safeObjectForKey:@"data"] delegate:self];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)addArrayValue
{
    [arrPayMentList addObject:@"Previous Balance"];
    if ([BunbleName containsString:@"Shilaj"]) {
        [arrPayMentList addObject:@"Admission Fees"];
    }
    [arrPayMentList addObject:@"Caution Money"];
    [arrPayMentList addObject:@"Tution Fees"];
    [arrPayMentList addObject:@"Transport Fees"];
    [arrPayMentList addObject:@"Imprest"];
    if ([BunbleName containsString:@"Bhadaj"]) {
        [arrPayMentList addObject:@"Food Fees"];
        [arrPayMentList addObject:@"Term Fees"];
    }
    [arrPayMentList addObject:@"Late Fees"];
    [arrPayMentList addObject:@"Discount"];
    [arrPayMentList addObject:@"Total Payable Fees"];
    [arrPayMentList addObject:@"Paid Fees"];
    [arrPayMentList addObject:@"Balance"];
}

#pragma mark -
#pragma mark - SideMenu Icon And Title Dict Method

-(NSMutableDictionary *)getDictfromTitle:(NSString *)title
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setObject:title forKey:@"title"];
    return dict;
}

#pragma mark -
#pragma mark - TableView Delegate Method

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    //    return section == 0 ? 0 : section == 1 ? 90 : 50;
    return section == 0 ? 0 : arrPayMentSummaryList.count > 0 ? 90 : 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section > 0)
    {
        PayMentCell *cell = (PayMentCell *)[tableView dequeueReusableCellWithIdentifier:@"PayMentHeaderCell"];
        cell.contentView.subviews[0].layer.borderColor = [[UIColor lightGrayColor]CGColor];
        cell.contentView.subviews[0].layer.borderWidth = 0.5;
        
        return arrPayMentSummaryList.count > 0 ? cell.contentView : nil;
        
        /*CGRect rect = CGRectMake(0, 0, SHARED_APPDELEGATE.window.frame.size.width,55);
         SectionView *viewFit = [[SectionView alloc] initWithFrame:rect :@"PaymentSection"];
         viewFit.viewBack.layer.borderColor = [[UIColor lightGrayColor]CGColor];
         viewFit.viewBack.layer.borderWidth = 1.0;
         viewFit.dateDelegate = self;
         viewFit.index = (int)section;
         
         [viewFit.btnDetails setTransform:CGAffineTransformIdentity];
         viewFit.viewBack.layer.shadowColor   = [UIColor clearColor].CGColor;
         
         viewFit.topConstant.constant = 0.0;
         viewFit.lblTitle.text = nil;
         if (section == 1) {
         viewFit.topConstant.constant = 40.0;
         viewFit.lblTitle.text = @"Payment Summary :";
         }
         
         if (section == selectedSection) {
         
         viewFit.viewBack.layer.shadowRadius  = 3.0f;
         viewFit.viewBack.layer.shadowColor   = [[UIColor clearColor] colorWithAlphaComponent:0.3].CGColor;
         viewFit.viewBack.layer.shadowOffset  = CGSizeMake(0.0f, 3.0f);
         viewFit.viewBack.layer.shadowOpacity = 1.0f;
         viewFit.viewBack.layer.masksToBounds = NO;
         
         [UIView animateWithDuration:0.3f delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
         [viewFit.btnDetails setTransform:CGAffineTransformRotate(viewFit.btnDetails.transform, M_PI/2)];
         } completion:nil];
         }
         
         NSDictionary *dictData = [arrPayMentSummaryList objectAtIndex:section-1];
         [viewFit setSectionPaymentData:dictData];
         
         return viewFit;*/
    }else{
        //        CGRect rect = CGRectMake(0, 0, SHARED_APPDELEGATE.window.frame.size.width,IS_IPAD ? 50 : 40);
        //        SectionView *viewFit = [[SectionView alloc] initWithFrame:rect :@"PaymentHeaderSection"];
        //        return viewFit;
    }
    return nil;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //    return arrPayMentSummaryList.count > 0 ? [arrPayMentSummaryList count]+1 : 1;
    return 2;
}

//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
//{
//    return  section == 0 ? viewFooter.frame.size.height : 0;
//}
//
//-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    return  section == 0 ? viewFooter : nil;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return indexPath.row == arrPayMentList.count ? IS_IPAD ? 50 : 40 : IS_IPAD ? 40 : 30;
    }else {
        //        if(indexPath.section == selectedSection){
        //
        //            NSDictionary *dictData = [arrPayMentSummaryList objectAtIndex:indexPath.section-1];
        //            NSArray *arrsecton = [dictData safeObjectForKey:@"Data"];
        //            NSDictionary *dict = [arrsecton objectAtIndex:indexPath.row];
        //
        //            if ([BunbleName containsString:@"Bhadaj"])
        //            {
        //                if ([dict[@"PayMode"] isEqualToString:@"Cash"]) {
        //                    return IS_IPAD ? 315 : 280; //258
        //                }else{
        //                    return IS_IPAD ? 365 : 325; // 305
        //                }
        //            }else{
        //                if ([dict[@"PayMode"] isEqualToString:@"Cash"]) {
        //                    return IS_IPAD ? 340 : 305; //280
        //                }else{
        //                    return IS_IPAD ? 390 : 345; // 325
        //                }
        //            }
        //        }
        return UITableViewAutomaticDimension;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section > 0) {
        //        NSDictionary *dictData =[arrPayMentSummaryList objectAtIndex:section-1];
        //        NSArray *arrData =[dictData objectForKey:@"Data"];
        //        return selectedSection ? [arrData count] : 0;
        return arrPayMentSummaryList.count;
    }
    return [arrPayMentList count] > 0 ? [arrPayMentList count] + (isRowExtend ? 1 : 0) : 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    PayMentCell *cell = (PayMentCell *)[tableView dequeueReusableCellWithIdentifier:indexPath.section == 0 ? @"CellPayMent" : @"PayMentCell1"];
    
    if (indexPath.section == 0) {
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PayMentCell" owner:self options:nil];
            cell = [nib objectAtIndex:indexPath.row == arrPayMentList.count ? 5 : 0];
            cell.selectionStyle  = UITableViewCellSelectionStyleNone;
            
            if(indexPath.row == arrPayMentList.count) {
                int i = 0;
                for (UIView *view in cell.contentView.subviews[0].subviews) {
                    if([view isKindOfClass:[UIButton class]]){
                        UIButton *btn = (UIButton *)view;
                        btn.tag = i;
                        if(i == 0){
                            btn.hidden = !btnPay1Show;
                        }else{
                            btn.hidden = !btnPay2Show;
                        }
                        [btn addTarget:self action:@selector(btnFooter:) forControlEvents:UIControlEventTouchUpInside];
                        i += 1;
                    }
                }
            }else{
                [cell setPaymentDeta:arrTerm1[indexPath.row] :arrTerm2[indexPath.row] :arrPayMentList[indexPath.row]];
            }
        }
        return cell;
    }else {
        NSDictionary *dict = [arrPayMentSummaryList objectAtIndex:indexPath.row];
        [cell setPaymentReceiptData:dict :indexPath.row+1];
        [[[cell contentView]subviews]lastObject].tag = indexPath.row;
        return cell;
    }
    
    //            NSDictionary *dictData = [arrPayMentSummaryList objectAtIndex:indexPath.section-1];
    //            NSArray *arrsecton = [dictData safeObjectForKey:@"Data"];
    //            NSDictionary *dict = [arrsecton objectAtIndex:indexPath.row];
    //
    //            if ([BunbleName containsString:@"Bhadaj"])
    //            {
    //                if ([dict[@"PayMode"] isEqualToString:@"Cash"]) {
    //                    cell = [nib objectAtIndex:2];
    //                }else{
    //                    cell = [nib objectAtIndex:1];
    //                }
    //            }else{
    //                if ([dict[@"PayMode"] isEqualToString:@"Cash"]) {
    //                    cell = [nib objectAtIndex:4];
    //                }else{
    //                    cell = [nib objectAtIndex:3];
    //                }
    //            }
    
    //    if (indexPath.section == 0)
    //    {
    //        if ([arrPayMentList count] > indexPath.row) {
    //            //[cell setPaymentDeta:term1 term2Data:term2 andDetail:[arrPayMentList objectAtIndex:indexPath.row]];
    //            [cell setPaymentDeta:arrTerm1[indexPath.row] :arrTerm2[indexPath.row] :arrPayMentList[indexPath.row]];
    //        }
    //    }
    //    else
    //    {
    //        if(indexPath.section == selectedSection)
    //        {
    //            NSDictionary *dictData = [arrPayMentSummaryList objectAtIndex:indexPath.section-1];
    //            NSArray *arrsecton = [dictData safeObjectForKey:@"Data"];
    //            NSDictionary *dict = [arrsecton objectAtIndex:indexPath.row];
    //            [cell setPaymentSummaryData:dict];
    //        }
    //        else
    //        {
    //            [cell HideData];
    //        }
    //    }
}

-(IBAction)btnViewAction:(UIButton *)sender
{
    NSDictionary *dict = [arrPayMentSummaryList objectAtIndex:sender.tag];
    
    ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PaymentOnlineVC *povc = [storyBoard instantiateViewControllerWithIdentifier:@"PaymentOnlineVC"];
    povc.paymentUrl = [dict safeObjectForKey:@"URL"];
    povc.title = @"Fee Receipt";
    povc.transition = animation;
    [self.navigationController pushViewController:povc animated:YES];
}

-(IBAction)btnFooter:(UIButton *)sender
{
    ADTransition * animation = [[ADSlideTransition alloc] initWithDuration:0.8 orientation:ADTransitionRightToLeft sourceRect:self.view.frame];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PaymentOnlineVC *povc = [storyBoard instantiateViewControllerWithIdentifier:@"PaymentOnlineVC"];
    povc.paymentUrl = sender.tag == 0 ? strPayNow1 : strPayNow2;
    povc.title = @"Pay Online";
    povc.transition = animation;
    [self.navigationController pushViewController:povc animated:YES];
}

-(void)setDateAtindex:(int)index
{
    NSLog(@"Section Select: %d",index);
    
    if(index == selectedSection){
        selectedSection = -1;
    }else{
        selectedSection = index;
    }
    
    isTerm1Pay = isTerm2Pay = NO;
    //    [UIView performWithoutAnimation:^{
    //        [tblPayMent reloadSections:[NSIndexSet indexSetWithIndex:index] withRowAnimation:UITableViewRowAnimationNone];
    //    }];
    
    [tblPayMent reloadData];
    
    if (selectedSection != -1) {
        [tblPayMent scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:selectedSection] atScrollPosition:UITableViewScrollPositionTop animated:YES];
    }
}

-(void)viewWillDisappear:(BOOL)animated
{
    isTerm1Pay = isTerm2Pay = NO;
}

- (IBAction)onClickBackBtn:(id)sender {
    [[self navigationController]popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
