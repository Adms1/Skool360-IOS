//
//  ReportCardViewController.m
//  Skool360
//
//  Created by ADMS on 01/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "PaymentOnlineVC.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface PaymentOnlineVC ()

@end

@implementation PaymentOnlineVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"about:blank"]]];
    
    NSURL *websiteUrl = [NSURL URLWithString:self.paymentUrl];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:websiteUrl];
    [webView loadRequest:urlRequest];
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [actView startAnimating];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [actView stopAnimating];
    [actView setHidesWhenStopped:YES];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [actView stopAnimating];
    [actView setHidesWhenStopped:YES];
}

- (IBAction)onClickBackBtn:(id)sender {
    [[self navigationController]popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
