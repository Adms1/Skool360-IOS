//
//  PayMentViewController.h
//  Skool360
//
//  Created by Darshan on 13/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "PayMentCell.h"

@interface PayMentViewController : MasterViewController

{
    IBOutlet UIView *viewHeader;
    IBOutlet UIView *viewFooter;
    
    IBOutlet UITableView *tblPayMent;
    
    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    
    NSMutableArray *arrPayMentList;
    NSMutableArray *arrTerm1;
    NSMutableArray *arrTerm2;
    NSMutableArray *arrPayMentSummaryList;
    
    NSMutableDictionary *term1;
    NSMutableDictionary *term2;
    
    BOOL btnPay1Show;
    BOOL btnPay2Show;
    
    NSString *strPayNow1;
    NSString *strPayNow2;
}

@end
