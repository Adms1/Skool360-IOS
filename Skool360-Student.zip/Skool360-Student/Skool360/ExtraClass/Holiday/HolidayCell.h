//
//  HolidayCell.h
//  Holiday
//
//  Created by Fernando Sproviero on 30/06/14.
//  Copyright (c) 2014 FS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomLabel.h"

@interface HolidayCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *cellImageView;
@property (weak, nonatomic) IBOutlet CustomLabel *lblName;
@property (weak, nonatomic) IBOutlet CustomLabel *lblDate;
@property (weak, nonatomic) IBOutlet CustomLabel *lblDay;
@property (weak, nonatomic) IBOutlet CustomLabel *lblHolidayDate;
@property (weak, nonatomic) IBOutlet CustomLabel *lblEvent;
@property (weak, nonatomic) IBOutlet CustomLabel *lblEventDate;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *holidayheight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *eventHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *holidayEventCenter;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *eventBottom;

-(void)parallaxTheImageViewScrollOffset:(CGPoint)offsetPoint;
@end
