//
//  CustomImageView.h
//  Skool360
//
//  Created by ADMS on 18/01/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE

@interface CustomImageView : UIImageView

@property(nonatomic)IBInspectable NSString *strImageName;
@property(nonatomic)IBInspectable BOOL *isTemplate;

@end

@interface PlaceholderImageView : UIImageView
@property(nonatomic)IBInspectable NSString *strImageName;
@end
