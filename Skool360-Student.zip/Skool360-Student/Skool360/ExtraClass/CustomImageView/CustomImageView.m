//
//  CustomImageView.m
//  Skool360
//
//  Created by ADMS on 18/01/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "CustomImageView.h"
#import "UIImageView+GetLocalImage.h"

@implementation CustomImageView

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self getIconsfromLocal:self.strImageName : self.isTemplate];
}

@end

@implementation PlaceholderImageView

-(void)awakeFromNib{
    [super awakeFromNib];
    self.image = [[UIImage imageNamed:_strImageName == nil ? @"no record found" : _strImageName] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    self.tintColor = [UIColor lightGrayColor];
}
@end
