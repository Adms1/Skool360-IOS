//
//  CommonClass.m
//  Viewfoo
//
//  Created by MitulB on 22/05/15.
//  Copyright (c) 2015 com. All rights reserved.
//

#import "CommonClass.h"
#import "AppDelegate.h"
#import "ErrorPopupVC.h"
#import "HeaderView.h"
#import "LoginView.h"
//AppDelegate *appDelegate;

@implementation CommonClass

+ (void)errorAlert:(NSInteger)errorCode :(UIViewController *)superView
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ErrorPopupVC *vc = (ErrorPopupVC *)[storyBoard instantiateViewControllerWithIdentifier:@"ErrorPopupVC"];
    
    switch (errorCode) {
            case -1001:
            [[[UIAlertView alloc]initWithTitle:provideAlert message:timeOutError delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]show];
            break;
            
            case -1011: case - 1004:
            if([superView isKindOfClass:[LoginView classForCoder]]) {
                [[[UIAlertView alloc]initWithTitle:provideAlert message:serverError delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]show];
                return;
            }
            [superView addChildViewController:vc];
            [superView.view addSubview:vc.view];
            [vc.view setFrame:superView.view.bounds];
            [vc didMoveToParentViewController:superView];
            [vc.view.subviews[0].subviews[2] setHidden:[superView isKindOfClass:[HomeView classForCoder]]];
            break;
            
            case -1005: case - 1009:
            [[[UIAlertView alloc]initWithTitle:provideAlert message:internetFailure delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]show];
            break;
            
        default:
            [[[UIAlertView alloc]initWithTitle:provideAlert message:failureMsg delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]show];
            break;
    }
}

+ (NSString *)timeAgoStringFromDate:(NSString *)strDate {
    NSDate *date = [CommonClass getDateFromString:strDate :@"yyyy-MM-dd'T'HH:mm:ss.SSSS"];
    NSDateComponentsFormatter *formatter = [[NSDateComponentsFormatter alloc] init];
    formatter.unitsStyle = NSDateComponentsFormatterUnitsStyleFull;
    
    NSDate *now = [NSDate date];
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:(NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitWeekOfMonth|NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond)
                                               fromDate:date
                                                 toDate:now
                                                options:0];
    
    if (components.year > 0) {
        formatter.allowedUnits = NSCalendarUnitYear;
    } else if (components.month > 0) {
        formatter.allowedUnits = NSCalendarUnitMonth;
    } else if (components.weekOfMonth > 0) {
        formatter.allowedUnits = NSCalendarUnitWeekOfMonth;
    } else if (components.day > 0) {
        formatter.allowedUnits = NSCalendarUnitDay;
    } else if (components.hour > 0) {
        formatter.allowedUnits = NSCalendarUnitHour;
    } else if (components.minute > 0) {
        formatter.allowedUnits = NSCalendarUnitMinute;
    } else {
        formatter.allowedUnits = NSCalendarUnitSecond;
    }
    
    NSString *formatString = NSLocalizedString(@"%@ ago", @"Used to say how much time has passed. e.g. '2 hours ago'");
    
    return [NSString stringWithFormat:formatString, [formatter stringFromDateComponents:components]];
}

+ (NSString *)convertToDate:(NSString *)strDate :(NSString *)originalFormate :(NSString *)formate
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:originalFormate];
    NSDate *date = [dateFormat dateFromString:strDate];
    
    [dateFormat setDateFormat:formate];
    return [dateFormat stringFromDate:date];
}

/*
 +(CommonClass *)shareObject
 {
 appDelegate  = [AppDelegate sharedAppDelegate];
 static CommonClass *objComminClass = nil;
 static dispatch_once_t onceToken;
 dispatch_once(&onceToken, ^{
 objComminClass = [[CommonClass alloc]init];
 });
 return objComminClass;
 } */


+(NSString *)trimString:(NSString *)string
{
    return [string stringByTrimmingCharactersInSet:
            [NSCharacterSet whitespaceCharacterSet]];
}

+(NSString *) removeNull:(NSString *) string
{
    if (string.length == 0)
    {
        string = @"";
    }
    NSRange range = [string rangeOfString:@"null"];
    if (range.length > 0 || string == nil)
    {
        string = @"";
    }
    string = [self trimString:string];
    return string;
}

+(BOOL)complareTwoString:(NSString *)str1 :(NSString *)str2
{
    if (str1 == nil) {
        return NO;
    }
    if (str2 == nil) {
        return NO;
    }
    if([str1 caseInsensitiveCompare:str2] == NSOrderedSame) {
        return YES;
    }
    return NO;
}

+(NSString *) removeNull1:(NSString *) string
{
    if ([string isKindOfClass:[NSNull class]] || [string isEqualToString:@""])
    {
        string = @"-";
    }
    string = [self trimString:string];
    return string;
}

+ (void) showAlertWithTitle:(NSString *)title message:(NSString *)message {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:ok];
    
}
+(void)showAlertWithTitle:(NSString *)strTitle andMessage:(NSString *)strMessage delegate:(id)delegate
{
    UIAlertController *alertController = [UIAlertController
                                          alertControllerWithTitle:@""
                                          message:strMessage
                                          preferredStyle:UIAlertControllerStyleAlert];
    
    
    UIAlertAction *cancelAction = [UIAlertAction
                                   actionWithTitle:NSLocalizedString(@"OK", @"OK action")
                                   style:UIAlertActionStyleCancel
                                   handler:^(UIAlertAction *action)
                                   {
                                       NSLog(@"Cancel action");
                                       
                                   }];
    [alertController addAction:cancelAction];
    [delegate presentViewController:alertController animated:YES completion:nil];
}

+ (BOOL)textIsValidEmailFormat:(NSString *)text {
    
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:text];
}
+ (BOOL)validateUrl: (NSString *) candidate {
    NSString *urlRegEx =
    @"((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}
+(NSString *)getStringDateFromDate:(NSDate *)date
{
    /*
     NSDate* endDateLocal = [NSDate dateWithTimeInterval:[[NSTimeZone systemTimeZone] secondsFromGMT] sinceDate:curDate];
     NSTimeInterval seconds = [endDateLocal timeIntervalSinceDate:strDate];
     */
    NSDateFormatter *dateFromat = [[NSDateFormatter alloc]init];
    [dateFromat setDateFormat:@"MMM,dd yyyy"];
    NSString *strDate = [dateFromat stringFromDate:date];
    
    return strDate;
}

+(NSDate *)getDateFromString:(NSString *)strDate :(NSString *)formate
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:formate];
    NSDate *date = [dateFormatter dateFromString:strDate];
    
    return date;
}

+(NSString *)getStringDateFromString:(NSString *)strDate
{
    return @"sd";
}

+ (NSString*)generateFileNameWithExtension:(NSString *)extensionString
{
    // Extenstion string is like @".png"
    
    NSDate *time = [NSDate date];
    NSDateFormatter* df = [NSDateFormatter new];
    [df setDateFormat:@"dd-MM-yyyy-hh-mm-ss"];
    NSString *timeString = [df stringFromDate:time];
    int r = arc4random() % 100;
    int d = arc4random() % 100;
    NSString *fileName = [NSString stringWithFormat:@"File-%@%d%d%@", timeString, r , d , extensionString ];
    
    NSLog(@"FILE NAME %@", fileName);
    
    return fileName;
}

+ (NSString *)extractYoutubeIdFromLink:(NSString *)link {
    
    NSString *regexString = @"((?<=(v|V)/)|(?<=be/)|(?<=(\\?|\\&)v=)|(?<=embed/))([\\w-]++)";
    NSRegularExpression *regExp = [NSRegularExpression regularExpressionWithPattern:regexString
                                                                            options:NSRegularExpressionCaseInsensitive
                                                                              error:nil];
    
    NSArray *array = [regExp matchesInString:link options:0 range:NSMakeRange(0,link.length)];
    if (array.count > 0) {
        NSTextCheckingResult *result = array.firstObject;
        return [link substringWithRange:result.range];
    }
    return nil;
}

+ (CGFloat)getLabelHeight:(NSString *)str :(CGFloat)width
{
    CGSize constraint = CGSizeMake(width, CGFLOAT_MAX);
    CGSize size;
    
    NSStringDrawingContext *context = [[NSStringDrawingContext alloc] init];
    CGSize boundingBox = [str boundingRectWithSize:constraint
                                           options:NSStringDrawingUsesLineFragmentOrigin
                                        attributes:@{NSFontAttributeName:FONT_OpenSans(12)}
                                           context:context].size;
    
    size = CGSizeMake(ceil(boundingBox.width), ceil(boundingBox.height));
    
    return size.height;
}

+ (CGSize)getDynamicHeightOflbl:(UILabel *)lbl
{
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:lbl.text attributes:@ {NSFontAttributeName:lbl.font }]; CGRect rect = [attributedText boundingRectWithSize:(CGSize){lbl.frame.size.width, CGFLOAT_MAX}options:NSStringDrawingUsesLineFragmentOrigin context:nil]; CGSize size = rect.size;
    return size;
}

+ (NSAttributedString *)getHtmlString:(NSString *)htmlString
{
    NSAttributedString *attrStr = [[NSAttributedString alloc] initWithData:[htmlString dataUsingEncoding:NSUnicodeStringEncoding] options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType } documentAttributes:nil error:nil];
    
    NSMutableAttributedString *newStr = [attrStr
                                         mutableCopy];
    NSRange range;
    NSCharacterSet *set = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    range = [[newStr string]
             rangeOfCharacterFromSet:set];
    while (range.length != 0 && range.location == 0)
    {
        [newStr replaceCharactersInRange:range
                              withString:@""];
        range = [[newStr string]
                 rangeOfCharacterFromSet:set];
    }
    
    // Then clear them from the end
    range = [[newStr string] rangeOfCharacterFromSet:set
                                             options:NSBackwardsSearch];
    while (range.length != 0 && NSMaxRange(range) ==
           [newStr length])
    {
        [newStr replaceCharactersInRange:range
                              withString:@""];
        range = [[newStr string] rangeOfCharacterFromSet:set
                                                 options:NSBackwardsSearch];
    }
    
    return [[NSAttributedString alloc]
            initWithAttributedString:newStr];
}

+ (void)addShadow:(UIView *)view :(CGFloat)qty
{
    view.layer.shadowColor = [[[UIColor clearColor] colorWithAlphaComponent:0.2] CGColor];
    view.layer.shadowOffset = CGSizeMake(0.0f,qty);
    view.layer.shadowOpacity = 1.0f;
    view.layer.shadowRadius = qty;
}

+(void)getDynamicFont
{
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    NSURL *URL = [NSURL URLWithString:@"http://example.com/download.zip"];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
        NSURL *documentsDirectoryURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
        return [documentsDirectoryURL URLByAppendingPathComponent:[response suggestedFilename]];
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
        NSLog(@"File downloaded to: %@", filePath);
    }];
    [downloadTask resume];
}

@end
