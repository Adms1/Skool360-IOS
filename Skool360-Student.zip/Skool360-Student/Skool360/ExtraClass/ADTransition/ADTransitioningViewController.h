//
//  ADTransitioningViewController.h
//  ADTransitionController
//
//  Created by Patrick Nollet on 10/10/13.
//  Copyright (c) 2013 Applidium. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ADTransition.h"

@interface ADTransitioningViewController : UIViewController
@property (nonatomic, strong) ADTransition * transition;
@end
