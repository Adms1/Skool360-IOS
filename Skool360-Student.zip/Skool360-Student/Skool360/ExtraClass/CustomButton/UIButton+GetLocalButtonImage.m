//
//  UIButton+GetLocalButtonImage.m
//  Skool360
//
//  Created by ADMS on 18/01/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "UIButton+GetLocalButtonImage.h"
#import "AFImageRequestOperation.h"

@implementation UIButton (GetLocalButtonImage)

- (void)getImagesfromLocal:(NSString *)strImageName
{
    NSString *documentsDirectoryURL = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    
    NSString *fileUrl = [documentsDirectoryURL stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",strImageName]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:fileUrl]){
        [self setImage:[UIImage imageWithContentsOfFile:fileUrl] forState:0];
    }else{
        [self storeImages:fileUrl :[NSString stringWithFormat:@"%@.png",strImageName]];
    }
}

-(void)storeImages:(NSString *)imageUrl :(NSString *)imageName
{
    NSString *strImageUrlLink = [NSString stringWithFormat:@"%@%@",Icons_Url,[imageName stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:strImageUrlLink]];
    
    AFImageRequestOperation *operation = [AFImageRequestOperation imageRequestOperationWithRequest:request imageProcessingBlock:nil success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
        
        [self setImage:image forState:0];
        [UIImagePNGRepresentation(image) writeToFile:imageUrl atomically:YES];
        
    } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error) {
        NSLog(@"%@", [error localizedDescription]);
        
    }];
    
    [operation start];
}

@end
