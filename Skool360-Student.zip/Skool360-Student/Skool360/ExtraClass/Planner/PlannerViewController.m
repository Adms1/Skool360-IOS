//
//  PlannerViewController.m
//  Skool380Bhadaj
//
//  Created by ADMS on 02/08/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "PlannerViewController.h"
#import "PlannerCell.h"
#import "PlannerCCell.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "Holiday.h"

@interface PlannerViewController ()
{
    NSMutableArray *arrMonthName;
    NSMutableDictionary *dicData;
    NSArray *colors;
}
@end

@implementation PlannerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    lblPlannerYear.transform = CGAffineTransformMakeRotation(-M_PI_2);
    
    tblPlanner.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    tblPlanner.layer.borderWidth = 0.5;
    
    colors = @[presentColor, pendingColor, detaultColor, [UIColor magentaColor], absentColor, [UIColor brownColor], [UIColor orangeColor], [UIColor cyanColor], sectionSelectColor];
    
    [self callHolidayApi];
}

-(void)callHolidayApi
{
    arrMonthName = [[NSMutableArray alloc]init];
    dicData = [[NSMutableDictionary alloc]init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [manager POST:GetHoliday_Url parameters:@{@"StandardID" : [[NSUserDefaults standardUserDefaults] valueForKey:STANDARDID]} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrListHoliday = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dict in arrListHoliday) {
                
                [arrMonthName addObject:[dict safeObjectForKey:@"MonthName"]];
                
                if([lblPlannerYear.text isEqualToString:@""]){
                    lblPlannerYear.text = [NSString stringWithFormat:@"PLANNER %@ - %ld",[dict safeObjectForKey:@"Year"], [[dict safeObjectForKey:@"Year"]integerValue]+1];
                }
                
                NSMutableArray *arrHolidayData = [[NSMutableArray alloc]init];
                NSMutableArray *arrEventData = [[NSMutableArray alloc]init];
                
                for (NSDictionary *holidayDict in [dict safeObjectForKey:@"Data"]) {
                    
                    NSArray *arrHDate = [[holidayDict safeObjectForKey:@"HolidayDate"] componentsSeparatedByString:@"-"];
                    NSArray *arrEDate = [[holidayDict safeObjectForKey:@"EventDate"] componentsSeparatedByString:@"-"];
                    
                    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
                    [dateFormat setDateFormat:@"d"];
                    
                    Holiday *objHoliday = [[Holiday alloc] init];
                    Holiday *objEvent = [[Holiday alloc] init];
                    
                    if(![[holidayDict safeObjectForKey:@"HolidayDate"] isEqualToString:@"-"])
                    {
                        NSDate *date = [CommonClass getDateFromString:arrHDate[0] :@"dd/MM/yyyy"];
                        
                        // Holiday
                        objHoliday.strDay = [NSString stringWithFormat:@"%ld", (long)[[dateFormat stringFromDate:date] intValue]];
                        objHoliday.strHoliday = [holidayDict safeObjectForKey:@"Holiday"];
                        objHoliday.strHolidayDate = @"-";
                        
                        if(![arrHDate[0] isEqualToString:arrHDate[1]]) {
                            objHoliday.strHolidayDate = [NSString stringWithFormat:@"%@ - %@", [CommonClass convertToDate:arrHDate[0] :@"dd/MM/yyyy" :@"dd MMM"], [CommonClass convertToDate:arrHDate[1] :@"dd/MM/yyyy" :@"dd MMM"]];
                        }
                        [arrHolidayData addObject:objHoliday];
                    }
                    
                    if(![[holidayDict safeObjectForKey:@"EventDate"] isEqualToString:@"-"]){
                        
                        NSDate *date = [CommonClass getDateFromString:arrEDate[0] :@"dd/MM/yyyy"];

                        // Event
                        objEvent.strDay = [NSString stringWithFormat:@"%ld", (long)[[dateFormat stringFromDate:date] intValue]];
                        objEvent.strEvent = [holidayDict safeObjectForKey:@"Event"];
                        objEvent.strEventDate = @"-";
                        
                        if(![arrEDate[0] isEqualToString:arrEDate[1]]) {
                            objHoliday.strEventDate = [NSString stringWithFormat:@"%@ - %@", [CommonClass convertToDate:arrEDate[0] :@"dd/MM/yyyy" :@"dd MMM"], [CommonClass convertToDate:arrEDate[1] :@"dd/MM/yyyy" :@"dd MMM"]];
                        }
                        [arrEventData addObject:objEvent];
                    }
                }
                [dicData setObject:arrHolidayData forKey:[NSString stringWithFormat:@"H-%@",[dict safeObjectForKey:@"MonthName"]]];
                [dicData setObject:arrEventData forKey:[NSString stringWithFormat:@"E-%@",[dict safeObjectForKey:@"MonthName"]]];
            }
            [tblPlanner reloadData];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    PlannerCell *cell = (PlannerCell *)[tableView dequeueReusableCellWithIdentifier:@"PlannerHeaderCell"];
    return cell.contentView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray *hArray = dicData[[NSString stringWithFormat:@"H-%@",[arrMonthName objectAtIndex:indexPath.row]]];
    NSMutableArray *eArray = dicData[[NSString stringWithFormat:@"E-%@",[arrMonthName objectAtIndex:indexPath.row]]];
    
    CGSize expectedLabelSize = [[arrMonthName[indexPath.row] uppercaseString] sizeWithAttributes:@{NSFontAttributeName : FONT_Semibold(18)}];
    if(eArray.count == 0 && hArray.count == 0){
        return expectedLabelSize.width + 10;
    }else {
        if(eArray.count < hArray.count){
            return (hArray.count * 60) < expectedLabelSize.width + 10 ? expectedLabelSize.width + 10 : (hArray.count * 60);
        }else{
            return (eArray.count * 60) < expectedLabelSize.width + 10 ? expectedLabelSize.width + 10 : (eArray.count * 60);
        }
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrMonthName count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray *hArray = dicData[[NSString stringWithFormat:@"H-%@",[arrMonthName objectAtIndex:indexPath.row]]];
    NSMutableArray *eArray = dicData[[NSString stringWithFormat:@"E-%@",[arrMonthName objectAtIndex:indexPath.row]]];
    
    NSString *strIdentifier = @"PlannerCell";
    if(hArray.count == 0 && eArray.count == 0){
        strIdentifier = @"PlannerNoCell";
    }
    PlannerCell *cell = (PlannerCell *)[tableView dequeueReusableCellWithIdentifier:strIdentifier];
    
    cell.lblMonth.textColor = [colors objectAtIndex:indexPath.row%colors.count];
    cell.lblMonth.text = [arrMonthName[indexPath.row] uppercaseString];
    
    if(hArray.count == 0 && eArray.count == 0){
        return cell;
    }
    
    cell.collectionEvent.tag = indexPath.row+1;
    cell.collectionHoliday.tag = (indexPath.row+1) * 100;
    
    [cell.collectionEvent reloadData];
    [cell.collectionHoliday reloadData];
    
    return cell;
}

#pragma mark - UICollectionView Datasource/Delegate

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if(collectionView.tag < 100)
    {
        NSMutableArray *eArray = dicData[[NSString stringWithFormat:@"E-%@",[arrMonthName objectAtIndex:collectionView.tag-1]]];
        Holiday *event = [eArray objectAtIndex:indexPath.row];
        return CGSizeMake(collectionView.frame.size.width,[event.strEventDate isEqualToString:@"-"] ? 50 : 60);
    }
    else
    {
        NSMutableArray *hArray = dicData[[NSString stringWithFormat:@"H-%@",[arrMonthName objectAtIndex:(collectionView.tag/100)-1]]];
        Holiday *holiday = [hArray objectAtIndex:indexPath.row];
        return CGSizeMake(collectionView.frame.size.width,[holiday.strHolidayDate isEqualToString:@"-"] ? 50 : 60);
    }
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    NSInteger tag = collectionView.tag;
    if(tag > 99) {
        tag = tag/100;
    }
    NSMutableArray *hArray = dicData[[NSString stringWithFormat:@"H-%@",[arrMonthName objectAtIndex:tag-1]]];
    NSMutableArray *eArray = dicData[[NSString stringWithFormat:@"E-%@",[arrMonthName objectAtIndex:tag-1]]];
    return collectionView.tag < 100 ? eArray.count : hArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    PlannerCCell *cell = (PlannerCCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"PlannerCCell" forIndexPath:indexPath];
    if(collectionView.tag < 100)
    {
        NSMutableArray *eArray = dicData[[NSString stringWithFormat:@"E-%@",[arrMonthName objectAtIndex:collectionView.tag-1]]];
        Holiday *event = [eArray objectAtIndex:indexPath.row];
        cell.lblDay.text = event.strDay;
        cell.lblHolidayEvent.text = event.strEvent;
        cell.lblHolidayEventDate.text = event.strEventDate;
        cell.lblHolidayEventDate.textColor = [event.strEventDate isEqualToString:@"-"] ? [UIColor clearColor] : [UIColor lightGrayColor];
    }
    else
    {
        NSMutableArray *hArray = dicData[[NSString stringWithFormat:@"H-%@",[arrMonthName objectAtIndex:(collectionView.tag/100)-1]]];
        Holiday *holiday = [hArray objectAtIndex:indexPath.row];
        cell.lblDay.text = holiday.strDay;
        cell.lblHolidayEvent.text = holiday.strHoliday;
        cell.lblHolidayEventDate.text = holiday.strHolidayDate;
        cell.lblHolidayEventDate.textColor = [holiday.strHolidayDate isEqualToString:@"-"] ? [UIColor clearColor] : [UIColor lightGrayColor];
    }
    return cell;
}
@end
