//
//  HolidayCell.h
//  Holiday
//
//  Created by Fernando Sproviero on 30/06/14.
//  Copyright (c) 2014 FS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlannerCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblMonth;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionHoliday;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionEvent;

@end
