//
//  JTCalendarScrollManager.m
//  JTCalendar
//
//  Created by Jonathan Tribouharet
//

#import "JTCalendarScrollManager.h"

@implementation JTCalendarScrollManager

- (void)setMenuPreviousDate:(NSDate *)previousDate
                currentDate:(NSDate *)currentDate
                   nextDate:(NSDate *)nextDate
{
    if(!_menuView){
        return;
    }
    
    [_menuView setPreviousDate:previousDate currentDate:currentDate nextDate:nextDate];
}

- (void)updateMenuContentOffset:(CGFloat)percentage pageMode:(NSUInteger)pageMode
{
    if(!_menuView){
        return;
    }
    
    [_menuView updatePageMode:pageMode];
    _menuView.scrollView.contentOffset = CGPointMake(percentage * _menuView.scrollView.contentSize.width, 0);
}

- (void)updateHorizontalContentOffset:(CGFloat)percentage
{
    if(!_horizontalContentView){
        return;
    }
    
    _horizontalContentView.contentOffset = CGPointMake(percentage * _horizontalContentView.contentSize.width, 0);
}

-(void)updateVerticalContentOffset:(CGFloat)percentage
{
    //NSLog(@"%@",_horizontalContentView);
    if(_horizontalContentView.contentOffset.x < 100 && _horizontalContentView.contentOffset.y < 100){
        return;
    }
    _horizontalContentView.contentOffset = CGPointMake(0, _horizontalContentView.contentSize.width);
}
-(void)updateVerticalNext
{
    //NSLog(@"%@",_horizontalContentView);
    _horizontalContentView.contentOffset = CGPointMake(_horizontalContentView.contentSize.width -_horizontalContentView.frame.size.width , 0);

}

@end
