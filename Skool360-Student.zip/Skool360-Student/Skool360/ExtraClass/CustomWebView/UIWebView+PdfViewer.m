//
//  UIWebView+PdfViewer.m
//  Shilaj (Student)
//
//  Created by ADMS on 20/06/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "UIWebView+PdfViewer.h"

@implementation UIWebView (PdfViewer)

-(void)downloadPdf:(NSString *)fileName
{
    NSString *documentsDirectoryURL = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    
    NSString *fileUrl = [documentsDirectoryURL stringByAppendingPathComponent:[NSString stringWithFormat: @"%@", [[fileName componentsSeparatedByString:@"PDFFiles/"]lastObject]]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:fileUrl]){
        NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL fileURLWithPath:fileUrl]];
        [self loadRequest:request];
    }else{
        [self downloadPdf:fileName :fileUrl];
    }
}

-(void)downloadPdf:(NSString *)fileName :(NSString *)filePath
{
    NSData *datapdf = [NSData dataWithContentsOfURL:[NSURL URLWithString:[fileName stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
    if(datapdf)
        [datapdf writeToFile:filePath atomically:YES];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL fileURLWithPath:filePath]];
    [self loadRequest:request];
}
@end
