//
//  NIDropUpCell.m
//  Skool360
//
//  Created by Darshan on 29/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "NIDropUpCell.h"

@implementation NIDropUpCell

@synthesize lblYearMonth;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
