//
//  MasterViewController.h
//  GTUPapers
//
//  Created by My Mac on 4/11/16.
//  Copyright (c) 2016 Darshan Jolapara. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "VKSideMenu.h"

#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:(v) options:NSNumericSearch] != NSOrderedAscending)

//#import "HomeView.h"
//#import "MyProfileView.h"
//#import "AttendanceView.h"
#import "ADTransitionController.h"

@class HomeView;
@class MyProfileView;
@class AttendanceView;

@interface MasterViewController : ADTransitioningViewController <VKSideMenuDelegate, VKSideMenuDataSource>

{
    //HomeView *objHomeView;
    //MyProfileView *objProfileView;
    //AttendanceView *objAttendanceView;
}
@property (nonatomic, strong) VKSideMenu *menuRight;

@property (strong , nonatomic) NSMutableArray *arrMenuList;

-(void)clickToggle;

@end
