//
//  PrincipalCell.h
//  Skool360
//
//  Created by ADMS on 07/09/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TTTAttributedLabel.h"

@interface PrincipalCell : UITableViewCell
{
    IBOutlet UIImageView *imgPrincipal;
    IBOutlet UILabel *lblPrincipalName;
    IBOutlet UILabel *lblPrincipalPost;
    
}
@property(nonatomic,retain)IBOutlet TTTAttributedLabel *lblPrincipalDes;
-(void)setData:(NSDictionary *)dic;
@end
