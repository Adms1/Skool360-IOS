//
//  ParentVC.m
//  Skool360
//
//  Created by ADMS on 14/08/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import "ParentVC.h"
#import "NIDropDown.h"
#import "AppDelegate.h"
#import "CommonClass.h"

@interface ParentVC ()<NIDropDownDelegate>
{
    NIDropDown *dropDown;
    NSMutableDictionary *dicStandards;
    NSMutableDictionary *dicSections;
    NSMutableDictionary *dicStudents;
    
    NSMutableArray *arrStandards;
    NSMutableArray *arrSections;
    NSMutableArray *arrSectionIds;
    NSMutableArray *arrStudents;
    
    NSString *strStdId;
    NSString *strSectionId;
    NSString *strStudent;
}
@end

@implementation ParentVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    btnStd.layer.borderWidth = 1.0f;
    btnStd.layer.borderColor = imprestBackColor.CGColor;
    
    btnSection.layer.borderWidth = 1.0f;
    btnSection.layer.borderColor = imprestBackColor.CGColor;
    
    btnStudent.layer.borderWidth = 1.0f;
    btnStudent.layer.borderColor = imprestBackColor.CGColor;
    
    btnDone.layer.cornerRadius = 2.0f;
    btnClose.layer.cornerRadius = btnClose.frame.size.width/2;
    
    [self getGradeSection];
}

-(void)viewWillAppear:(BOOL)animated
{
    strStudent = @"";
    strStdId = @"";
    strSectionId = @"";
    
    UIView *mainView = self.view.subviews[0].subviews[0];
    mainView.layer.cornerRadius = 10.0;
    mainView.transform = CGAffineTransformMakeScale(0.1, 0.1);
    mainView.layer.cornerRadius = 5.0;
    
    [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        mainView.transform = CGAffineTransformMakeScale(1.0, 1.0);
    } completion:nil];
    
    btnClose.transform = CGAffineTransformMakeScale(0.1, 0.1);
    [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        btnClose.transform = CGAffineTransformMakeScale(1.0, 1.0);
    } completion:nil];
}

-(void)getGradeSection
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    dicStandards = [[NSMutableDictionary alloc]init];
    dicSections = [[NSMutableDictionary alloc]init];
    arrStandards = [[NSMutableArray alloc]init];
    
    [manager POST:GetStandardSection_Url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrData = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *stdDict in arrData) {
                [dicStandards setValue:[stdDict safeObjectForKey:@"StandardID"] forKey:[stdDict safeObjectForKey:@"Standard"]];
                [arrStandards addObject:[stdDict safeObjectForKey:@"Standard"]];
                
                NSMutableArray *array = [[NSMutableArray alloc]init];
                for (NSDictionary *secDict in [stdDict safeObjectForKey:@"SectionDetail"]) {
                    [array addObject:[NSString stringWithFormat:@"%@/%@",[secDict safeObjectForKey:@"Section"], [secDict safeObjectForKey:@"SectionID"]]];
                }
                [dicSections setValue:array forKey:[stdDict safeObjectForKey:@"Standard"]];
            }
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)getStudentList
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    dicStudents = [[NSMutableDictionary alloc]init];
    
    NSDictionary *params = @{
                             @"StandrdID" : strStdId,
                             @"ClassID" : strSectionId
                             };
    
    [manager POST:StudentList_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrData = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dict in arrData) {
                [dicStudents setValue:[NSString stringWithFormat:@"%@/%@/%@/%@/%@/%@", [dict safeObjectForKey:@"ClassID"], [dict safeObjectForKey:@"FamilyID"], [dict safeObjectForKey:@"StandardID"], [dict safeObjectForKey:@"StudentID"], [dict safeObjectForKey:@"TermID"], [dict safeObjectForKey:@"RegisterStatus"]] forKey:[dict safeObjectForKey:@"StudentName"]];
            }
            NSSortDescriptor* sortOrder = [NSSortDescriptor sortDescriptorWithKey: @"self" ascending: YES];
            arrStudents = [[dicStudents allKeys] sortedArrayUsingDescriptors: [NSArray arrayWithObject: sortOrder]];
        }else{
            arrStudents = [[NSMutableArray alloc]init];
        }
        [[self.view viewWithTag:30]removeFromSuperview];
        [self onClickBtnActions:btnStudent];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (IBAction)onClickBtnActions:(UIButton *)sender {
    
    if(sender.tag != 0)
    {
        NSMutableArray *array = [[NSMutableArray alloc]init];
        switch (sender.tag) {
            case 1:
                array = arrStandards;
                break;
            case 2:
                array = arrSections;
                break;
            default:
                array = arrStudents;
                break;
        }
        
        if(dropDown == nil) {
            CGFloat f = array.count > 4 ? 120 : array.count * 30;
            dropDown = [[NIDropDown alloc]showDropDown:sender :&f :array :nil :@"down"];
            dropDown.tag = sender.tag * 10;
            dropDown.delegate = self;
        }
        else {
            [dropDown hideDropDown:sender];
            [self rel];
        }
    }
    else
    {
        if([strStdId isEqualToString:@""])
        {
            [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please select standard" delegate:self];
            return;
        }
        else if([strSectionId isEqualToString:@""])
        {
            [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please select section" delegate:self];
            return;
        }
        else if([strStudent isEqualToString:@""])
        {
            [CommonClass showAlertWithTitle:provideAlert andMessage:@"Please select student" delegate:self];
            return;
        }
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        
        NSArray *array = [strStudent componentsSeparatedByString:@"/"];
        [userDefault setObject:array[0] forKey:PASSWORD]; // ClassID
        [userDefault setObject:array[1] forKey:FAMILYID]; //FamilyID
        [userDefault setObject:array[2] forKey:STANDARDID]; //StandardID
        [userDefault setObject:array[3] forKey:STUDENTID]; //StudentID
        [userDefault setObject:array[4] forKey:TERMID]; //TermID
        [userDefault setObject:array[5] forKey:ISREGISTER]; //RegisterStatus
        [[NSUserDefaults standardUserDefaults] setObject:@"NO" forKey:@"ISLOGIN"];
        
        [userDefault synchronize];
        
        UIView *mainView = self.view.subviews[0].subviews[0];
        mainView.transform = CGAffineTransformMakeScale(1.0, 1.0);
        
        [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            mainView.transform = CGAffineTransformMakeScale(0.01, 0.01);
        } completion:^(BOOL finished) {
            [self.view removeFromSuperview];
            [self removeFromParentViewController];
            
            [SHARED_APPDELEGATE createAccountOrLogin];
        }];
    }
}

-(IBAction)btnClose:(UIButton *)sender
{
    sender.transform = CGAffineTransformMakeScale(1.0, 1.0);
    
    [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        sender.transform = CGAffineTransformMakeScale(0.1, 0.1);
    } completion:nil];
    
    UIView *mainView = self.view.subviews[0].subviews[0];
    mainView.transform = CGAffineTransformMakeScale(1.0, 1.0);
    
    [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        mainView.transform = CGAffineTransformMakeScale(0.1, 0.1);
    } completion:^(BOOL finished) {
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }];
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender :(NSInteger)index{
    [self rel];
    
    NSMutableArray *array = [[NSMutableArray alloc]init];
    switch (sender.tag) {
        case 10:
            strStdId = [dicStandards valueForKey:arrStandards[index]];
            array = [dicSections valueForKey:arrStandards[index]];
            
            arrSections = [[NSMutableArray alloc]init];
            arrSectionIds = [[NSMutableArray alloc]init];
            
            for (NSString *item in array) {
                [arrSections addObject:[[item componentsSeparatedByString:@"/"]firstObject]];
                [arrSectionIds addObject:[[item componentsSeparatedByString:@"/"]lastObject]];
            }
            
            [[self.view viewWithTag:20]removeFromSuperview];
            if(![arrSections containsObject:[NSString stringWithFormat:@"%@",[btnSection titleForState:0]]]){
                strSectionId = @"";
                [btnSection setTitle:@"Please select" forState:0];
            }
            [self onClickBtnActions:btnSection];
            
            // student dropdown reset
            arrStudents = [[NSMutableArray alloc]init];
            [[self.view viewWithTag:30]removeFromSuperview];
            [btnStudent setTitle:@"Please select" forState:0];
            strStudent = @"";
            [self onClickBtnActions:btnStudent];
            break;
            
        case 20:
            strSectionId = [arrSectionIds objectAtIndex:index];
            strStudent = @"";
            [self getStudentList];
            break;
            
        default:
            strStudent = [dicStudents valueForKey:[arrStudents objectAtIndex:index]];
            break;
    }
}

-(void)rel{
    dropDown = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
