//
//  ParentVC.h
//  Skool360
//
//  Created by ADMS on 14/08/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface ParentVC : MasterViewController
{
    IBOutlet UIButton *btnStd;
    IBOutlet UIButton *btnSection;
    IBOutlet UIButton *btnStudent;
    IBOutlet UIButton *btnDone;
    IBOutlet UIButton *btnClose;
}
@end
