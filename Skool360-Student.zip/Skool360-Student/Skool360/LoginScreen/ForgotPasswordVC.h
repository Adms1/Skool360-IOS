//
//  ForgotPasswordVC.h
//  Bhadaj (Student)
//
//  Created by ADMS on 17/07/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgotPasswordVC : UIViewController
{
    IBOutlet UIButton *btnForgotPassword;
    IBOutlet UIButton *btnClose;
    IBOutlet UILabel *lblInfo;
    IBOutlet UITextField *txtCommunicationNo;
}
@end
