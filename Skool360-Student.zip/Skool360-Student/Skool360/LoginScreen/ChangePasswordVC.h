//
//  ForgotPasswordVC.h
//  Bhadaj (Student)
//
//  Created by ADMS on 17/07/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangePasswordVC : UIViewController
{
    IBOutlet UIButton *btnChangePassword;
    IBOutlet UITextField *txtNewPassword;
    IBOutlet UITextField *txtConfirmPassword;
}
@end
