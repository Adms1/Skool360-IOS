//
//  LoginView.h
//  Skool360
//
//  Created by Darshan on 23/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"

@interface LoginView : UIViewController

{
    IBOutlet UITextField *txtUserName;
    IBOutlet UITextField *txtPassword;
    
    IBOutlet UIButton *btnRemember;
    IBOutlet UIButton *btnLogin;
    
    IBOutlet UILabel *lblTitle;
}

@end
