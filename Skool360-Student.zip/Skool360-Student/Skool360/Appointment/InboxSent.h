//
//  InboxSent.h
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InboxSent : NSObject

@property (nonatomic , strong) NSString *ReadStatus;
@property (nonatomic , strong) NSString *UserName;
@property (nonatomic , strong) NSString *FromID;
@property (nonatomic , strong) NSString *ToID;
@property (nonatomic , strong) NSString *MessageID;
@property (nonatomic , strong) NSString *SubjectLine;
@property (nonatomic , strong) NSString *MeetingDate;
@property (nonatomic , strong) NSString *Description;
@end
