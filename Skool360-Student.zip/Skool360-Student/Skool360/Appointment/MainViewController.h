//
//  MainViewController.h
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"

@interface MainViewController : MasterViewController
{
    IBOutlet UICollectionView *tabCollection;
    IBOutlet NSLayoutConstraint *constantViewWidth;
    IBOutlet NSLayoutConstraint *constantViewLeft;
}
@end

