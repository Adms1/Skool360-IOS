//
//  InboxSent.m
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "InboxSent.h"

@implementation InboxSent

@synthesize ReadStatus, SubjectLine, UserName, MessageID, FromID, ToID, Description, MeetingDate;
@end
