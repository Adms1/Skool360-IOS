//
//  SentInboxCell.m
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "SentInboxCell.h"

@implementation SentInboxCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    for (UIView *view in self.contentView.subviews[0].subviews[0].subviews) {
        for (UIView *view1 in self.contentView.subviews[0].subviews[1].subviews) {
            UILabel *lbl = (UILabel *)view1;
            lbl.font = FONT_OpenSans(IS_IPAD ? 16 : 13);
        }
        UILabel *lbl = (UILabel *)view;
        lbl.font = FONT_Semibold(IS_IPAD ? 16 : 13);
    }
    
//    for (UIView *view in self.contentView.subviews[0].subviews[1].subviews) {
//        UILabel *lbl = (UILabel *)view;
//        lbl.font = FONT_OpenSans(IS_IPAD ? 16 : 13);
//    }
}

-(void)displayHeaderData:(InboxSent *)data
{
    _lblUserName.text = data.UserName;
    _lblSubjectLine.text = data.SubjectLine;
    _lblMeetingDate.text = data.MeetingDate;
    
    for (UIView *view in self.contentView.subviews[0].subviews[1].subviews) {
        UILabel *lbl = (UILabel *)view;
        if (lbl.tag != 1) {
            if([data.ReadStatus isEqualToString:@"Pending"]){
                lbl.font = FONT_Semibold(IS_IPAD ? 16 : 13);
            }else{
                lbl.font = FONT_OpenSans(IS_IPAD ? 16 : 13);
            }
        }
    }
}

-(void)displayData:(InboxSent *)data
{
    _lblDescription.text = data.Description;
}

-(IBAction)btnDelete:(UIButton *)sender
{
    [[self delegate]deleteRequest:sender];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
