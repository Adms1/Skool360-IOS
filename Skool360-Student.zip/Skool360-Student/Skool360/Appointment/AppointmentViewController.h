//
//  AppointmentViewController.h
//  Skool360
//
//  Created by Darshan on 02/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "MasterViewController.h"
#import "NIDropDown.h"

@interface AppointmentViewController : UIViewController<NIDropDownDelegate>

{
    IBOutlet UIView *viewtitle;
    IBOutlet UIView *viewDescription;
    IBOutlet UIView *viewDatePicker;
    IBOutlet UIView *viewToolBar;
    
    IBOutlet UIScrollView *scrollV;
    
    IBOutlet UIImageView *imgLogo;
    
    IBOutlet UIButton *btnSideMenu;
    IBOutlet UIButton *btnBack;
    IBOutlet UIButton *btnSave;
    IBOutlet UIButton *btnCancel;
    IBOutlet UIButton *btnRequest;
    IBOutlet UIButton *btnSelectDate;
    IBOutlet UIButton *btnDone;
    IBOutlet UIButton *btnPickerDateCancel;
    
    
    IBOutlet UITextField *txtPurpose;
    
    IBOutlet UITextView *txvDescription;
    
    NIDropDown *dropDown;
        
    NSString *strAppointmentDate;
    NSString *strRequestID;
}

@end
