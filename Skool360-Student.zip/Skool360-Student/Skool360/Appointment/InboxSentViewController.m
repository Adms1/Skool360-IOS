//
//  InboxSentViewController.m
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "InboxSentViewController.h"
#import "AppDelegate.h"
#import "CommonClass.h"
#import "InboxSent.h"
#import "SentInboxCell.h"

@interface InboxSentViewController ()<SentInboxCellDelegate>
{
    NSMutableArray *arrInboxSentData;
    NSInteger selectedIndex;
}
@end

@implementation InboxSentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    selectedIndex = -1;
    tblSentReceiveReq.tableFooterView = [UIView new];
    
    tblSentReceiveReq.estimatedRowHeight = 120;
    tblSentReceiveReq.rowHeight = UITableViewAutomaticDimension;
    
    tblSentReceiveReq.estimatedSectionHeaderHeight = 50;
    tblSentReceiveReq.sectionHeaderHeight = UITableViewAutomaticDimension;
    
    [self callInboxSentApi];
}

-(void)viewWillAppear:(BOOL)animated
{
    [lblNoDataFound setHidden:YES];
    [self callInboxSentApi];
}

-(void)callInboxSentApi
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    [params setObject:strStudentID forKey:@"UserID"];
    [params setObject:@"Student" forKey:@"UserType"];
    [params setObject:[self.title isEqualToString:@"Inbox"] ? @"Inbox" : @"Sent" forKey:@"MessgaeType"];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:PTMTeacherStudentGetDetail_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        arrInboxSentData = [[NSMutableArray alloc]init];
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            NSMutableArray *arrListRequest = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dic in arrListRequest)
            {
                InboxSent *is = [[InboxSent alloc]init];
                
                is.ReadStatus = dic[@"ReadStatus"];
                is.UserName = dic[@"UserName"];
                is.FromID = dic[@"FromID"];
                is.ToID = dic[@"ToID"];
                is.SubjectLine = dic[@"SubjectLine"];
                is.MessageID = dic[@"MessageID"];
                is.MeetingDate = dic[@"MeetingDate"];
                is.Description = dic[@"Description"];
                
                [arrInboxSentData addObject:is];
            }
        }else{
            [lblNoDataFound setHidden:NO];
        }
        [tblSentReceiveReq reloadData];
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

-(void)callDeleteRequestApi:(NSInteger)index
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    [params setObject:((InboxSent *)[arrInboxSentData objectAtIndex:index]).MessageID forKey:@"MessageID"];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:PTMDeleteMeeting_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            [arrInboxSentData removeObjectAtIndex:index];
            selectedIndex = -1;
            [tblSentReceiveReq reloadData];
        }
        [SHARED_APPDELEGATE hideLoadingView];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    SentInboxCell *headerView = (SentInboxCell *)[tableView dequeueReusableCellWithIdentifier:@"SentInboxHeaderCell"];
    
    [CommonClass addShadow:headerView.contentView.subviews[0].subviews[1] :2.0];
    
    if(section > 0){
        headerView.viewHeight.constant = -5.0;
        headerView.contentView.subviews[0].subviews[0].hidden = YES;
    }else{
        headerView.viewHeight.constant = 35.0;
        headerView.contentView.subviews[0].subviews[0].hidden = NO;
    }
    
    if(section == selectedIndex) {
        headerView.lblView.textColor = TextBgColor;
    }else {
        headerView.lblView.textColor = [UIColor redColor];
    }
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(expandCollapseSection:)];
    headerView.lblView.tag = section;
    [headerView.lblView addGestureRecognizer:tapGesture];
    
    [headerView displayHeaderData:arrInboxSentData[section]];
    return headerView.contentView;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == selectedIndex) {
        return UITableViewAutomaticDimension;
    }
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    tblSentReceiveReq.estimatedSectionHeaderHeight = (section == 0 ? 90 : 50);
    return UITableViewAutomaticDimension;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return arrInboxSentData.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *strIdentifier = @"SentCell";
    if([self.title isEqualToString:@"Inbox"]) {
        strIdentifier = @"InboxCell";
    }
    
    SentInboxCell *cell = (SentInboxCell *)[tableView dequeueReusableCellWithIdentifier:strIdentifier forIndexPath:indexPath];
    if ([self.title isEqualToString:@"Sent"])
    {
        cell.btnDelete.tag = indexPath.section;
        cell.delegate = self;
    }
    [cell displayData:arrInboxSentData[indexPath.section]];
    return cell;
}

-(void)deleteRequest:(UIButton *)sender
{
    [self callDeleteRequestApi:sender.tag];
}

-(void)expandCollapseSection:(UITapGestureRecognizer *)gesture
{
    NSInteger Index = gesture.view.tag;
    if(selectedIndex == Index) {
        selectedIndex = -1;
    }
    else {
        selectedIndex = Index;
    }
    
    InboxSent *is = arrInboxSentData[Index];
    if ([is.ReadStatus isEqualToString:@"Pending"] && [self.title isEqualToString:@"Inbox"])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
        
        [SHARED_APPDELEGATE showLoadingView];
        
        [params setObject:@"Staff" forKey:@"Flag"];
        [params setObject:is.MessageID forKey:@"MessageID"];
        [params setObject:is.FromID forKey:@"FromID"];
        [params setObject:is.ToID forKey:@"ToID"];
        [params setObject:is.MeetingDate forKey:@"MeetingDate"];
        [params setObject:is.SubjectLine forKey:@"SubjectLine"];
        [params setObject:is.Description forKey:@"Description"];
        
        NSLog(@"params>>> %@",params);
        
        [manager POST:PTMTeacherStudentInsertDetail_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSLog(@"ResponceLogin %@",responseObject);
            
            if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
                
                is.ReadStatus = @"Read";
                [arrInboxSentData replaceObjectAtIndex:Index withObject:is];
            }
            [self refreshTableData];
            [SHARED_APPDELEGATE hideLoadingView];
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [CommonClass errorAlert:error.code :self];

            [SHARED_APPDELEGATE hideLoadingView];
            NSLog(@"Error: %@", error);
        }];
    }
    [self refreshTableData];
}

-(void)refreshTableData
{
    [tblSentReceiveReq reloadData];
    
    if (selectedIndex != -1) {
        [tblSentReceiveReq scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:selectedIndex] atScrollPosition:UITableViewScrollPositionNone animated:YES];
    }
}
@end

