//
//  MainViewController.m
//  Skool360
//
//  Created by ADMS on 03/10/17.
//  Copyright © 2017 Darshan. All rights reserved.
//

#import "MainViewController.h"
#import "SuggestionViewController.h"
#import "InboxSentSViewController.h"

@interface TabCell:UICollectionViewCell
@property(nonatomic,retain)IBOutlet UILabel *lblTitle;
@end

@implementation TabCell

-(void)awakeFromNib{
    [super awakeFromNib];
    self.lblTitle.font = FONT_Semibold(IS_IPAD ? 20 : 15);
}

@end

@interface MainViewController ()<UIPageViewControllerDelegate,UIPageViewControllerDataSource,UIScrollViewDelegate>
{
    UICollectionView *tabCollectionView;
    NSInteger currentPage;
    NSArray *tabBarTitle;
    NSMutableArray *views;
    UIPageViewController *pageController;
}
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tabBarTitle = @[@"Inbox", @"Sent", @"Create"];
    views = [self ptnViewControllers];
    
    constantViewWidth.constant = self.view.bounds.size.width/tabBarTitle.count;
}

-(void)viewWillAppear:(BOOL)animated
{
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]firstObject]) setTitle:self.title.uppercaseString forState:0];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:1]) addTarget:self action:@selector(onClickSideMenuBtn:) forControlEvents:UIControlEventTouchUpInside];
    [((UIButton *)[[[[[[[self view] subviews]firstObject]subviews]firstObject]subviews]objectAtIndex:2]) addTarget:self action:@selector(onClickBackBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    //[[self view]layoutIfNeeded];
    
    CGFloat pointY = self.view.subviews[1].frame.size.height + self.view.subviews[1].frame.origin.y + 5.0;
    
    [[self.view subviews]objectAtIndex:1].layer.shadowColor = [[[UIColor clearColor]colorWithAlphaComponent:0.2]CGColor];
    [[self.view subviews]objectAtIndex:1].layer.shadowRadius = 2.0;
    [[self.view subviews]objectAtIndex:1].layer.shadowOffset = CGSizeMake(0.0, 2.0);
    [[self.view subviews]objectAtIndex:1].layer.shadowOpacity = 1.0;
    
    [self createPageViewController:pointY];
}

-(NSMutableArray *)ptnViewControllers
{
    NSMutableArray *viewControllers = [[NSMutableArray alloc]init];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    for (int i = 0; i < tabBarTitle.count - 1; i++)
    {
        InboxSentSViewController *isvc = [storyBoard instantiateViewControllerWithIdentifier:@"InboxSentSViewController"];
        isvc.title = tabBarTitle[i];
        [viewControllers addObject:isvc];
    }
    SuggestionViewController *svc = [storyBoard instantiateViewControllerWithIdentifier:@"SuggestionViewController"];
    [viewControllers addObject:svc];
    
    return viewControllers;
}

-(void)createPageViewController:(CGFloat)pointY
{
    pageController = [[UIPageViewController alloc]initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
    
    pageController.view.backgroundColor = [UIColor clearColor];
    pageController.delegate = self;
    pageController.dataSource = self;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 0.11 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        
        pageController.view.frame = CGRectMake(0, pointY, self.view.frame.size.width, self.view.frame.size.height-pointY);
    });
    
    [pageController setViewControllers:@[views.firstObject] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    
    [self addChildViewController:pageController];
    [self.view addSubview:pageController.view];
    [pageController didMoveToParentViewController:self];
    
    for (UIView *v in pageController.view.subviews) {
        if ([v isKindOfClass:[UIScrollView class]]) {
            ((UIScrollView *)v).delegate = self;
        }
    }
}

#pragma mark - UICollectionView Datasource/Delegate

-(NSInteger)indexofviewController:(UIViewController *)viewController
{
    if([views containsObject:viewController]){
        return [views indexOfObject:viewController];
    }
    return -1;
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    NSInteger index = [self indexofviewController:viewController];
    
    if (index != -1) {
        index = index - 1;
    }
    if(index < 0) {
        return nil;
    }
    else {
        return [views objectAtIndex:index];
    }
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    NSInteger index = [self indexofviewController:viewController];
    
    if (index != -1) {
        index = index + 1;
    }
    if(index >= views.count) {
        return nil;
    }
    else {
        return [views objectAtIndex:index];
    }
}

-(void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed
{
    if (completed) {
        currentPage = [views indexOfObject:pageController.viewControllers.lastObject];
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(self.view.bounds.size.width/3, collectionView.frame.size.height);
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return tabBarTitle.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    TabCell *cell = (TabCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"TabCell" forIndexPath:indexPath];
    cell.lblTitle.text = tabBarTitle[indexPath.row];
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    int direction = UIPageViewControllerNavigationDirectionForward;
    if (currentPage > indexPath.row) {
        direction = UIPageViewControllerNavigationDirectionReverse;
    }
    [pageController setViewControllers:@[[views objectAtIndex:indexPath.row]] direction:direction animated:YES completion:^(BOOL finished) {
        currentPage = indexPath.row;
    }];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat xFromCenter = self.view.frame.size.width-scrollView.contentOffset.x;
    CGFloat xCoor = (self.view.bounds.size.width/tabBarTitle.count) * currentPage;
    CGFloat xPosition = xCoor - xFromCenter/views.count;
    constantViewLeft.constant = xPosition;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

