//
//  HCWork.h
//  Skool360
//
//  Created by ADMS on 18/01/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HCWork : NSObject

@property (nonatomic , strong) NSString *HomeWorkDate;
@property (nonatomic , strong) NSString *ClassWorkDate;
@property (nonatomic , strong) NSString *Subject;
@property (nonatomic , strong) NSString *Status;
@property (nonatomic , strong) NSAttributedString *HomeWork;
@property (nonatomic , strong) NSAttributedString *ClassWork;
@property (nonatomic , strong) NSAttributedString *ChapterName;
@property (nonatomic , strong) NSAttributedString *Objective;
@property (nonatomic , strong) NSAttributedString *AssessmentQue;

@end
