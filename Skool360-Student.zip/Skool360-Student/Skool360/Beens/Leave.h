//
//  Leave.h
//  Bhadaj (Student)
//
//  Created by ADMS on 24/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Leave : NSObject
@property(nonatomic,retain)NSString *strFromDate;
@property(nonatomic,retain)NSString *strToDate;
@property(nonatomic,retain)NSString *strReason;
@property(nonatomic,retain)NSString *strStatus;
@end
