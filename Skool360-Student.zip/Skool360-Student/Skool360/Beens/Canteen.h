//
//  Canteen.h
//  Skool360
//
//  Created by Darshan on 05/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Canteen : NSObject

@property (nonatomic , strong) NSString *MenuDay;
@property (nonatomic , strong) NSString *MenuDate;
@property (nonatomic , strong) NSString *Breakfast;
@property (nonatomic , strong) NSString *Lunch;
@property (nonatomic , strong) NSString *FlvrMilk;

@end
