//
//  Attendance.h
//  Skool360
//
//  Created by Darshan on 29/08/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Attendance : NSObject

@property (nonatomic , strong) NSString *AttendanceDate;
@property (nonatomic , strong) NSString *AttendenceStatus;
@property (nonatomic , strong) NSString *Comment;

@end
