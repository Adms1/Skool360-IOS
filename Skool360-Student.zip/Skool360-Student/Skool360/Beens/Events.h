//
//  Events.h
//  Bhadaj (Student)
//
//  Created by ADMS on 24/05/18.
//  Copyright © 2018 Darshan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Photos.h"

@interface Events : NSObject
@property(nonatomic,retain)NSString *strEventName;
@property(nonatomic,retain)NSString *strEventPic;
@property(nonatomic,retain)NSMutableArray<Photos *> *photos;
@end
