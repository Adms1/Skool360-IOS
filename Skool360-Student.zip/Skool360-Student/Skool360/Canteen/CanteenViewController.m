//
//  CanteenViewController.m
//  Skool360
//
//  Created by Darshan on 05/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "CanteenViewController.h"
#import "CommonClass.h"
#import "Canteen.h"
#import "AppDelegate.h"

@interface CanteenViewController ()<NIDropDownDelegate>
{
    NIDropDown *dropDown;
    BOOL yearMonth;
    BOOL month;
    
    NSString *strYear;
    NSString *strMonth;
    NSString *strFilterMonth;
    NSString *strFilterYear;
}
@end

@implementation CanteenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (isiPhone6) {
        imgLogo.frame = CGRectMake(-66, 0, 140, 45);
    }else if (isiPhone6Plus){
        imgLogo.frame = CGRectMake(-86, 0, 140, 45);
    }
    
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.titleView = viewtitle;
    
    [btnSideMenu setAttributedTitle:nil forState:UIControlStateNormal];
    [[btnSideMenu titleLabel] setNumberOfLines:0];
    [[btnSideMenu titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    
//    UIBarButtonItem *barBtnSide = [[UIBarButtonItem alloc] initWithCustomView:btnSideMenu];
//    self.navigationItem.rightBarButtonItems = @[barBtnSide];
//    
//    UIBarButtonItem *barBtnBack = [[UIBarButtonItem alloc] initWithCustomView:btnBack];
//    self.navigationItem.leftBarButtonItems = @[barBtnBack];
    
    btnMonth.layer.cornerRadius = 4.0f;
    btnMonth.layer.borderWidth = 0.5f;
    btnMonth.layer.borderColor = imgCircleColor.CGColor;
    
    btnYear.layer.cornerRadius = 4.0f;
    btnYear.layer.borderWidth = 0.5f;
    btnYear.layer.borderColor = imgCircleColor.CGColor;
    
    btnFilter.layer.cornerRadius = 4.0f;
    
    btnSelected = YES;
    
    viewDatePicker.layer.borderWidth = 1.0f;
    viewDatePicker.layer.borderColor = datePickerBoardColor.CGColor;
    viewDatePicker.layer.cornerRadius = 4.0f;
    
    btnDone.layer.cornerRadius = 2.0f;
    btnCancel.layer.cornerRadius = 2.0f;
    
    lblNoFound.hidden = NO;
    
    NSDateFormatter *dfy = [[NSDateFormatter alloc] init];
    NSDateFormatter *dfm = [[NSDateFormatter alloc] init];
    NSDateFormatter *dfM = [[NSDateFormatter alloc] init];
    
    [dfy setDateFormat:@"yyyy"];
    [dfm setDateFormat:@"MM"];
    [dfM setDateFormat:@"MMM"];
    
    strYear = [dfy stringFromDate:[NSDate date]];
    strMonth = [dfm stringFromDate:[NSDate date]];
    NSString *strMonths = [dfM stringFromDate:[NSDate date]];
    
    [btnMonth setTitle:strMonths forState:UIControlStateNormal];
    [btnYear setTitle:strYear forState:UIControlStateNormal];
    
    strFilterYear = strYear;
    strFilterMonth = strMonth;
    
    tblCanteen.estimatedRowHeight = 96.0;
    tblCanteen.rowHeight = UITableViewAutomaticDimension;
    
    [self getCanteentToDate];
}

#pragma mark -
#pragma mark - CLASSWORK SERVICE CALL METHOD

-(void)getCanteentToDate
{
    arrCanteenList = [[NSMutableArray alloc] init];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    
    NSString *strStudentID = [[NSUserDefaults standardUserDefaults]objectForKey:STUDENTID];
    
    lblNoFound.hidden = YES;
    
    [params setObject:[NSString stringWithFormat:@"1/%@/%@",strFilterMonth,strFilterYear] forKey:@"StartDate"];
    
    NSCalendar* cal = [NSCalendar currentCalendar];
    NSDateComponents* comps = [[NSDateComponents alloc] init];
    [comps setMonth:[strFilterMonth intValue]];
    NSRange range1 = [cal rangeOfUnit:NSDayCalendarUnit
                              inUnit:NSMonthCalendarUnit
                             forDate:[cal dateFromComponents:comps]];
    
    [params setObject:[NSString stringWithFormat:@"%lu/%@/%@",(unsigned long)range1.length,strFilterMonth,strFilterYear] forKey:@"EndDate"];
    [params setObject:strStudentID forKey:@"Standard"];
    
    [SHARED_APPDELEGATE showLoadingView];
    
    NSLog(@"params>>> %@",params);
    
    [manager POST:canteenMenu_Url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SHARED_APPDELEGATE hideLoadingView];
        
        NSLog(@"ResponceLogin %@",responseObject);
        
        if ([CommonClass complareTwoString:[responseObject safeObjectForKey:@"Success"] :@"True"]) {
            
            tblCanteen.hidden = NO;
            NSMutableArray *arrListCanteen = [responseObject safeObjectForKey:@"FinalArray"];
            
            for (NSDictionary *dict in arrListCanteen) {
                
                Canteen *objCanteent = [[Canteen alloc] init];
                
                objCanteent.MenuDay = [dict safeObjectForKey:@"MenuDay"];
                objCanteent.MenuDate = [dict safeObjectForKey:@"MenuDate"];
                objCanteent.Breakfast = [dict safeObjectForKey:@"Breakfast"];
                objCanteent.Lunch = [dict safeObjectForKey:@"Lunch"];
                objCanteent.FlvrMilk = [dict safeObjectForKey:@"FlvrMilk"];
                
                [arrCanteenList addObject:objCanteent];
            }
            [tblCanteen reloadData];
        }else{
            tblCanteen.hidden = YES;
            lblNoFound.hidden = NO;
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [CommonClass errorAlert:error.code :self];

        [SHARED_APPDELEGATE hideLoadingView];
        NSLog(@"Error: %@", error);
    }];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [arrCanteenList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdenti = @"cellCanteen";
    
    CanteenCell *cell = (CanteenCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdenti];
//    if (cell == nil)
//    {
//        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CanteenCell" owner:self options:nil];
//        cell = [nib objectAtIndex:0];
//    }
    
    cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    
    if ([arrCanteenList count] > 0) {
        Canteen *objCanteen = [arrCanteenList objectAtIndex:indexPath.row];
        [cell setCanteenListData:objCanteen];
    }
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}



#pragma mark -
#pragma mark - BUTTONCLICK Method

- (IBAction)onClickMonthBtn:(id)sender {
    
    yearMonth = NO;
    
    NSArray * arr = [[NSArray alloc] init];
    arr = [NSMutableArray arrayWithObjects:@"Jan", @"Feb", @"Mar", @"Apr", @"May", @"Jun", @"Jul", @"Aug", @"Sep", @"Oct",@"Nov",@"Dec",nil];
    if(dropDown == nil) {
        CGFloat f = 240;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (IBAction)onClickYearBtn:(id)sender {
    
    yearMonth = YES;
    
    NSDate *today = [NSDate date]; // get the current date
    NSCalendar* cal = [NSCalendar currentCalendar]; // get current calender
    NSDateComponents* dateOnlyToday = [cal components:( NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit ) fromDate:today];
    [dateOnlyToday setYear:([dateOnlyToday year] + 1)];
    NSDate *nextDate = [cal dateFromComponents:dateOnlyToday];
    
    [dateOnlyToday setYear:([dateOnlyToday year] - 2)];
    NSDate *preDate = [cal dateFromComponents:dateOnlyToday];
    
    NSDateFormatter *dfy = [[NSDateFormatter alloc] init];
    [dfy setDateFormat:@"yyyy"];
    
    NSString *nextYear = [dfy stringFromDate:nextDate];
    NSString *preYear = [dfy stringFromDate:preDate];
    
    NSArray * arr = [[NSArray alloc] init];
    arr = [NSMutableArray arrayWithObjects:preYear, strYear, nextYear,nil];
    if(dropDown == nil) {
        CGFloat f = 90;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :nil :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender :(NSInteger)index{
    [self rel];
    
    if (yearMonth == YES) {
        NSLog(@"Year %@", btnYear.titleLabel.text);
        strFilterYear = btnYear.titleLabel.text;
    }else{
        NSLog(@"Month %@", btnMonth.titleLabel.text);
        
        NSString * dateString = [NSString stringWithFormat: @"%@", btnMonth.titleLabel.text];
        
        NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MMMM"];
        NSDate* myDate = [dateFormatter dateFromString:dateString];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"MM"];
        NSString *stringFromDate = [formatter stringFromDate:myDate];
        
        NSLog(@"%@", stringFromDate);
        
        strFilterMonth = stringFromDate;
    }
}

-(void)rel{
    //    [dropDown release];
    dropDown = nil;
}

- (IBAction)onClickFilterBtn:(id)sender {

    [self getCanteentToDate];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
