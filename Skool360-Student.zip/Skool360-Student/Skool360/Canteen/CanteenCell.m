//
//  CanteenCell.m
//  Skool360
//
//  Created by Darshan on 05/09/16.
//  Copyright © 2016 Darshan. All rights reserved.
//

#import "CanteenCell.h"
#import "UIImageView+GetLocalImage.h"

@implementation CanteenCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setCanteenListData:(Canteen *)objCanteen
{
    lblDate.text = objCanteen.MenuDate;
    lblDay.text = objCanteen.MenuDay;
    
    if ([objCanteen.MenuDay isEqualToString:@"Wednesday"]) {
        dateView.backgroundColor = sectionSelectColor;
        [imgIcon getImagesfromLocal:@"CanteenOrangeIcon"];
    }else{
        dateView.backgroundColor = detaultColor;
        [imgIcon getImagesfromLocal:@"CanteenIcon"];
    }
    lblBrackFast.text = objCanteen.Breakfast;
    lblLunch.text = objCanteen.Lunch;
}

-(void)setCellNewHeight:(float)extraheight
{
    cellHeight = cellHeight + (extraheight - 15);
}

-(CGFloat )getCellHeight
{
    return cellHeight;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
